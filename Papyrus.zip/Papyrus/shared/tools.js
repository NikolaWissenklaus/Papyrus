/*
 * Ferramentas de destino de um mapeamento.
 *
 * Todo mapeamento tem a mesma estrutura (pastas, paginas, catalogo, grupos),
 * e a ferramenta escolhida na criacao so muda tres coisas: o selo do card no
 * hub, as regras de nomenclatura que o validador cobra e os geradores de
 * codigo oferecidos no inspetor.
 *
 * `rules: 'ga4'` liga snake_case, nomes reservados, prefixos proibidos e os
 * limites oficiais do GA4. As demais ferramentas usam `generic`: o Meta Ads,
 * por exemplo, tem eventos padrao em PascalCase (`AddToCart`), e cobrar
 * snake_case ali travaria a exportacao por um erro que nao existe.
 *
 * As cores sao so de identificacao no hub. Nenhum logotipo e usado.
 */

export const TOOLS = [
  { id: 'ga4', label: 'Google Analytics 4', short: 'GA4', color: '#E37400', rules: 'ga4', snippets: ['dataLayer', 'gtag', 'schema'] },
  { id: 'google-ads', label: 'Google Ads', short: 'Ads', color: '#1A73E8', rules: 'generic', snippets: ['dataLayer', 'gtag', 'schema'] },
  { id: 'meta-ads', label: 'Meta Ads', short: 'Meta', color: '#0866FF', rules: 'generic', snippets: ['dataLayer', 'schema'] },
  { id: 'criteo', label: 'Criteo', short: 'CR', color: '#F25C05', rules: 'generic', snippets: ['dataLayer', 'schema'] },
  { id: 'rtb-house', label: 'RTB House', short: 'RTB', color: '#C8102E', rules: 'generic', snippets: ['dataLayer', 'schema'] },
  { id: 'tiktok-ads', label: 'TikTok Ads', short: 'TT', color: '#161823', rules: 'generic', snippets: ['dataLayer', 'schema'] },
  { id: 'linkedin-ads', label: 'LinkedIn Ads', short: 'in', color: '#0A66C2', rules: 'generic', snippets: ['dataLayer', 'schema'] },
  { id: 'pinterest-ads', label: 'Pinterest Ads', short: 'Pin', color: '#E60023', rules: 'generic', snippets: ['dataLayer', 'schema'] },
  { id: 'other', label: 'Outra ferramenta', short: '•••', color: '#5F6368', rules: 'generic', snippets: ['dataLayer', 'schema'] },
];

export const TOOL_MAP = Object.fromEntries(TOOLS.map((tool) => [tool.id, tool]));

/** Ferramenta pelo id. Id desconhecido cai em "Outra ferramenta", nunca em undefined. */
export function toolOf(id) {
  return TOOL_MAP[id] || TOOL_MAP.other;
}
