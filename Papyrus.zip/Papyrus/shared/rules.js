/*
 * Vocabulario e regras de nomenclatura que o servidor e o navegador precisam
 * aplicar do mesmo jeito.
 *
 * Este arquivo e importado pelo Node (server/lib/catalog.js) e pelo navegador
 * (public/js/constants.js e util.js). Por isso nao pode depender de DOM nem de
 * modulo do Node, e so importa outros arquivos de `shared/` por caminho
 * relativo, que funciona igual nos dois lados.
 */

/** Tipos de evento. Os rotulos e cores ficam em public/js/constants.js. */
export const EVENT_TYPE_IDS = ['view', 'interaction', 'ecommerce', 'automatic'];

/** Tipos de dado suportados no parametro. */
export const PARAM_TYPES = ['string', 'boolean', 'int', 'float', 'array', 'object'];

/** Escopos de parametro dentro de um card, na mesma ordem em que aparecem. */
export const PARAM_SCOPE_IDS = ['eventParams', 'userParams', 'itemParams'];

/** Nomes que o GA4 reserva. Eventos customizados nao podem usar nenhum deles. */
export const RESERVED_EVENT_NAMES = new Set([
  'ad_activeview', 'ad_click', 'ad_exposure', 'ad_query', 'ad_reward',
  'adunit_exposure', 'app_clear_data', 'app_exception', 'app_install',
  'app_remove', 'app_store_refund', 'app_store_subscription_cancel',
  'app_store_subscription_convert', 'app_store_subscription_renew',
  'app_update', 'app_upgrade', 'dynamic_link_app_open', 'dynamic_link_app_update',
  'dynamic_link_first_open', 'error', 'firebase_campaign', 'firebase_in_app_message_action',
  'first_open', 'first_visit', 'in_app_purchase', 'notification_dismiss',
  'notification_foreground', 'notification_open', 'notification_receive',
  'os_update', 'session_start', 'user_engagement',
]);

/** Prefixos reservados para nomes de evento e parametro. */
export const RESERVED_PREFIXES = ['ga_', 'google_', 'firebase_'];

/** Limites oficiais do GA4 relevantes para o planejamento. */
export const GA4_LIMITS = {
  eventNameLength: 40,
  paramNameLength: 40,
  paramValueLength: 100,
  paramsPerEvent: 25,
  userPropertiesPerProperty: 25,
};

/** Limite de tamanho de nome nas ferramentas que nao seguem as regras do GA4. */
export const GENERIC_NAME_LENGTH = 100;

/** Converte texto livre em snake_case valido para GA4. */
export function toSnakeCase(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '') // remove os acentos separados pelo NFD
    .replace(/([a-z0-9])([A-Z])/g, '$1_$2')
    .toLowerCase()
    .replace(/[^a-z0-9_]+/g, '_')
    .replace(/_{2,}/g, '_')
    .replace(/^_+|_+$/g, '');
}

/** Verifica se o texto ja esta em snake_case canonico. */
export function isSnakeCase(value) {
  return /^[a-z][a-z0-9_]*$/.test(String(value || ''));
}

/**
 * Forma de comparacao de nomes do catalogo: sem caixa e sem espacos nas
 * pontas. `View_Item` e `view_item` nao podem conviver como dois eventos.
 */
export function normalizeKey(name) {
  return String(name || '').trim().normalize('NFC').toLowerCase();
}
