/*
 * Vinculo entre o card de evento do canvas e o evento do catalogo.
 *
 * O card guarda `catalogEventId` e uma copia do que o catalogo define: nome,
 * tipo e as tabelas de parametros, cada parametro com o seu `catalogParamId`.
 * A copia existe para a pagina continuar autossuficiente: o exportador, os
 * geradores de codigo, o validador e o backup leem o card sem precisar
 * consultar o catalogo.
 *
 * O catalogo e a fonte da verdade da estrutura. O que e manual no card (valor
 * de exemplo de cada parametro, gatilho, plataforma, governanca, ticket e o
 * proprio event_id) nunca e tocado pela sincronizacao.
 *
 * O mesmo codigo roda no servidor, que propaga as mudancas do catalogo para as
 * paginas no disco, e no navegador, que monta o card novo e ressincroniza a
 * pagina aberta. Duas implementacoes divergiriam na primeira mudanca.
 */

import { PARAM_SCOPE_IDS, normalizeKey } from './rules.js';

/** Parametro que identifica cada card. Nao pertence ao catalogo: todo card tem o seu. */
export const EVENT_ID_PARAM = 'event_id';

const EVENT_ID_ALPHABET = 'abcdefghijklmnopqrstuvwxyz0123456789';

/** Identificador curto, no mesmo formato do uid() de public/js/util.js. */
export function uid(prefix = 'el') {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}${Date.now().toString(36).slice(-4)}`;
}

/*
 * Monta o `event_id` em tres partes separadas por hifen:
 *
 *   d + codigos ASCII do nome da pasta da pagina
 *   p + timestamp atual em segundos
 *   6 + sufixo aleatorio de 6 caracteres
 *
 * Os codigos ASCII vao com zero a esquerda, sempre 3 digitos. Sem esse padding
 * "AB" (65, 66) e "6566" dariam a mesma string e o prefixo pararia de
 * identificar a pasta. Quando a pagina esta na raiz do mapeamento, a pasta
 * considerada e a propria `papyrus`.
 */
export function generateEventId(folderName) {
  // NFD separa o acento da letra. O filtro logo abaixo joga fora o acento
  // solto e tudo o que estiver fora da faixa ASCII imprimivel.
  const ascii = [
    ...String(folderName || 'papyrus')
      .normalize('NFD')
      .replace(/[^\x20-\x7E]/g, ''),
  ]
    .map((char) => String(char.charCodeAt(0)).padStart(3, '0'))
    .join('');

  const random = Array.from(
    { length: 6 },
    () => EVENT_ID_ALPHABET[Math.floor(Math.random() * EVENT_ID_ALPHABET.length)],
  ).join('');

  return `d${ascii}-p${Math.floor(Date.now() / 1000)}-6${random}`;
}

/** Nome da pasta de uma pagina a partir do caminho relativo. Vazio na raiz. */
export function folderNameOf(pagePath) {
  const parts = String(pagePath || '').split('/');
  return parts.length > 1 ? parts[parts.length - 2] : '';
}

export function emptyCatalog() {
  return { events: [], params: [] };
}

/**
 * Indices de consulta do catalogo. Montado uma vez por operacao, e nao a cada
 * card: uma propagacao percorre centenas de cards contra o mesmo catalogo.
 */
export function indexCatalog(catalog) {
  const events = new Map();
  const params = new Map();
  const eventsByName = new Map();
  const paramsByKey = new Map();

  for (const param of catalog?.params || []) {
    params.set(param.id, param);
    paramsByKey.set(paramKey(param.scope, param.name), param);
  }
  for (const event of catalog?.events || []) {
    events.set(event.id, event);
    eventsByName.set(normalizeKey(event.name), event);
  }

  return { catalog: catalog || emptyCatalog(), events, params, eventsByName, paramsByKey };
}

/** Chave de um parametro no catalogo: o nome so se repete em escopos diferentes. */
export function paramKey(scope, name) {
  return `${scope}::${normalizeKey(name)}`;
}

/** Parametros que um evento do catalogo declara, ja resolvidos e agrupados por escopo. */
export function resolveEventParams(event, index) {
  const out = { eventParams: [], userParams: [], itemParams: [] };
  for (const ref of event?.params || []) {
    const def = index.params.get(ref.id);
    if (!def || !out[def.scope]) continue;
    out[def.scope].push({ def, required: Boolean(ref.required) });
  }
  return out;
}

/*
 * O event_id do card atravessa qualquer troca de evento. Card sem ele (legado
 * que perdeu a linha, por exemplo) ganha um novo, porque sem a chave o card
 * nem passa no validador.
 */
function keepEventId(previousEventParams, folderName) {
  const found = (previousEventParams || []).find((p) => p?.name === EVENT_ID_PARAM);
  if (found) {
    const { catalogParamId, ...rest } = found;
    return rest;
  }
  return {
    id: uid('p'),
    name: EVENT_ID_PARAM,
    type: 'string',
    required: true,
    example: generateEventId(folderName),
    description: '',
  };
}

/**
 * Monta as tabelas de parametros do card a partir do evento do catalogo.
 *
 * Cada parametro do card e reencontrado pelo `catalogParamId` e, na falta
 * dele, pelo nome no mesmo escopo. E isso que preserva o valor de exemplo
 * digitado no card quando o parametro e renomeado no catalogo, e tambem quando
 * um card antigo, sem vinculo, e ligado ao catalogo pela primeira vez.
 */
export function buildCardParams(event, index, previous = {}, { folderName } = {}) {
  const byCatalogId = new Map();
  const byName = new Map();

  for (const scope of PARAM_SCOPE_IDS) {
    for (const p of previous[scope] || []) {
      if (!p || p.name === EVENT_ID_PARAM) continue;
      if (p.catalogParamId) byCatalogId.set(p.catalogParamId, p);
      if (p.name) byName.set(paramKey(scope, p.name), p);
    }
  }

  const resolved = resolveEventParams(event, index);
  const out = {};

  for (const scope of PARAM_SCOPE_IDS) {
    out[scope] = resolved[scope].map(({ def, required }) => {
      const prev = byCatalogId.get(def.id) || byName.get(paramKey(scope, def.name));
      return {
        id: prev?.id || uid('p'),
        catalogParamId: def.id,
        name: def.name,
        type: def.type || 'string',
        required,
        example: prev ? String(prev.example ?? '') : String(def.example || ''),
        description: def.description || '',
      };
    });
  }

  out.eventParams.unshift(keepEventId(previous.eventParams, folderName));
  return out;
}

/** Liga o card ao evento do catalogo, trocando nome, tipo e parametros. */
export function linkCardData(data, event, index, options = {}) {
  return {
    ...data,
    catalogEventId: event.id,
    name: event.name,
    eventType: event.eventType,
    ...buildCardParams(event, index, data || {}, options),
  };
}

/** O que a sincronizacao controla no card. O resto e manual. */
const syncedShape = (data) =>
  JSON.stringify({
    name: data.name,
    eventType: data.eventType,
    eventParams: data.eventParams || [],
    userParams: data.userParams || [],
    itemParams: data.itemParams || [],
  });

/**
 * Reaplica o catalogo em um card ja vinculado.
 * @returns {{ data: object, changed: boolean, missing: boolean }}
 */
export function syncCardData(data, index, options = {}) {
  if (!data?.catalogEventId) return { data, changed: false, missing: false };

  const event = index.events.get(data.catalogEventId);
  if (!event) return { data, changed: false, missing: true };

  const next = linkCardData(data, event, index, options);
  const changed = syncedShape(data) !== syncedShape(next);
  return { data: changed ? next : data, changed, missing: false };
}

/** Desfaz o vinculo e deixa o card como estava, so que livre para edicao. */
export function unlinkCardData(data) {
  const { catalogEventId, ...rest } = data || {};
  const strip = (list) => (list || []).map(({ catalogParamId, ...p }) => p);
  return {
    ...rest,
    eventParams: strip(rest.eventParams),
    userParams: strip(rest.userParams),
    itemParams: strip(rest.itemParams),
  };
}

/** 'linked' | 'missing' (o evento sumiu do catalogo) | 'unlinked' (card livre). */
export function cardLinkStatus(data, index) {
  if (!data?.catalogEventId) return 'unlinked';
  return index.events.has(data.catalogEventId) ? 'linked' : 'missing';
}

/**
 * Card colado de outro mapeamento chega com ids de outro catalogo. Ele e
 * religado pelo nome quando o evento existe aqui, e solto quando nao existe:
 * um vinculo apontando para o nada so geraria aviso sem conserto.
 */
export function relinkCardData(data, index, options = {}) {
  if (!data?.catalogEventId) return data;
  if (index.events.has(data.catalogEventId)) return syncCardData(data, index, options).data;

  const sameName = index.eventsByName.get(normalizeKey(data.name));
  if (sameName) return linkCardData(data, sameName, index, options);
  return unlinkCardData(data);
}

/**
 * Sincroniza todos os cards vinculados de uma pagina.
 *
 * `onlyEventIds` limita a passada aos cards de alguns eventos, que e o caso da
 * propagacao depois de editar um evento so.
 *
 * @returns {{ doc: object, changed: number, missing: number }}
 */
export function syncDocWithCatalog(doc, index, { onlyEventIds = null, folderName } = {}) {
  if (!Array.isArray(doc?.elements)) return { doc, changed: 0, missing: 0 };

  let changed = 0;
  let missing = 0;
  const only = onlyEventIds ? new Set(onlyEventIds) : null;

  const elements = doc.elements.map((el) => {
    if (el?.type !== 'event' || !el.data?.catalogEventId) return el;
    if (only && !only.has(el.data.catalogEventId)) return el;

    const result = syncCardData(el.data, index, { folderName });
    if (result.missing) missing += 1;
    if (!result.changed) return el;
    changed += 1;
    return { ...el, data: result.data };
  });

  return { doc: changed ? { ...doc, elements } : doc, changed, missing };
}
