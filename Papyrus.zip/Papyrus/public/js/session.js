/*
 * Sessao do lado do navegador: 30 minutos sem atividade e a pessoa volta para
 * o login.
 *
 * Quem decide se a sessao vale e o servidor, que empurra o prazo a cada
 * requisicao. So que ler o catalogo ou rolar uma tabela e atividade sem
 * requisicao nenhuma. Por isso a interface observa mouse, teclado e rolagem e,
 * havendo atividade, avisa o servidor no maximo uma vez por minuto.
 *
 * O ultimo instante de atividade vai para o localStorage. Com duas abas
 * abertas, a aba parada nao derruba a sessao da aba em uso: ela so encerra
 * quando nenhuma das duas teve atividade nos ultimos 30 minutos.
 */

import { api } from './api.js';

const ACTIVITY_KEY = 'papyrus.lastActivity';
const PING_EVERY_MS = 60 * 1000;
const CHECK_EVERY_MS = 15 * 1000;

let ttl = 30 * 60 * 1000;
let lastActivity = Date.now();
let lastContact = Date.now();
let ending = false;
let beforeEnd = null;
let timer = null;

function sharedActivity() {
  try {
    return Math.max(lastActivity, Number(localStorage.getItem(ACTIVITY_KEY)) || 0);
  } catch {
    return lastActivity;
  }
}

function markActivity() {
  const now = Date.now();
  if (now - lastActivity < 1000) return;
  lastActivity = now;
  try {
    localStorage.setItem(ACTIVITY_KEY, String(now));
  } catch {
    /* storage bloqueado: vale a atividade desta aba */
  }
}

async function check() {
  if (ending) return;
  const now = Date.now();
  const last = sharedActivity();

  if (now - last >= ttl) {
    endSession('idle');
    return;
  }
  if (last > lastContact && now - lastContact >= PING_EVERY_MS) {
    lastContact = now;
    api.touch().catch(() => {});
  }
}

/**
 * @param {{ ttlMs: number, beforeEnd?: () => Promise<void> }} options
 *   `beforeEnd` grava o que estiver pendente antes de sair.
 */
export function startSessionWatch({ ttlMs, beforeEnd: hook } = {}) {
  if (Number(ttlMs) > 0) ttl = Number(ttlMs);
  beforeEnd = hook || null;
  lastActivity = Date.now();
  markActivity();

  const events = ['pointerdown', 'keydown', 'wheel', 'touchstart'];
  for (const name of events) window.addEventListener(name, markActivity, { capture: true, passive: true });
  window.addEventListener('pointermove', markActivity, { passive: true });
  window.addEventListener('scroll', markActivity, { capture: true, passive: true });

  clearInterval(timer);
  timer = setInterval(check, CHECK_EVERY_MS);

  // Notebook que acordou depois de horas fechado confere na hora.
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') check();
  });
}

/** Toda resposta do servidor ja conta como contato: nao precisa de ping extra. */
export function noteServerContact() {
  lastContact = Date.now();
}

/**
 * Encerra a sessao e volta para o login.
 * @param {'idle'|'expired'|'logout'} reason
 */
export async function endSession(reason = 'logout') {
  if (ending) return;
  ending = true;
  clearInterval(timer);

  try {
    await beforeEnd?.();
  } catch {
    /* a sessao pode ja ter caido no servidor; nao ha mais o que gravar */
  }
  try {
    await api.logout();
  } catch {
    /* sair funciona mesmo com a sessao vencida */
  }
  location.replace(`/login?reason=${encodeURIComponent(reason)}`);
}
