/*
 * Usuarios: o chip com o menu da conta, a troca da propria senha e o
 * gerenciamento (so administradores): adicionar, remover, redefinir senha e
 * mudar o perfil.
 *
 * Senha nunca aparece. A lista mostra nome, perfil e datas; redefinir pede a
 * senha nova duas vezes, em campo mascarado. O usuario padrao (abacate) nao
 * pode ser removido nem deixar de ser administrador.
 *
 * Perfis:
 *   Administrador  usa a ferramenta, gerencia usuarios e mexe nas integracoes
 *   Editor         usa a ferramenta inteira (mapas, catalogo, importacoes)
 */

import { api } from '../api.js';
import { state, setUser } from '../store.js';
import { esc, formatDate } from '../util.js';
import { openModal, confirm, contextMenu } from '../ui/modal.js';
import { toast } from '../ui/toast.js';
import { endSession } from '../session.js';

const USERNAME_RULE = /^[a-z0-9][a-z0-9._@-]{2,63}$/;
const PASSWORD_MIN = 8;

const initial = (name) => String(name || '?').trim().charAt(0).toUpperCase();

/** Botao com a inicial e o nome de quem esta logado. */
export function renderUserChip(host) {
  const user = state.user;
  if (!host || !user) return;
  host.innerHTML = `
    <button class="user-chip" type="button" title="Conta de ${esc(user.username)}">
      <span class="user-chip__avatar">${esc(initial(user.username))}</span>
      <span class="user-chip__name">${esc(user.username)}</span>
      <svg class="user-chip__caret" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 4.5L6 7.5l3-3" /></svg>
    </button>`;
}

/**
 * Menu da conta.
 * @param {HTMLElement} anchor
 * @param {{ onSwitchWorkspace?: () => void }} [options] sem a opcao, o menu e o do hub
 */
export function openUserMenu(anchor, { onSwitchWorkspace } = {}) {
  const rect = anchor.getBoundingClientRect();
  const items = [];

  if (onSwitchWorkspace) items.push({ label: 'Trocar de mapeamento', onClick: onSwitchWorkspace });
  if (state.user?.admin) items.push({ label: 'Gerenciar usuários', onClick: () => openUserManager() });
  items.push({ label: 'Trocar minha senha', onClick: () => openChangePassword() });
  items.push({ label: 'Documentação', onClick: () => window.open('/docs/papyrus-handbook.html', '_blank', 'noopener') });
  items.push('-');
  items.push({ label: 'Sair', danger: true, onClick: () => endSession('logout') });

  contextMenu(rect.right - 200, rect.bottom + 6, items);
}

function showError(node, message) {
  node.textContent = message;
  node.hidden = !message;
}

/** Campo de senha com rotulo, sem nada de exibir o conteudo. */
const passwordField = (id, label, autocomplete) => `
  <div class="field">
    <label class="field__label" for="${id}">${esc(label)}</label>
    <input class="input" type="password" id="${id}" autocomplete="${autocomplete}" spellcheck="false" />
  </div>`;

function checkNewPassword(password, confirmation) {
  if (password.length < PASSWORD_MIN) return `A senha precisa ter pelo menos ${PASSWORD_MIN} caracteres.`;
  if (password !== confirmation) return 'As duas senhas não conferem.';
  return null;
}

/* Minha senha */

export function openChangePassword() {
  return openModal({
    title: 'Trocar minha senha',
    subtitle: `Conta ${state.user?.username || ''}. As outras sessões abertas com esta conta são encerradas.`,
    body: `
      ${passwordField('cp-current', 'Senha atual', 'current-password')}
      ${passwordField('cp-new', 'Nova senha', 'new-password')}
      ${passwordField('cp-confirm', 'Repita a nova senha', 'new-password')}
      <div class="field__hint">Pelo menos ${PASSWORD_MIN} caracteres.</div>
      <div class="form-error" id="cp-error" role="alert" hidden></div>`,
    footer: `
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--primary" id="cp-save">Trocar senha</button>`,
    onMount: (modal, close) => {
      const error = modal.querySelector('#cp-error');
      const save = modal.querySelector('#cp-save');
      const value = (id) => modal.querySelector(id).value;

      const submit = async () => {
        const problem = checkNewPassword(value('#cp-new'), value('#cp-confirm'));
        if (!value('#cp-current')) return showError(error, 'Informe a senha atual.');
        if (problem) return showError(error, problem);

        save.disabled = true;
        try {
          const { user } = await api.changePassword(value('#cp-current'), value('#cp-new'));
          setUser(user);
          toast.ok('Senha trocada.');
          close(true);
        } catch (err) {
          showError(error, err.message);
          save.disabled = false;
        }
      };

      modal.querySelectorAll('input').forEach((input) => {
        input.onkeydown = (e) => e.key === 'Enter' && submit();
      });
      save.onclick = submit;
      modal.querySelector('#cp-current').focus();
    },
  });
}

/* Gerenciamento (administrador) */

function usersTable(users) {
  const me = state.user?.username;
  return `
    <div class="table-scroll" style="max-height:52vh">
      <table class="table">
        <thead><tr><th>Usuário</th><th>Perfil</th><th>Criado</th><th>Último acesso</th><th></th></tr></thead>
        <tbody>
          ${users
            .map(
              (u) => `
              <tr>
                <td>
                  <span class="user-cell">
                    <span class="user-chip__avatar user-chip__avatar--small">${esc(initial(u.username))}</span>
                    <strong>${esc(u.username)}</strong>
                    ${u.username === me ? '<span class="chip">você</span>' : ''}
                    ${u.isDefault ? '<span class="chip chip--view" title="Usuário padrão: não pode ser removido">padrão</span>' : ''}
                  </span>
                  ${u.usingDefaultPassword ? '<div class="cell-sub" style="color:var(--warn)">ainda com a senha padrão</div>' : ''}
                </td>
                <td>${u.admin ? '<span class="chip chip--interaction">Administrador</span>' : '<span class="chip">Editor</span>'}</td>
                <td class="muted">${formatDate(u.createdAt)}${u.createdBy ? `<div class="cell-sub">por ${esc(u.createdBy)}</div>` : ''}</td>
                <td class="muted">${u.lastLoginAt ? formatDate(u.lastLoginAt) : '<span class="faint">nunca entrou</span>'}</td>
                <td class="cell-actions">
                  <button class="btn btn--mini" data-reset="${esc(u.username)}">Redefinir senha</button>
                  ${
                    !u.isDefault && u.username !== me
                      ? `<button class="btn btn--mini" data-profile="${esc(u.username)}">${u.admin ? 'Tornar editor' : 'Tornar administrador'}</button>
                         <button class="btn btn--mini btn--mini-danger" data-remove="${esc(u.username)}">Remover</button>`
                      : ''
                  }
                </td>
              </tr>`,
            )
            .join('')}
        </tbody>
      </table>
    </div>`;
}

export async function openUserManager() {
  if (!state.user?.admin) {
    toast.error('Apenas administradores gerenciam usuários.');
    return;
  }

  let users;
  try {
    ({ users } = await api.listUsers());
  } catch (err) {
    toast.error(err.message);
    return;
  }

  await openModal({
    title: 'Usuários',
    subtitle: 'Quem pode entrar no Papyrus. As senhas nunca são exibidas; para trocar, redefina.',
    wide: true,
    body: `
      <div class="users-head">
        <div class="field__hint">
          <strong>Administrador</strong> gerencia usuários e as integrações. <strong>Editor</strong> usa a ferramenta inteira.
          O usuário padrão não pode ser removido.
        </div>
        <button class="btn btn--primary" id="um-new">+ Novo usuário</button>
      </div>
      <div id="um-table">${usersTable(users)}</div>`,
    footer: '<button class="btn btn--ghost" data-close="null">Fechar</button>',
    onMount: (modal) => {
      const host = modal.querySelector('#um-table');

      const reload = async () => {
        try {
          ({ users } = await api.listUsers());
          host.innerHTML = usersTable(users);
          bindRows();
        } catch (err) {
          toast.error(err.message);
        }
      };

      function bindRows() {
        host.querySelectorAll('[data-reset]').forEach((btn) => {
          btn.onclick = async () => {
            if (await openResetPassword(btn.dataset.reset)) reload();
          };
        });
        host.querySelectorAll('[data-profile]').forEach((btn) => {
          btn.onclick = async () => {
            const user = users.find((u) => u.username === btn.dataset.profile);
            try {
              await api.setUserAdmin(user.username, !user.admin);
              toast.ok(`${user.username} agora é ${user.admin ? 'editor' : 'administrador'}.`);
              reload();
            } catch (err) {
              toast.error(err.message);
            }
          };
        });
        host.querySelectorAll('[data-remove]').forEach((btn) => {
          btn.onclick = async () => {
            const username = btn.dataset.remove;
            const ok = await confirm({
              title: 'Remover usuário',
              message: `Remover "${username}"? A pessoa perde o acesso na hora, inclusive a sessão que estiver aberta. Os mapas criados por ela continuam.`,
              confirmText: 'Remover',
            });
            if (!ok) return;
            try {
              await api.deleteUser(username);
              toast.ok(`Usuário "${username}" removido.`);
              reload();
            } catch (err) {
              toast.error(err.message);
            }
          };
        });
      }

      modal.querySelector('#um-new').onclick = async () => {
        if (await openNewUser()) reload();
      };
      bindRows();
    },
  });
}

function openNewUser() {
  return openModal({
    title: 'Novo usuário',
    subtitle: 'A senha definida aqui é a de primeiro acesso. A pessoa pode trocar depois em "Trocar minha senha".',
    body: `
      <div class="field">
        <label class="field__label" for="nu-name">Usuário</label>
        <input class="input" id="nu-name" autocomplete="off" spellcheck="false" placeholder="ex.: ana.souza" />
        <div class="field__hint">Letras minúsculas, números, ponto, hífen, sublinhado ou @, de 3 a 64 caracteres.</div>
      </div>
      ${passwordField('nu-pass', 'Senha', 'new-password')}
      ${passwordField('nu-confirm', 'Repita a senha', 'new-password')}
      <label class="check"><input type="checkbox" id="nu-admin" /> Administrador (gerencia usuários e integrações)</label>
      <div class="form-error" id="nu-error" role="alert" hidden></div>`,
    footer: `
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--primary" id="nu-save">Criar usuário</button>`,
    onMount: (modal, close) => {
      const error = modal.querySelector('#nu-error');
      const save = modal.querySelector('#nu-save');
      const name = modal.querySelector('#nu-name');

      name.oninput = () => {
        const lower = name.value.toLowerCase();
        if (lower !== name.value) name.value = lower;
      };

      const submit = async () => {
        const username = name.value.trim();
        if (!USERNAME_RULE.test(username)) return showError(error, 'Usuário inválido. Veja as regras logo abaixo do campo.');
        const problem = checkNewPassword(modal.querySelector('#nu-pass').value, modal.querySelector('#nu-confirm').value);
        if (problem) return showError(error, problem);

        save.disabled = true;
        try {
          await api.createUser({
            username,
            password: modal.querySelector('#nu-pass').value,
            admin: modal.querySelector('#nu-admin').checked,
          });
          toast.ok(`Usuário "${username}" criado.`);
          close(true);
        } catch (err) {
          showError(error, err.message);
          save.disabled = false;
        }
      };

      modal.querySelectorAll('input').forEach((input) => {
        input.onkeydown = (e) => e.key === 'Enter' && submit();
      });
      save.onclick = submit;
      name.focus();
    },
  });
}

function openResetPassword(username) {
  const self = username === state.user?.username;
  return openModal({
    title: 'Redefinir senha',
    subtitle: self
      ? 'A sua senha. As outras sessões abertas com esta conta são encerradas.'
      : `Nova senha de "${username}". Quem estiver logado com esta conta sai na hora.`,
    body: `
      ${passwordField('rp-pass', 'Nova senha', 'new-password')}
      ${passwordField('rp-confirm', 'Repita a nova senha', 'new-password')}
      <div class="field__hint">Pelo menos ${PASSWORD_MIN} caracteres. Passe a senha para a pessoa por um canal seguro.</div>
      <div class="form-error" id="rp-error" role="alert" hidden></div>`,
    footer: `
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--primary" id="rp-save">Redefinir</button>`,
    onMount: (modal, close) => {
      const error = modal.querySelector('#rp-error');
      const save = modal.querySelector('#rp-save');

      const submit = async () => {
        const password = modal.querySelector('#rp-pass').value;
        const problem = checkNewPassword(password, modal.querySelector('#rp-confirm').value);
        if (problem) return showError(error, problem);

        save.disabled = true;
        try {
          const { user } = await api.resetUserPassword(username, password);
          if (self) setUser({ ...state.user, ...user });
          toast.ok(`Senha de "${username}" redefinida.`);
          close(true);
        } catch (err) {
          showError(error, err.message);
          save.disabled = false;
        }
      };

      modal.querySelectorAll('input').forEach((input) => {
        input.onkeydown = (e) => e.key === 'Enter' && submit();
      });
      save.onclick = submit;
      modal.querySelector('#rp-pass').focus();
    },
  });
}
