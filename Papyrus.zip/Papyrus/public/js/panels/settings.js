/*
 * Aba "Configuracoes", dividida em tres blocos.
 *
 * O primeiro guarda os padroes da foto do canvas (resolucao, formato, fundo,
 * margem e as opcoes do PDF) que pre-preenchem o modal "Foto / PDF". Eles
 * ficam no localStorage do navegador.
 *
 * O segundo cuida do Google Cloud Storage: bucket, prefixo, project id e a
 * service account, colada como JSON em um campo mascarado. A chave privada
 * nunca volta para o navegador; a API devolve so `hasCredential`.
 *
 * O terceiro mostra o backup diario no bucket (pasta versions/): se esta
 * ativo, quando rodou pela ultima vez e o botao para rodar agora.
 *
 * Mexer no Storage e no backup e de administrador. Para os demais a tela
 * mostra o estado, com os campos travados.
 *
 * Por seguranca, a tela nao mostra nada sobre o servidor: nem caminho de pasta,
 * nem sistema operacional, nem versao do runtime.
 */

import { api } from '../api.js';
import { on, state } from '../store.js';
import { esc, formatDate, formatBytes } from '../util.js';
import { toast } from '../ui/toast.js';
import { PDF_PAGE_FORMATS } from '../pdf.js';

let root = null;

/* Padroes de exportacao, guardados no localStorage */

const EXPORT_DEFAULTS_KEY = 'papyrus.exportDefaults';

const BASE_EXPORT_DEFAULTS = {
  scale: '3',
  format: 'png',
  background: '#FFFFFF',
  padding: 60,
  pdfPage: 'fit',
  pdfHeader: true,
};

/** Padroes atuais, lidos pelo modal "Tirar foto". */
export function getExportDefaults() {
  try {
    return { ...BASE_EXPORT_DEFAULTS, ...JSON.parse(localStorage.getItem(EXPORT_DEFAULTS_KEY) || '{}') };
  } catch {
    return { ...BASE_EXPORT_DEFAULTS };
  }
}

function saveExportDefaults(patch) {
  const next = { ...getExportDefaults(), ...patch };
  localStorage.setItem(EXPORT_DEFAULTS_KEY, JSON.stringify(next));
  return next;
}

/* Init / render */

export function initSettings() {
  root = document.getElementById('settings-root');
  on('view', (view) => {
    if (view === 'settings') render();
  });
}

async function render() {
  root.innerHTML = `
    <div class="page-head">
      <div>
        <h1>Configurações</h1>
        <p>Preferências da ferramenta e integrações. O Storage e o backup valem para todos os mapeamentos.</p>
      </div>
    </div>
    <div id="settings-body">
      <div class="card" style="text-align:center;color:var(--text-muted)">Carregando…</div>
    </div>`;

  let gcs = null;
  let backup = null;
  try {
    [gcs, backup] = await Promise.all([api.getGcsSettings(), api.backupStatus()]);
  } catch (err) {
    root.querySelector('#settings-body').innerHTML =
      `<div class="card" style="color:var(--danger)">${esc(err.message)}</div>`;
    return;
  }

  const body = root.querySelector('#settings-body');
  body.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:16px">
      ${exportCard()}
      ${gcsCard(gcs)}
      ${backupCard(backup)}
    </div>`;

  bindExportCard(body);
  bindGcsCard(body, gcs);
  bindBackupCard(body);
}

const isAdmin = () => Boolean(state.user?.admin);

const adminNote = () =>
  isAdmin()
    ? ''
    : '<p class="field__hint" style="margin:0 0 12px"><strong>Somente administradores alteram esta integração.</strong> Os valores aparecem só para consulta.</p>';

/* Padroes da foto do canvas */

function exportCard() {
  const def = getExportDefaults();
  const opt = (value, label, current) =>
    `<option value="${value}"${String(value) === String(current) ? ' selected' : ''}>${label}</option>`;

  return `
    <div class="card">
      <h3 style="font-size:16px;margin-bottom:4px">Foto e PDF do canvas</h3>
      <p class="field__hint" style="margin:0 0 16px">
        Valores pré-selecionados ao abrir o modal "Foto / PDF". Salvos automaticamente neste navegador.
      </p>
      <div class="grid-2" style="max-width:640px">
        <div class="field">
          <label class="field__label">Resolução padrão</label>
          <select class="select" data-export-pref="scale">
            ${opt('2', '2× (apresentação)', def.scale)}
            ${opt('3', '3× (alta resolução)', def.scale)}
            ${opt('4', '4× (impressão)', def.scale)}
          </select>
        </div>
        <div class="field">
          <label class="field__label">Formato padrão</label>
          <select class="select" data-export-pref="format">
            ${opt('png', 'PNG (sem perdas)', def.format)}
            ${opt('jpeg', 'JPG (arquivo menor)', def.format)}
            ${opt('pdf', 'PDF (documento)', def.format)}
          </select>
        </div>
        <div class="field">
          <label class="field__label">Fundo padrão</label>
          <select class="select" data-export-pref="background">
            ${opt('#FFFFFF', 'Branco', def.background)}
            ${opt('#F8F9FA', 'Cinza claro', def.background)}
            ${opt('#202124', 'Preto', def.background)}
            ${opt('transparent', 'Transparente (só PNG)', def.background)}
          </select>
        </div>
        <div class="field">
          <label class="field__label">Margem padrão (px)</label>
          <input class="input" type="number" min="0" max="300" data-export-pref="padding" value="${def.padding}" />
        </div>
        <div class="field">
          <label class="field__label">Página do PDF</label>
          <select class="select" data-export-pref="pdfPage">
            ${PDF_PAGE_FORMATS.map((f) => opt(f.id, esc(f.label), def.pdfPage)).join('')}
          </select>
        </div>
        <div class="field">
          <label class="field__label">Cabeçalho do PDF</label>
          <label class="check"><input type="checkbox" data-export-pref="pdfHeader" ${def.pdfHeader === false ? '' : 'checked'} /> Nome da página, mapeamento e data</label>
        </div>
      </div>
    </div>`;
}

function bindExportCard(body) {
  body.querySelectorAll('[data-export-pref]').forEach((node) => {
    node.onchange = () => {
      const key = node.dataset.exportPref;
      const value =
        key === 'padding' ? Math.max(0, Number(node.value) || 0) : node.type === 'checkbox' ? node.checked : node.value;
      saveExportDefaults({ [key]: value });
      toast.ok('Padrão de exportação salvo.');
    };
  });
}

/* Google Cloud Storage */

function statusChip(status) {
  if (status.ready) return '<span class="chip chip--interaction">Pronto para publicar</span>';
  if (status.configured) return '<span class="chip chip--warn">Configurado, mas o pacote está ausente</span>';
  return '<span class="chip">Não configurado</span>';
}

const envChip = '<span class="chip chip--warn" title="Este valor está sendo definido por variável de ambiente e ignora o que for salvo aqui.">env</span>';

function gcsCard(gcs) {
  const { config, envOverrides, status } = gcs;
  // Fora do admin, tudo fica so para leitura.
  const lock = (envLocked) => (envLocked || !isAdmin() ? 'disabled' : '');

  return `
    <div class="card">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px">
        <h3 style="font-size:16px">Google Cloud Storage</h3>
        <span id="gcs-status-chip">${statusChip(status)}</span>
      </div>
      <p class="field__hint" style="margin:0 0 16px">
        Destino do botão <strong>Exportar</strong> (contrato de coleta), da exportação do catálogo
        (<code>catalog/</code>) e do backup diário (<code>versions/</code>), e origem das importações do Storage.
        ${status.ready ? '' : status.reason ? `<br /><strong>${esc(status.reason)}</strong>` : ''}
      </p>
      ${adminNote()}

      <div class="grid-2" style="max-width:640px">
        <div class="field">
          <label class="field__label">Bucket ${envOverrides.bucket ? envChip : ''}</label>
          <input class="input input--mono" id="gcs-bucket" value="${esc(config.bucket)}"
                 placeholder="meu-bucket" ${lock(envOverrides.bucket)} />
        </div>
        <div class="field">
          <label class="field__label">Prefixo (pasta no bucket) ${envOverrides.prefix ? envChip : ''}</label>
          <input class="input input--mono" id="gcs-prefix" value="${esc(config.prefix)}"
                 placeholder="papyrus/" ${lock(envOverrides.prefix)} />
        </div>
      </div>

      <div class="grid-2" style="max-width:640px">
        <div class="field">
          <label class="field__label">Project ID (opcional) ${envOverrides.projectId ? envChip : ''}</label>
          <input class="input input--mono" id="gcs-project" value="${esc(config.projectId)}"
                 placeholder="meu-projeto-gcp" ${lock(envOverrides.projectId)} />
          <div class="field__hint">Se vazio, é lido da própria service account.</div>
        </div>
        <div class="field">
          <label class="field__label">
            Service account (JSON) ${envOverrides.keyFilename ? envChip : ''}
            ${hasKey(config, envOverrides) ? '<span class="chip chip--interaction">credencial salva ✓</span>' : ''}
          </label>
          <input class="input input--mono" type="password" id="gcs-keyjson" spellcheck="false"
                 autocomplete="off" ${lock(envOverrides.keyFilename)}
                 placeholder="${hasKey(config, envOverrides) ? 'Cole um novo JSON para substituir a credencial' : 'Cole aqui o conteúdo do JSON da service account'}" />
          <div class="field__hint">
            O conteúdo fica mascarado e nunca é exibido de volta: ele é validado e armazenado
            com segurança no servidor. A service account precisa do papel
            <strong>Storage Object User</strong> (<code>roles/storage.objectUser</code>) no bucket:
            ele lista, lê, grava e substitui arquivos, o que o backup diário e a importação precisam.
          </div>
        </div>
      </div>

      ${
        isAdmin()
          ? `<div style="display:flex;gap:8px;margin-top:6px;align-items:center;flex-wrap:wrap">
               <button class="btn btn--primary" id="gcs-save">Salvar configuração</button>
               <button class="btn btn--ghost" id="gcs-test">Testar conexão</button>
               ${hasKey(config, envOverrides) && !envOverrides.keyFilename
                 ? '<button class="btn btn--mini" id="gcs-remove-key" style="color:var(--danger)">Remover credencial</button>'
                 : ''}
               <span id="gcs-test-result" class="field__hint"></span>
             </div>`
          : '<span id="gcs-test-result" class="field__hint"></span>'
      }
      <p class="field__hint" style="margin:8px 0 0">
        "Testar conexão" valida os valores que estão nesta tela. Para que a exportação
        passe a usá-los, clique em <strong>Salvar configuração</strong>.
      </p>
    </div>`;
}

/** Existe credencial utilizável (salva pela UI ou definida via env)? */
const hasKey = (config, envOverrides) => Boolean(config.hasCredential) || envOverrides.keyFilename;

function bindGcsCard(body, gcs) {
  const value = (id) => body.querySelector(id)?.value?.trim() ?? '';
  const testResult = body.querySelector('#gcs-test-result');

  // Salvar sem testar e o erro mais comum, entao vale o aviso.
  if (!gcs.status.ready && gcs.status.configured) {
    testResult.textContent = gcs.status.reason || '';
  }
  if (!isAdmin()) return;

  body.querySelector('#gcs-save').onclick = async () => {
    try {
      const keyJson = value('#gcs-keyjson');
      const saved = await api.saveGcsSettings({
        bucket: value('#gcs-bucket'),
        prefix: value('#gcs-prefix'),
        projectId: value('#gcs-project'),
        // A credencial so viaja quando um JSON novo foi colado. Sem isso, a
        // que ja estava salva continua valendo no servidor.
        ...(keyJson ? { keyJson } : {}),
      });
      toast.ok('Configuração do Storage salva.');
      body.querySelector('#gcs-status-chip').innerHTML = statusChip(saved.status);
      // Re-renderiza para o estado passar a mostrar a credencial como salva.
      render();
    } catch (err) {
      toast.error(err.message);
    }
  };

  body.querySelector('#gcs-test').onclick = async () => {
    testResult.textContent = 'Testando…';
    try {
      // Testa o que esta na tela, e nao so o que ja foi salvo. Da para conferir
      // bucket e credencial antes de gravar a configuracao.
      const keyJson = value('#gcs-keyjson');
      const result = await api.testGcs({
        bucket: value('#gcs-bucket'),
        prefix: value('#gcs-prefix'),
        projectId: value('#gcs-project'),
        ...(keyJson ? { keyJson } : {}),
      });
      testResult.innerHTML = `<span style="color:var(--ok)">✓ Conectado ao bucket <code>${esc(result.bucket)}</code>.</span>`;
      toast.ok('Conexão com o GCS funcionando.');
    } catch (err) {
      testResult.innerHTML = `<span style="color:var(--danger)">${esc(err.message)}</span>`;
    }
  };

  body.querySelector('#gcs-remove-key')?.addEventListener('click', async () => {
    try {
      await api.saveGcsSettings({
        bucket: value('#gcs-bucket'),
        prefix: value('#gcs-prefix'),
        projectId: value('#gcs-project'),
        removeKey: true,
      });
      toast.ok('Credencial removida.');
      render();
    } catch (err) {
      toast.error(err.message);
    }
  });
}

/* Backup diario */

function lastRunLine(lastRun) {
  if (!lastRun) return '<span class="faint">Nenhum backup gravado ainda.</span>';
  const when = formatDate(lastRun.at);
  const how = lastRun.trigger === 'manual' ? 'manual' : 'agendado';
  if (lastRun.ok) {
    return `<span style="color:var(--ok)">✓</span> ${when} (${how}) · <code>${esc(lastRun.gsUri)}</code> ·
      ${lastRun.pages} página(s) de ${lastRun.workspaces} mapeamento(s) · ${formatBytes(lastRun.bytes)}`;
  }
  return `<span style="color:var(--danger)">Falhou em ${when} (${how}): ${esc(lastRun.error)}</span>
    <div class="field__hint">O Papyrus tenta de novo em 30 minutos.</div>`;
}

function backupCard(backup) {
  return `
    <div class="card" id="backup-card">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px">
        <h3 style="font-size:16px">Backup diário no bucket</h3>
        ${backup.enabled ? '<span class="chip chip--interaction">Ativo</span>' : '<span class="chip">Inativo</span>'}
      </div>
      <p class="field__hint" style="margin:0 0 14px">
        Todo dia às <strong>00h</strong> (${esc(backup.timezone)}) o Papyrus grava em
        <code>${esc(backup.folder)}AAAAMMDD.json</code> o estado atual de todos os mapeamentos: páginas completas,
        pastas, cores, catálogo e grupos de parâmetros. O arquivo de hoje seria <code>${esc(backup.todayKey)}.json</code>.
        Se o servidor estava desligado à meia-noite, o backup do dia roda assim que ele voltar.
        Para restaurar, use <strong>Importar → Do Google Cloud Storage</strong> na barra lateral.
        ${backup.enabled ? '' : `<br /><strong>${esc(backup.reason || '')}</strong>`}
      </p>
      <div class="backup-last">
        <span class="field__label">Último backup</span>
        <div id="backup-last">${lastRunLine(backup.lastRun)}</div>
      </div>
      ${
        isAdmin()
          ? `<div style="display:flex;gap:8px;margin-top:12px;align-items:center">
               <button class="btn btn--ghost" id="backup-run" ${backup.enabled ? '' : 'disabled'}>Fazer backup agora</button>
               <span class="field__hint">Usa o mesmo nome do dia: roda de novo e substitui o arquivo de hoje.</span>
             </div>`
          : ''
      }
      <p class="field__hint" style="margin:10px 0 0">
        Ficam de fora usuários, senhas e a credencial do Storage. As imagens coladas no canvas também não vão
        no JSON (a página guarda só o endereço delas): faça backup da pasta <code>papyrus/_assets</code> junto.
      </p>
    </div>`;
}

function bindBackupCard(body) {
  const run = body.querySelector('#backup-run');
  if (!run) return;

  run.onclick = async () => {
    run.disabled = true;
    run.textContent = 'Gravando…';
    try {
      const { lastRun } = await api.runBackup();
      body.querySelector('#backup-last').innerHTML = lastRunLine(lastRun);
      toast.ok(`Backup gravado em ${lastRun.gsUri}`, 5000);
    } catch (err) {
      toast.error(err.message, 6000);
      try {
        const status = await api.backupStatus();
        body.querySelector('#backup-last').innerHTML = lastRunLine(status.lastRun);
      } catch {
        /* o toast ja explicou */
      }
    } finally {
      run.disabled = false;
      run.textContent = 'Fazer backup agora';
    }
  };
}
