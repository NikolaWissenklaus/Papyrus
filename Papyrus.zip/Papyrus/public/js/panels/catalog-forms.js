/*
 * Dialogos do catalogo, usados pela aba Catalogo e pelo canvas.
 *
 *   openEventEditor   cria ou edita um evento e escolhe os parametros dele
 *   openParamEditor   cria ou edita um parametro
 *   openEventPicker   escolhe um evento para o card novo do canvas
 *   openEventDetails  ficha completa do evento, com onde ele esta mapeado
 *   openParamDetails  ficha do parametro, com os eventos que o usam
 *
 * A regra do catalogo e que parametro nasce solto e so entra em um evento
 * quando e escolhido no editor do evento. Por isso o editor do evento e
 * tambem o lugar onde se cria parametro novo, ou se traz um grupo inteiro.
 *
 * Toda gravacao devolve o catalogo inteiro e passa por setCatalog(), que
 * ressincroniza a pagina aberta no canvas.
 */

import {
  state, setCatalog, loadCatalog, flushSave, currentTool, getCatalogIndex, unlinkOpenDocCards,
} from '../store.js';
import { api } from '../api.js';
import {
  EVENT_TYPES, EVENT_TYPE_MAP, PARAM_TYPES, PARAM_SCOPES, PARAM_SCOPE_SHORT,
  GA4_ITEM_PARAMS, GA4_ECOMMERCE_EVENT_PARAMS,
} from '../constants.js';
import { esc, toSnakeCase, formatDate, plural } from '../util.js';
import { openModal, confirm } from '../ui/modal.js';
import { toast } from '../ui/toast.js';
import { normalizeKey } from '../../shared/rules.js';
import { paramKey, resolveEventParams, EVENT_ID_PARAM } from '../../shared/catalog-sync.js';

const SCOPES = ['eventParams', 'userParams', 'itemParams'];

/*
 * Uso de cada evento nos mapas ({ [eventId]: { cards, pages } }). Quem calcula
 * e o servidor, na consolidacao que a aba Catalogo carrega; os dialogos so
 * leem, para avisar "isto esta em 12 cards" antes de alguem mudar o evento.
 */
let usageCache = {};

export function setCatalogUsage(usage) {
  usageCache = usage || {};
}

export function usageOf(eventId) {
  return usageCache[eventId] || null;
}

/** Nome digitado ja no formato da ferramenta: snake_case no GA4, intacto nas demais. */
function normalizeTyped(value) {
  const trimmed = String(value || '').trim();
  return currentTool().rules === 'ga4' ? toSnakeCase(trimmed) : trimmed;
}

const typeChip = (eventType) => {
  const type = EVENT_TYPE_MAP[eventType] || EVENT_TYPE_MAP.interaction;
  return `<span class="chip chip--${type.id}">${esc(type.label)}</span>`;
};

function showFormError(node, message) {
  node.textContent = message;
  node.hidden = !message;
}

/**
 * Garante que os parametros existam no catalogo, criando os que faltam.
 * @param {Array<{ name, scope, type, required, example?, description? }>} defs
 * @returns {Promise<{ params: object[], created: number, errors: string[] }>}
 */
async function ensureCatalogParams(defs) {
  const params = [];
  const errors = [];
  let created = 0;
  let latest = null;

  for (const def of defs) {
    const name = normalizeTyped(def.name);
    if (!name || (def.scope === 'eventParams' && name === EVENT_ID_PARAM)) continue;

    const key = paramKey(def.scope, name);
    const existing = (latest || state.catalog).params.find((p) => paramKey(p.scope, p.name) === key);
    if (existing) {
      params.push(existing);
      continue;
    }
    try {
      const res = await api.createCatalogParam({
        name,
        scope: def.scope,
        type: PARAM_TYPES.includes(def.type) ? def.type : 'string',
        required: Boolean(def.required),
        example: def.example || '',
        description: def.description || '',
      });
      latest = res.catalog;
      params.push(res.param);
      created += 1;
    } catch (err) {
      errors.push(`${name}: ${err.message}`);
    }
  }

  if (latest) setCatalog(latest);
  return { params, created, errors };
}

/* Editor de evento */

/**
 * @param {{ event?: object, prefillName?: string }} [options]
 * @returns {Promise<object|null>} o evento gravado
 */
export async function openEventEditor({ event = null, prefillName = '' } = {}) {
  const tool = currentTool();
  const ga4 = tool.rules === 'ga4';
  const draft = {
    eventType: event?.eventType || 'interaction',
    params: (event?.params || []).map((ref) => ({ id: ref.id, required: Boolean(ref.required) })),
  };
  const usage = event ? usageOf(event.id) : null;

  return openModal({
    title: event ? 'Editar evento do catálogo' : 'Novo evento no catálogo',
    subtitle: event
      ? `As mudanças valem para todos os cards de "${event.name}".`
      : 'Dê nome e tipo ao evento e escolha os parâmetros que ele carrega. O event_id entra sozinho em todo card.',
    wide: true,
    body: `
      <div class="grid-2">
        <div class="field">
          <label class="field__label" for="ev-name">Nome do evento</label>
          <input class="input input--mono" id="ev-name" value="${esc(event?.name || normalizeTyped(prefillName))}"
                 placeholder="${ga4 ? 'add_to_cart' : 'AddToCart'}" autocomplete="off" />
          <div class="field__hint">${ga4 ? 'Padrão GA4: snake_case, até 40 caracteres.' : `Use o nome exato que o ${esc(tool.label)} espera.`}</div>
        </div>
        <div class="field">
          <label class="field__label" for="ev-type">Tipo</label>
          <select class="select" id="ev-type">
            ${EVENT_TYPES.map((t) => `<option value="${t.id}"${t.id === draft.eventType ? ' selected' : ''}>${t.label}</option>`).join('')}
          </select>
          <div class="field__hint">Define a cor da tarja do card no canvas.</div>
        </div>
      </div>
      <div class="field">
        <label class="field__label" for="ev-desc">Descrição</label>
        <textarea class="textarea" id="ev-desc" placeholder="Quando o evento dispara e o que ele mede.">${esc(event?.description || '')}</textarea>
      </div>

      <div class="picker-bar">
        <div class="picker-bar__title">
          <span class="field__label">Parâmetros do evento</span>
          <span class="chip" id="ev-count"></span>
        </div>
        <div class="picker-bar__actions">
          <input class="input input--search" id="ev-search" placeholder="Buscar parâmetro…" autocomplete="off" />
          <button type="button" class="btn btn--mini" id="ev-new-param">+ Criar parâmetro</button>
          <button type="button" class="btn btn--mini" id="ev-group" title="Seleciona todos os parâmetros de um grupo, criando no catálogo os que faltarem">Usar grupo</button>
          ${ga4 ? '<button type="button" class="btn btn--mini" id="ev-ga4" title="currency, value e os 18 parâmetros padrão de items[]">Padrão GA4 de ecommerce</button>' : ''}
        </div>
      </div>
      <div class="param-picker" id="ev-params"></div>
      <div class="field__hint" style="margin-top:8px">
        O <code>event_id</code> não aparece aqui porque é automático: todo card nasce com o seu, único.
      </div>
      <div class="form-error" id="ev-error" role="alert" hidden></div>`,
    footer: `
      ${usage?.cards ? `<span class="modal__note">Em uso em ${plural(usage.cards, 'card')} de ${plural(usage.pages.length, 'página')}.</span>` : ''}
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--primary" id="ev-save">${event ? 'Salvar evento' : 'Criar evento'}</button>`,
    onMount: (modal, close) => {
      const nameInput = modal.querySelector('#ev-name');
      const typeSelect = modal.querySelector('#ev-type');
      const descInput = modal.querySelector('#ev-desc');
      const search = modal.querySelector('#ev-search');
      const list = modal.querySelector('#ev-params');
      const count = modal.querySelector('#ev-count');
      const error = modal.querySelector('#ev-error');
      const saveBtn = modal.querySelector('#ev-save');

      const select = (param) => {
        if (param.scope === 'itemParams' && draft.eventType !== 'ecommerce') return false;
        if (!draft.params.some((ref) => ref.id === param.id)) draft.params.push({ id: param.id, required: Boolean(param.required) });
        return true;
      };

      function renderList() {
        const scrollTop = list.scrollTop;
        const q = normalizeKey(search.value);
        const chosen = new Map(draft.params.map((ref) => [ref.id, ref]));

        list.innerHTML = SCOPES.map((scope) => {
          const blocked = scope === 'itemParams' && draft.eventType !== 'ecommerce';
          const params = state.catalog.params
            .filter((p) => p.scope === scope)
            .filter((p) => !q || normalizeKey(p.name).includes(q) || normalizeKey(p.description).includes(q))
            .sort((a, b) => a.name.localeCompare(b.name));

          const rows = params
            .map((p) => {
              const ref = chosen.get(p.id);
              return `
                <div class="pick-row${ref ? ' is-selected' : ''}${blocked ? ' is-blocked' : ''}" data-param="${p.id}">
                  <label class="pick-row__main">
                    <input type="checkbox" ${ref ? 'checked' : ''} ${blocked ? 'disabled' : ''} />
                    <code class="pick-row__name">${esc(p.name)}</code>
                    <span class="chip">${esc(p.type)}</span>
                    ${p.description ? `<span class="pick-row__desc">${esc(p.description)}</span>` : ''}
                  </label>
                  ${ref ? `<button type="button" class="toggle" data-required aria-pressed="${ref.required}" title="Obrigatório neste evento?">${ref.required ? 'Obrig.' : 'Opc.'}</button>` : ''}
                </div>`;
            })
            .join('');

          return `
            <div class="param-picker__group">
              <div class="param-picker__scope">
                ${esc(PARAM_SCOPES[scope])}
                ${blocked ? '<span class="faint"> · só em eventos do tipo Ecommerce</span>' : ''}
              </div>
              ${rows || `<div class="param-picker__empty">${q ? 'Nada encontrado nesta busca.' : 'Nenhum parâmetro deste escopo no catálogo.'}</div>`}
            </div>`;
        }).join('');

        list.scrollTop = scrollTop;
        count.textContent = plural(draft.params.length, 'selecionado');

        list.querySelectorAll('.pick-row').forEach((row) => {
          const id = row.dataset.param;
          row.querySelector('input[type="checkbox"]').onchange = (e) => {
            if (e.target.checked) {
              const param = state.catalog.params.find((p) => p.id === id);
              if (param) select(param);
            } else {
              draft.params = draft.params.filter((ref) => ref.id !== id);
            }
            renderList();
          };
          const toggle = row.querySelector('[data-required]');
          if (toggle) {
            toggle.onclick = () => {
              const ref = draft.params.find((r) => r.id === id);
              if (!ref) return;
              ref.required = !ref.required;
              toggle.setAttribute('aria-pressed', String(ref.required));
              toggle.textContent = ref.required ? 'Obrig.' : 'Opc.';
            };
          }
        });
      }

      nameInput.onblur = () => {
        const normalized = normalizeTyped(nameInput.value);
        if (normalized !== nameInput.value) nameInput.value = normalized;
      };

      typeSelect.onchange = () => {
        draft.eventType = typeSelect.value;
        if (draft.eventType !== 'ecommerce') {
          const before = draft.params.length;
          const scopeOf = new Map(state.catalog.params.map((p) => [p.id, p.scope]));
          draft.params = draft.params.filter((ref) => scopeOf.get(ref.id) !== 'itemParams');
          if (draft.params.length < before) toast.info('Parâmetros de items[] removidos: eles só existem em eventos Ecommerce.');
        }
        renderList();
      };

      search.oninput = () => renderList();

      modal.querySelector('#ev-new-param').onclick = async () => {
        const typed = search.value.trim();
        const created = await openParamEditor({ prefill: { name: typed } });
        if (!created) return;
        search.value = '';
        if (!select(created)) toast.info(`"${created.name}" é de items[]: mude o tipo para Ecommerce para usá-lo.`);
        renderList();
      };

      modal.querySelector('#ev-group').onclick = async () => {
        const group = await pickGroup();
        if (!group) return;
        const defs = group.params.map((p) => ({ ...p, scope: group.scope || 'eventParams' }));
        const result = await ensureCatalogParams(defs);
        let skipped = 0;
        for (const param of result.params) if (!select(param)) skipped += 1;
        renderList();
        reportEnsure(result, skipped);
      };

      modal.querySelector('#ev-ga4')?.addEventListener('click', async () => {
        if (draft.eventType !== 'ecommerce') {
          draft.eventType = 'ecommerce';
          typeSelect.value = 'ecommerce';
        }
        const defs = [
          ...GA4_ECOMMERCE_EVENT_PARAMS.map((p) => ({ ...p, scope: 'eventParams' })),
          ...GA4_ITEM_PARAMS.map((p) => ({ ...p, scope: 'itemParams' })),
        ];
        const result = await ensureCatalogParams(defs);
        for (const param of result.params) select(param);
        renderList();
        reportEnsure(result, 0);
      });

      saveBtn.onclick = async () => {
        const payload = {
          name: normalizeTyped(nameInput.value),
          eventType: typeSelect.value,
          description: descInput.value.trim(),
          params: draft.params,
        };
        if (!payload.name) {
          showFormError(error, 'Dê um nome ao evento.');
          nameInput.focus();
          return;
        }

        saveBtn.disabled = true;
        try {
          // A edicao propaga para as paginas no disco. O que estiver pendente
          // no canvas precisa chegar antes, senao o auto-save seguinte grava a
          // versao antiga por cima.
          if (event) await flushSave();
          const res = event ? await api.updateCatalogEvent(event.id, payload) : await api.createCatalogEvent(payload);
          setCatalog(res.catalog);

          const synced = res.propagation?.cards || 0;
          toast.ok(
            event
              ? synced ? `Evento salvo · ${plural(synced, 'card sincronizado', 'cards sincronizados')}.` : 'Evento salvo.'
              : `Evento "${res.event.name}" criado no catálogo.`,
          );
          close(res.event);
        } catch (err) {
          showFormError(error, err.message);
          saveBtn.disabled = false;
        }
      };

      renderList();
      nameInput.focus();
      if (event) nameInput.select();
    },
  });
}

function reportEnsure(result, skipped) {
  const parts = [`${plural(result.params.length - skipped, 'parâmetro selecionado', 'parâmetros selecionados')}`];
  if (result.created) parts.push(`${result.created} criado(s) no catálogo`);
  if (skipped) parts.push(`${skipped} de items[] ignorado(s), o evento não é Ecommerce`);
  toast.ok(`${parts.join(' · ')}.`);
  if (result.errors.length) toast.error(`Não deu para criar: ${result.errors.join(' | ')}`, 8000);
}

/** Escolhe um Grupo de Parametros. */
function pickGroup() {
  const groups = state.templates || [];
  if (!groups.length) {
    toast.info('Nenhum grupo salvo ainda. Crie um na aba “Grupos de Parâmetros”.');
    return Promise.resolve(null);
  }

  return openModal({
    title: 'Usar um grupo de parâmetros',
    subtitle: 'Os parâmetros do grupo entram selecionados no evento. Os que ainda não existem no catálogo são criados.',
    body: `<div class="group-pick">
      ${groups
        .map(
          (g, i) => `
          <button type="button" class="group-pick__row" data-index="${i}">
            <strong>${esc(g.name)}</strong>
            <span class="faint"> · ${plural(g.params.length, 'parâmetro')} · ${esc(PARAM_SCOPE_SHORT[g.scope] || 'Evento')}</span>
            <span class="group-card__params" style="margin-top:6px">
              ${g.params.slice(0, 8).map((p) => `<span class="chip">${esc(p.name)}</span>`).join('')}
              ${g.params.length > 8 ? `<span class="chip">+${g.params.length - 8}</span>` : ''}
            </span>
          </button>`,
        )
        .join('')}
    </div>`,
    footer: '<button class="btn btn--ghost" data-close="null">Cancelar</button>',
    onMount: (modal, close) => {
      modal.querySelectorAll('[data-index]').forEach((btn) => {
        btn.onclick = () => close(groups[Number(btn.dataset.index)]);
      });
    },
  });
}

/* Editor de parametro */

/**
 * @param {{ param?: object, prefill?: object }} [options]
 * @returns {Promise<object|null>} o parametro gravado
 */
export async function openParamEditor({ param = null, prefill = {} } = {}) {
  const ga4 = currentTool().rules === 'ga4';
  const usedBy = param ? state.catalog.events.filter((e) => e.params.some((ref) => ref.id === param.id)) : [];
  const values = {
    name: param?.name ?? normalizeTyped(prefill.name || ''),
    scope: param?.scope ?? prefill.scope ?? 'eventParams',
    type: param?.type ?? prefill.type ?? 'string',
    required: Boolean(param?.required ?? prefill.required ?? false),
    description: param?.description ?? '',
    example: param?.example ?? '',
  };
  const scopeLocked = Boolean(param && usedBy.length);

  return openModal({
    title: param ? 'Editar parâmetro' : 'Novo parâmetro no catálogo',
    subtitle: param
      ? usedBy.length
        ? `Em ${plural(usedBy.length, 'evento')}: ${usedBy.map((e) => e.name).join(', ')}. As mudanças chegam a todos os cards desses eventos.`
        : 'Ainda não está em nenhum evento.'
      : 'Fica disponível no catálogo e entra em um evento quando for escolhido na criação ou na edição dele.',
    body: `
      <div class="grid-2">
        <div class="field">
          <label class="field__label" for="pa-name">Nome</label>
          <input class="input input--mono" id="pa-name" value="${esc(values.name)}" placeholder="${ga4 ? 'item_category' : 'content_ids'}" autocomplete="off" />
          <div class="field__hint">${ga4 ? 'snake_case, até 40 caracteres.' : 'Nome exato esperado pela ferramenta.'}</div>
        </div>
        <div class="field">
          <label class="field__label" for="pa-scope">Escopo</label>
          <select class="select" id="pa-scope" ${scopeLocked ? 'disabled' : ''}>
            ${SCOPES.map((s) => `<option value="${s}"${s === values.scope ? ' selected' : ''}>${esc(PARAM_SCOPES[s])}</option>`).join('')}
          </select>
          ${scopeLocked ? '<div class="field__hint">O escopo não muda enquanto o parâmetro estiver em eventos.</div>' : ''}
        </div>
      </div>
      <div class="grid-2">
        <div class="field">
          <label class="field__label" for="pa-type">Tipo de dado</label>
          <select class="select" id="pa-type">
            ${PARAM_TYPES.map((t) => `<option value="${t}"${t === values.type ? ' selected' : ''}>${t}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label class="field__label">Padrão ao escolher</label>
          <div class="pill-group" id="pa-required">
            <button type="button" class="pill" data-required="true" aria-pressed="${values.required}">Obrigatório</button>
            <button type="button" class="pill" data-required="false" aria-pressed="${!values.required}">Opcional</button>
          </div>
          <div class="field__hint">É só a sugestão: cada evento decide se o parâmetro é obrigatório nele.</div>
        </div>
      </div>
      <div class="field">
        <label class="field__label" for="pa-desc">Descrição</label>
        <textarea class="textarea" id="pa-desc" placeholder="O que o parâmetro carrega e de onde vem o valor.">${esc(values.description)}</textarea>
      </div>
      <div class="field">
        <label class="field__label" for="pa-example">Valor de exemplo</label>
        <input class="input" id="pa-example" value="${esc(values.example)}" placeholder="ex.: BRL" autocomplete="off" />
        <div class="field__hint">Entra como exemplo inicial nos cards novos; em cada card ele pode ser trocado.</div>
      </div>
      <div class="form-error" id="pa-error" role="alert" hidden></div>`,
    footer: `
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--primary" id="pa-save">${param ? 'Salvar parâmetro' : 'Criar parâmetro'}</button>`,
    onMount: (modal, close) => {
      const nameInput = modal.querySelector('#pa-name');
      const error = modal.querySelector('#pa-error');
      const saveBtn = modal.querySelector('#pa-save');
      let required = values.required;

      modal.querySelectorAll('#pa-required [data-required]').forEach((btn) => {
        btn.onclick = () => {
          required = btn.dataset.required === 'true';
          modal.querySelectorAll('#pa-required [data-required]').forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
        };
      });

      nameInput.onblur = () => {
        const normalized = normalizeTyped(nameInput.value);
        if (normalized !== nameInput.value) nameInput.value = normalized;
      };

      const submit = async () => {
        const payload = {
          name: normalizeTyped(nameInput.value),
          scope: modal.querySelector('#pa-scope').value,
          type: modal.querySelector('#pa-type').value,
          required,
          description: modal.querySelector('#pa-desc').value.trim(),
          example: modal.querySelector('#pa-example').value.trim(),
        };
        if (!payload.name) {
          showFormError(error, 'Dê um nome ao parâmetro.');
          nameInput.focus();
          return;
        }

        saveBtn.disabled = true;
        try {
          if (param) await flushSave();
          const res = param ? await api.updateCatalogParam(param.id, payload) : await api.createCatalogParam(payload);
          setCatalog(res.catalog);
          const synced = res.propagation?.cards || 0;
          toast.ok(
            param
              ? synced ? `Parâmetro salvo · ${plural(synced, 'card sincronizado', 'cards sincronizados')}.` : 'Parâmetro salvo.'
              : `Parâmetro "${res.param.name}" criado no catálogo.`,
          );
          close(res.param);
        } catch (err) {
          showFormError(error, err.message);
          saveBtn.disabled = false;
        }
      };

      nameInput.onkeydown = (e) => {
        if (e.key === 'Enter') submit();
      };
      saveBtn.onclick = submit;
      nameInput.focus();
    },
  });
}

/* Seletor de evento (canvas) */

/**
 * @param {{ title?: string, subtitle?: string, currentId?: string }} [options]
 * @returns {Promise<object|null>} evento do catalogo escolhido
 */
export async function openEventPicker({ title = 'Escolher evento do catálogo', subtitle = '', currentId = null } = {}) {
  try {
    await loadCatalog();
  } catch {
    /* sem rede, vale o catalogo que ja esta na memoria */
  }

  return openModal({
    title,
    subtitle,
    wide: true,
    body: `
      <input class="input input--search" id="pk-search" placeholder="Buscar evento pelo nome, tipo ou descrição…" autocomplete="off" />
      <div class="event-pick" id="pk-list" role="listbox"></div>`,
    footer: `
      <button class="btn btn--ghost" id="pk-new" style="margin-right:auto">+ Novo evento no catálogo</button>
      <button class="btn btn--ghost" data-close="null">Cancelar</button>`,
    onMount: (modal, close) => {
      const search = modal.querySelector('#pk-search');
      const list = modal.querySelector('#pk-list');
      let active = 0;
      let rows = [];

      const createNew = async () => {
        const created = await openEventEditor({ prefillName: search.value });
        if (created) close(created);
      };

      function render() {
        const q = normalizeKey(search.value);
        rows = [...state.catalog.events]
          .filter((e) => {
            if (!q) return true;
            const type = EVENT_TYPE_MAP[e.eventType]?.label || '';
            return [e.name, e.description, type].some((text) => normalizeKey(text).includes(q));
          })
          .sort((a, b) => a.name.localeCompare(b.name));
        active = Math.min(active, Math.max(rows.length - 1, 0));

        if (!state.catalog.events.length) {
          list.innerHTML = `
            <div class="event-pick__empty">
              <strong>O catálogo deste mapeamento ainda não tem eventos.</strong>
              <p>Todo card nasce de um evento do catálogo. Crie o primeiro e ele já entra no canvas.</p>
              <button class="btn btn--primary" data-create>Criar o primeiro evento</button>
            </div>`;
        } else if (!rows.length) {
          list.innerHTML = `
            <div class="event-pick__empty">
              <strong>Nenhum evento com "${esc(search.value.trim())}".</strong>
              <button class="btn btn--ghost" data-create>Criar "${esc(normalizeTyped(search.value))}" no catálogo</button>
            </div>`;
        } else {
          list.innerHTML = rows
            .map((e, i) => {
              const usage = usageOf(e.id);
              return `
                <button type="button" class="event-pick__row${i === active ? ' is-active' : ''}${e.id === currentId ? ' is-current' : ''}" data-index="${i}" role="option">
                  ${typeChip(e.eventType)}
                  <span class="event-pick__body">
                    <code class="event-pick__name">${esc(e.name)}</code>
                    ${e.description ? `<span class="event-pick__desc">${esc(e.description)}</span>` : ''}
                  </span>
                  <span class="event-pick__meta">
                    ${plural(e.params.length, 'parâmetro')}${usage ? ` · ${plural(usage.cards, 'card')}` : ''}${e.id === currentId ? ' · atual' : ''}
                  </span>
                </button>`;
            })
            .join('');
        }

        list.querySelectorAll('[data-index]').forEach((row) => {
          row.onclick = () => close(rows[Number(row.dataset.index)]);
        });
        list.querySelector('[data-create]')?.addEventListener('click', createNew);
      }

      search.oninput = () => {
        active = 0;
        render();
      };
      search.onkeydown = (e) => {
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
          e.preventDefault();
          if (!rows.length) return;
          active = (active + (e.key === 'ArrowDown' ? 1 : -1) + rows.length) % rows.length;
          render();
          list.querySelector('.is-active')?.scrollIntoView({ block: 'nearest' });
        }
        if (e.key === 'Enter' && rows[active]) close(rows[active]);
      };
      modal.querySelector('#pk-new').onclick = createNew;

      render();
      search.focus();
    },
  });
}

/* Fichas */

const go = (detail) => window.dispatchEvent(new CustomEvent('papyrus:goto', { detail }));

/** Exclui o evento do catalogo, avisando onde ele esta em uso. */
export async function deleteCatalogEvent(event) {
  const usage = usageOf(event.id);
  const ok = await confirm({
    title: 'Excluir evento do catálogo',
    message: usage?.cards
      ? `"${event.name}" está em ${plural(usage.cards, 'card')} de ${plural(usage.pages.length, 'página')}. Os cards continuam no canvas, com o conteúdo atual, mas ficam fora do catálogo. Excluir mesmo assim?`
      : `Excluir "${event.name}" do catálogo? Ele ainda não está em nenhum card.`,
  });
  if (!ok) return false;

  try {
    await flushSave();
    const res = await api.deleteCatalogEvent(event.id);
    setCatalog(res.catalog, { resync: false });
    unlinkOpenDocCards([event.id]);
    toast.ok(res.unlinked?.cards ? `Evento excluído · ${plural(res.unlinked.cards, 'card ficou', 'cards ficaram')} fora do catálogo.` : 'Evento excluído.');
    window.dispatchEvent(new CustomEvent('papyrus:catalog-changed'));
    return true;
  } catch (err) {
    toast.error(err.message);
    return false;
  }
}

/** Exclui o parametro. O servidor recusa se ele estiver em algum evento. */
export async function deleteCatalogParam(param) {
  const ok = await confirm({ title: 'Excluir parâmetro', message: `Excluir "${param.name}" do catálogo?` });
  if (!ok) return false;
  try {
    const res = await api.deleteCatalogParam(param.id);
    setCatalog(res.catalog);
    toast.ok('Parâmetro excluído.');
    return true;
  } catch (err) {
    toast.error(err.message, 7000);
    return false;
  }
}

/** Ficha completa do evento: parametros por extenso e onde ele esta mapeado. */
export function openEventDetails(eventId) {
  const event = state.catalog.events.find((e) => e.id === eventId);
  if (!event) {
    toast.error('Evento não encontrado no catálogo.');
    return null;
  }

  const resolved = resolveEventParams(event, getCatalogIndex());
  const usage = usageOf(event.id);
  const rows = SCOPES.flatMap((scope) => resolved[scope].map(({ def, required }) => ({ def, required, scope })));

  return openModal({
    title: event.name,
    subtitle: event.description || 'Sem descrição.',
    wide: true,
    body: `
      <div class="detail-meta">
        ${typeChip(event.eventType)}
        <span class="chip">${plural(rows.length + 1, 'parâmetro')}</span>
        <span class="chip${usage ? ' chip--interaction' : ''}">${usage ? `${plural(usage.cards, 'card')} em ${plural(usage.pages.length, 'página')}` : 'Ainda não usado nos mapas'}</span>
      </div>
      <div class="detail-grid">
        <div><span class="field__label">Criado</span>${formatDate(event.createdAt)}${event.createdBy ? ` · ${esc(event.createdBy)}` : ''}</div>
        <div><span class="field__label">Atualizado</span>${formatDate(event.updatedAt)}${event.updatedBy ? ` · ${esc(event.updatedBy)}` : ''}</div>
      </div>

      <h4 class="detail-title">Parâmetros</h4>
      <div class="table-scroll" style="max-height:320px">
        <table class="table">
          <thead><tr><th>Escopo</th><th>Parâmetro</th><th>Tipo</th><th>Obrig.</th><th>Descrição</th><th>Exemplo</th></tr></thead>
          <tbody>
            <tr>
              <td><span class="chip">Evento</span></td><td><code>${EVENT_ID_PARAM}</code></td><td>string</td><td>sim</td>
              <td class="muted">Automático e único em cada card.</td><td class="faint">gerado</td>
            </tr>
            ${rows
              .map(
                ({ def, required, scope }) => `
                <tr>
                  <td><span class="chip">${esc(PARAM_SCOPE_SHORT[scope])}</span></td>
                  <td><code>${esc(def.name)}</code></td>
                  <td>${esc(def.type)}</td>
                  <td>${required ? 'sim' : 'não'}</td>
                  <td class="muted">${esc(def.description || '—')}</td>
                  <td class="faint"><code>${esc(def.example || '—')}</code></td>
                </tr>`,
              )
              .join('')}
          </tbody>
        </table>
      </div>

      <h4 class="detail-title">Onde está mapeado</h4>
      ${
        usage
          ? `<div class="usage-list">${usage.pages
              .map(
                (p) => `<div class="usage-row">
                  <span class="usage-row__name">${esc(p.name)}</span>
                  <span class="faint">${esc(p.path)}</span>
                  <span class="chip">${plural(p.count, 'card')}</span>
                  <button class="btn btn--mini" data-open="${esc(p.path)}">Abrir</button>
                </div>`,
              )
              .join('')}</div>`
          : '<p class="field__hint">Nenhum card usa este evento ainda. Crie um no canvas com a ferramenta Card de Evento (E).</p>'
      }`,
    footer: `
      <button class="btn btn--ghost" id="ed-delete" style="margin-right:auto;color:var(--danger)">Excluir</button>
      <button class="btn btn--ghost" data-close="null">Fechar</button>
      <button class="btn btn--primary" id="ed-edit">Editar evento</button>`,
    onMount: (modal, close) => {
      modal.querySelectorAll('[data-open]').forEach((btn) => {
        btn.onclick = () => {
          close(null);
          go({ path: btn.dataset.open, catalogEventId: event.id });
        };
      });
      modal.querySelector('#ed-edit').onclick = async () => {
        close(null);
        await openEventEditor({ event });
        window.dispatchEvent(new CustomEvent('papyrus:catalog-changed'));
      };
      modal.querySelector('#ed-delete').onclick = async () => {
        if (await deleteCatalogEvent(event)) close(null);
      };
    },
  });
}

/** Ficha do parametro, com os eventos que o carregam. */
export function openParamDetails(paramId) {
  const param = state.catalog.params.find((p) => p.id === paramId);
  if (!param) {
    toast.error('Parâmetro não encontrado no catálogo.');
    return null;
  }
  const usedBy = state.catalog.events.filter((e) => e.params.some((ref) => ref.id === param.id));

  return openModal({
    title: param.name,
    subtitle: param.description || 'Sem descrição.',
    body: `
      <div class="detail-meta">
        <span class="chip">${esc(PARAM_SCOPES[param.scope])}</span>
        <span class="chip">${esc(param.type)}</span>
        <span class="chip">${param.required ? 'Obrigatório por padrão' : 'Opcional por padrão'}</span>
      </div>
      <div class="detail-grid">
        <div><span class="field__label">Exemplo</span><code>${esc(param.example || '—')}</code></div>
        <div><span class="field__label">Atualizado</span>${formatDate(param.updatedAt)}${param.updatedBy ? ` · ${esc(param.updatedBy)}` : ''}</div>
      </div>
      <h4 class="detail-title">Eventos associados</h4>
      ${
        usedBy.length
          ? `<div class="chip-cloud">${usedBy
              .map((e) => {
                const ref = e.params.find((r) => r.id === param.id);
                return `<button class="chip chip--button" data-event="${e.id}" title="${ref?.required ? 'obrigatório' : 'opcional'} neste evento">${esc(e.name)}${ref?.required ? ' *' : ''}</button>`;
              })
              .join('')}</div>
             <p class="field__hint">* obrigatório no evento.</p>`
          : '<p class="field__hint">Ainda não está em nenhum evento. Ele entra em um evento quando for escolhido no editor do evento.</p>'
      }`,
    footer: `
      <button class="btn btn--ghost" id="pd-delete" style="margin-right:auto;color:var(--danger)" ${usedBy.length ? 'disabled title="Remova o parâmetro dos eventos antes de excluir"' : ''}>Excluir</button>
      <button class="btn btn--ghost" data-close="null">Fechar</button>
      <button class="btn btn--primary" id="pd-edit">Editar parâmetro</button>`,
    onMount: (modal, close) => {
      modal.querySelectorAll('[data-event]').forEach((btn) => {
        btn.onclick = () => {
          close(null);
          openEventDetails(btn.dataset.event);
        };
      });
      modal.querySelector('#pd-edit').onclick = async () => {
        close(null);
        await openParamEditor({ param });
        window.dispatchEvent(new CustomEvent('papyrus:catalog-changed'));
      };
      modal.querySelector('#pd-delete').onclick = async () => {
        if (await deleteCatalogParam(param)) {
          close(null);
          window.dispatchEvent(new CustomEvent('papyrus:catalog-changed'));
        }
      };
    },
  });
}
