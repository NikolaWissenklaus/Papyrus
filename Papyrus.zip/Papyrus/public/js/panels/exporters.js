/*
 * As duas saidas da ferramenta, com destinos propositalmente diferentes.
 *
 * "Exportar" gera um JSON so com regra de negocio: o nome da pagina como chave
 * raiz e um array de eventos tipados como valor. Coordenada, cor e elemento
 * visual ficam de fora. O nome basta como chave porque o workspace recusa nome
 * repetido, entao duas paginas nunca disputam a mesma chave. O escopo e sempre o workspace inteiro, nunca uma pagina
 * isolada, porque o arquivo precisa valer como retrato completo da coleta. Ele
 * vai direto para o bucket do Google Cloud Storage, ja que o contrato de coleta
 * precisa de um endereco unico. Download solto na maquina de quem exportou vira
 * copia divergente em uma semana.
 *
 * "Tirar foto" gera PNG, JPG ou PDF do canvas, sempre pelo navegador. E
 * material de apresentacao e de conversa: tem vida curta e nao precisa ser
 * versionado.
 */

import { api } from '../api.js';
import { state, flushSave, getValidationContext } from '../store.js';
import { esc, downloadBlob, loadImage, formatDate } from '../util.js';
import { openModal } from '../ui/modal.js';
import { toast } from '../ui/toast.js';
import { exportCanvasImage } from '../canvas/stage.js';
import { validateDoc } from '../quality/validation.js';
import { EVENT_ID_PARAM } from '../models.js';
import { isDarkColor } from '../constants.js';
import { PDF_PAGE_FORMATS, pdfLayout, buildImagePdf } from '../pdf.js';
import { getExportDefaults } from './settings.js';

/**
 * Nome sugerido do arquivo. O export cobre o mapeamento inteiro, sempre. O GA4
 * continua com o nome de antes, para quem ja le `papyrus.json` no bucket; os
 * outros mapeamentos ganham o proprio, senao um sobrescreveria o outro.
 */
const defaultFilename = () =>
  !state.workspace || state.workspace.isDefault ? 'papyrus' : `papyrus-${state.workspace.id}`;

/** Consulta o status do GCS sem quebrar a UI se o servidor falhar. */
async function safeGcsStatus() {
  try {
    return await api.gcsStatus();
  } catch {
    return { configured: false, ready: false, reason: null };
  }
}

/* Foto do canvas (PNG / JPG / PDF) */

/**
 * Faixa de cabecalho do PDF: nome da pagina, mapeamento e data, desenhados
 * na propria imagem. O PDF continua sendo so uma imagem, o que mantem o
 * gerador pequeno e o resultado identico ao que se ve no canvas.
 */
async function composeWithHeader(dataUrl, { ratio, title, subtitle, background }) {
  const img = await loadImage(dataUrl);
  const header = Math.round(68 * ratio);
  // O navegador recusa canvas muito grande; sem espaco, o cabecalho fica de fora.
  if (img.height + header > 16000) return null;

  const canvas = document.createElement('canvas');
  canvas.width = img.width;
  canvas.height = img.height + header;
  const g = canvas.getContext('2d');
  const dark = isDarkColor(background);

  g.fillStyle = background || '#FFFFFF';
  g.fillRect(0, 0, canvas.width, canvas.height);

  const left = Math.round(28 * ratio);
  g.textBaseline = 'alphabetic';
  g.fillStyle = dark ? '#E8EAED' : '#202124';
  g.font = `500 ${Math.round(20 * ratio)}px Roboto, "Helvetica Neue", Arial, sans-serif`;
  g.fillText(title, left, Math.round(34 * ratio));
  g.fillStyle = dark ? '#9AA0A6' : '#5F6368';
  g.font = `${Math.round(12 * ratio)}px Roboto, "Helvetica Neue", Arial, sans-serif`;
  g.fillText(subtitle, left, Math.round(54 * ratio));
  g.fillStyle = dark ? 'rgba(255,255,255,0.14)' : '#E8EAED';
  g.fillRect(left, header - Math.max(1, Math.round(ratio)), canvas.width - left * 2, Math.max(1, Math.round(ratio)));

  g.drawImage(img, 0, header);
  return canvas;
}

function canvasToJpegBytes(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      async (blob) => {
        if (!blob) return reject(new Error('O navegador não conseguiu gerar a imagem.'));
        resolve(new Uint8Array(await blob.arrayBuffer()));
      },
      'image/jpeg',
      0.92,
    );
  });
}

/** Monta e baixa o PDF a partir da imagem exportada do canvas. */
async function downloadPdf(image, options) {
  const background = options.background === 'transparent' ? '#FFFFFF' : options.background;
  const title = state.doc.name || 'Página';
  const subtitle = [state.workspace?.name, formatDate(new Date().toISOString()), 'Papyrus'].filter(Boolean).join(' · ');

  let canvas = options.header
    ? await composeWithHeader(image.dataUrl, { ratio: image.ratio, title, subtitle, background })
    : null;

  if (!canvas) {
    const img = await loadImage(image.dataUrl);
    canvas = document.createElement('canvas');
    canvas.width = img.width;
    canvas.height = img.height;
    canvas.getContext('2d').drawImage(img, 0, 0);
  }

  const jpeg = await canvasToJpegBytes(canvas);
  const layout = pdfLayout({
    format: options.pageFormat,
    imageWidth: canvas.width,
    imageHeight: canvas.height,
    ratio: image.ratio,
  });
  const bytes = buildImagePdf({
    jpeg,
    imageWidth: canvas.width,
    imageHeight: canvas.height,
    title: `${title}${state.workspace ? ` · ${state.workspace.name}` : ''}`,
    ...layout,
  });

  downloadBlob(new Blob([bytes], { type: 'application/pdf' }), `${sanitize(state.doc.name)}.pdf`);
}

export async function takeCanvasPhoto() {
  if (!state.doc) {
    toast.error('Abra uma página antes de tirar a foto.');
    return;
  }

  const hasSelection = state.selection.length > 0;

  // Pre-preenche com os padroes definidos na aba Configuracoes.
  const def = getExportDefaults();
  // Pagina com fundo proprio ja abre com ele escolhido: o conteudo foi montado
  // para aquela cor, e sobre branco poderia ficar ilegivel.
  const pageBg = state.doc.background || '';
  if (pageBg) def.background = pageBg;
  const sel = (value, current) => (String(value) === String(current) ? ' selected' : '');

  const options = await openModal({
    title: 'Foto ou PDF do canvas',
    subtitle: 'A imagem é recortada no conteúdo, sem áreas vazias sobrando.',
    body: `
      <div class="grid-2">
        <div class="field">
          <label class="field__label">Formato</label>
          <select class="select" id="png-format">
            <option value="png"${sel('png', def.format)}>PNG (sem perdas)</option>
            <option value="jpeg"${sel('jpeg', def.format)}>JPG (arquivo menor)</option>
            <option value="pdf"${sel('pdf', def.format)}>PDF (documento)</option>
          </select>
        </div>
        <div class="field">
          <label class="field__label">Resolução</label>
          <select class="select" id="png-scale">
            <option value="2"${sel(2, def.scale)}>2× (apresentação)</option>
            <option value="3"${sel(3, def.scale)}>3× (alta resolução, recomendado)</option>
            <option value="4"${sel(4, def.scale)}>4× (impressão)</option>
          </select>
        </div>
      </div>
      <div class="grid-2">
        <div class="field">
          <label class="field__label">Fundo</label>
          <select class="select" id="png-bg">
            ${pageBg ? `<option value="${esc(pageBg)}" selected>Cor do canvas</option>` : ''}
            <option value="#FFFFFF"${sel('#FFFFFF', def.background)}>Branco</option>
            <option value="#F8F9FA"${sel('#F8F9FA', def.background)}>Cinza claro</option>
            <option value="#202124"${sel('#202124', def.background)}>Preto</option>
            <option value="transparent"${sel('transparent', def.background)}>Transparente (só PNG)</option>
          </select>
        </div>
        <div class="field">
          <label class="field__label">Margem (px)</label>
          <input class="input" type="number" id="png-pad" value="${Number(def.padding) || 0}" min="0" max="300" />
        </div>
      </div>
      <div class="grid-2" id="pdf-options" hidden>
        <div class="field">
          <label class="field__label">Página do PDF</label>
          <select class="select" id="pdf-page">
            ${PDF_PAGE_FORMATS.map((f) => `<option value="${f.id}"${sel(f.id, def.pdfPage || 'fit')}>${esc(f.label)}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label class="field__label">Cabeçalho</label>
          <label class="check"><input type="checkbox" id="pdf-header" ${def.pdfHeader === false ? '' : 'checked'} /> Nome da página, mapeamento e data</label>
        </div>
      </div>
      ${
        hasSelection
          ? `<label class="check"><input type="checkbox" id="png-selection" />
               Exportar apenas a seleção atual (${state.selection.length} elemento(s))</label>`
          : ''
      }
      <div class="field__hint" style="margin-top:10px">O arquivo é baixado pelo navegador.</div>`,
    footer: `
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--primary" id="png-go">Tirar foto</button>`,
    // Os valores tem de ser lidos antes de fechar o modal: depois do close() o
    // DOM do dialogo ja nao existe.
    onMount: (modal, close) => {
      const formatSelect = modal.querySelector('#png-format');
      const bgSelect = modal.querySelector('#png-bg');
      const go = modal.querySelector('#png-go');

      // JPG e PDF nao tem canal alfa, e fundo transparente sairia preto.
      formatSelect.onchange = () => {
        const opaque = formatSelect.value !== 'png';
        const transparentOption = bgSelect.querySelector('option[value="transparent"]');
        transparentOption.disabled = opaque;
        if (opaque && bgSelect.value === 'transparent') bgSelect.value = '#FFFFFF';
        modal.querySelector('#pdf-options').hidden = formatSelect.value !== 'pdf';
        go.textContent = formatSelect.value === 'pdf' ? 'Gerar PDF' : 'Tirar foto';
      };
      // Vale tambem para o estado inicial, ja que o padrao pode vir como JPG.
      formatSelect.onchange();

      go.onclick = () =>
        close({
          scale: Number(modal.querySelector('#png-scale').value) || 3,
          format: formatSelect.value,
          background: bgSelect.value,
          padding: Number(modal.querySelector('#png-pad').value) || 0,
          onlySelection: Boolean(modal.querySelector('#png-selection')?.checked),
          pageFormat: modal.querySelector('#pdf-page').value,
          header: modal.querySelector('#pdf-header').checked,
        });
    },
  });

  if (!options) return;

  const isPdf = options.format === 'pdf';
  const opaque = options.format !== 'png';
  const image = exportCanvasImage({
    pixelRatio: options.scale,
    padding: options.padding,
    background: options.background === 'transparent' ? (opaque ? '#FFFFFF' : null) : options.background,
    // O PDF recebe JPEG: e o formato que ele embute sem recompressao.
    mimeType: options.format === 'png' ? 'image/png' : 'image/jpeg',
    quality: 0.92,
    onlySelection: options.onlySelection,
    // Para o PDF sobra espaco para o cabecalho dentro do limite do navegador.
    maxSide: isPdf ? 14000 : 16000,
  });
  if (!image) return;

  try {
    if (isPdf) {
      await downloadPdf(image, options);
      toast.ok('PDF gerado.');
      return;
    }
    const filename = `${sanitize(state.doc.name)}-${options.scale}x.${options.format === 'jpeg' ? 'jpg' : 'png'}`;
    const blob = await (await fetch(image.dataUrl)).blob();
    downloadBlob(blob, filename);
    toast.ok('Foto salva.');
  } catch (err) {
    toast.error(`Falha ao gerar o arquivo: ${err.message}`);
  }
}

/* Exportar: JSON de eventos para o Google Cloud Storage */

/** Caminho de toda pagina valida da arvore, em profundidade. */
function allPagePaths(nodes = state.tree || [], out = []) {
  for (const node of nodes) {
    if (node.type === 'folder') allPagePaths(node.children || [], out);
    else if (!node.invalid) out.push(node.path);
  }
  return out;
}

/*
 * Audita o mapeamento inteiro antes de liberar o export.
 *
 * O validador do rodape roda so na pagina aberta, e o arquivo exportado cobre
 * todas. Entao aqui as paginas sao lidas do disco e validadas uma a uma, e no
 * fim vem a checagem que nenhuma delas conseguiria fazer sozinha: event_id
 * repetido entre paginas diferentes.
 *
 * Bloqueia por erro, nao por aviso. Aviso e coisa de mapa em andamento (sem
 * squad, sem gatilho descrito, card fora do catalogo) e travar por isso
 * deixaria o export inalcancavel.
 */
async function auditWorkspace() {
  const docs = await Promise.all(
    allPagePaths().map(async (path) => {
      const { doc } = await api.readPage(path);
      return { path, name: doc?.name || path, doc };
    }),
  );

  const blockers = [];
  const context = getValidationContext();

  for (const { name, doc } of docs) {
    for (const issue of validateDoc(doc, context).issues) {
      if (issue.level !== 'error') continue;
      blockers.push({ page: name, where: issue.where, message: issue.message });
    }
  }

  const byEventId = new Map();
  for (const { name, doc } of docs) {
    for (const el of doc?.elements || []) {
      if (el.type !== 'event') continue;
      const id = ((el.data?.eventParams || []).find((p) => p.name === EVENT_ID_PARAM)?.example || '').trim();
      if (!id) continue;
      if (!byEventId.has(id)) byEventId.set(id, []);
      byEventId.get(id).push({ page: name, event: el.data?.name || '(sem nome)' });
    }
  }

  for (const [id, uses] of byEventId) {
    // Colisao dentro de uma pagina so o validador ja apontou acima.
    const pages = new Set(uses.map((u) => u.page));
    if (uses.length < 2 || pages.size < 2) continue;
    blockers.push({
      page: [...pages].join(', '),
      where: uses.map((u) => u.event).join(', '),
      message: `event_id "${id}" repetido em mais de uma página.`,
    });
  }

  return blockers;
}

/**
 * O escopo e sempre o mapeamento inteiro. Exportar uma pagina isolada produzia
 * contratos parciais circulando em paralelo, cada um dizendo uma coisa; o
 * arquivo no bucket precisa valer como retrato completo da coleta.
 */
export async function exportEvents() {
  await flushSave();

  const [blockers, gcs] = await Promise.all([auditWorkspace(), safeGcsStatus()]);
  const blocked = blockers.length > 0;

  const result = await openModal({
    title: 'Exportar',
    subtitle: 'JSON com as regras de negócio: sem coordenadas, cores ou elementos visuais.',
    wide: true,
    body: `
      ${
        blocked
          ? `<div class="card" style="border-color:#FAD2CF;background:var(--danger-bg);margin-bottom:14px;padding:12px 16px">
               <strong style="color:var(--danger);font-size:13px">
                 ${blockers.length} problema(s) impedem a exportação
               </strong>
               <div class="field__hint" style="margin:2px 0 10px">
                 O arquivo é o contrato de coleta do mapeamento inteiro. Corrija os itens abaixo e tente de novo.
               </div>
               <div style="display:flex;flex-direction:column;gap:5px;max-height:190px;overflow:auto">
                 ${blockers
                   .map(
                     (b) => `<div style="font-size:12px">
                       <code>${esc(b.page)}</code>
                       ${b.where ? `<span class="faint">· ${esc(b.where)}</span>` : ''}
                       <div class="faint">${esc(b.message)}</div>
                     </div>`,
                   )
                   .join('')}
               </div>
             </div>`
          : ''
      }

      <div class="field">
        <label class="field__label">Escopo</label>
        <div class="field__hint">
          Todo o mapeamento <strong>${esc(state.workspace?.name || '')}</strong>: todas as páginas dele, e não apenas a que está aberta.
          Os cards saem com a definição atual do catálogo.
        </div>
      </div>

      <div class="field">
        <label class="field__label">Nome do arquivo</label>
        <input class="input input--mono" id="tf-name" value="${esc(defaultFilename())}" />
      </div>

      <div class="field">
        <label class="field__label">Destino</label>
        <div class="card" style="padding:12px 16px">
          <strong style="font-size:13px">Google Cloud Storage</strong>
          ${
            gcs.ready
              ? `<div class="field__hint" style="margin-top:2px">Bucket: <code>${esc(gcs.bucket)}</code>${
                  gcs.prefix ? ` · prefixo <code>${esc(gcs.prefix)}</code>` : ''
                }</div>`
              : `<div class="field__hint" style="margin-top:2px;color:var(--warn)">${esc(
                  gcs.reason || 'Não configurado.',
                )}</div>`
          }
        </div>
      </div>

      <details style="margin-top:14px">
        <summary style="cursor:pointer;font-size:12px;color:var(--text-muted)">Ver estrutura gerada</summary>
        <pre class="code" style="margin-top:8px;max-height:220px">${esc(SAMPLE)}</pre>
      </details>`,
    footer: `
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--primary" id="tf-go" ${gcs.ready && !blocked ? '' : 'disabled'}>Exportar</button>`,
    onMount: (modal, close) => {
      const nameInput = modal.querySelector('#tf-name');

      modal.querySelector('#tf-go').onclick = () =>
        close({ filename: nameInput.value.trim() || defaultFilename() });
    },
  });

  if (!result) return;

  try {
    // `paths: null` diz ao servidor para varrer o mapeamento inteiro.
    const response = await api.exportEvents({ paths: null, filename: result.filename });
    toast.ok(`Exportado para ${response.gcs.gsUri}`);
  } catch (err) {
    toast.error(err.message);
  }
}

const SAMPLE = `{
  "Checkout": [
    {
      "event_name": "begin_checkout",
      "event_type": "ecommerce",
      "platform": ["web", "app"],
      "trigger": "Clique em 'Finalizar compra' no carrinho",
      "governance": { "squad": "Checkout", "owner": "…", "notes": "…" },
      "tracker": { "card_name": "…", "card_id": "ANA-1234", "url": "…" },
      "parameters": {
        "event": [{ "name": "event_id", "type": "string", "required": true }],
        "user":  [{ "name": "user_id", "type": "string", "required": false }],
        "items": [{ "name": "item_id", "type": "string", "required": true }]
      }
    }
  ]
}`;

const sanitize = (name) =>
  String(name || 'export')
    .normalize('NFD')
    .replace(/[^\x20-\x7E]/g, '')
    .replace(/[^a-zA-Z0-9-_.]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .toLowerCase() || 'export';
