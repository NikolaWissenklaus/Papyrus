/*
 * Aba "Catalogo".
 *
 * E a fonte oficial dos eventos e parametros do mapeamento, e tambem o retrato
 * do que esta nos mapas. Junta o que antes era o Dicionario Global (uso nos
 * mapas, conflito de tipo, event_id repetido, de-para, CSV) com o cadastro:
 * criar evento escolhendo os parametros dele, criar parametro, editar,
 * excluir, exportar para o Storage e importar de volta.
 *
 * Quem consolida os mapas e o servidor (GET /dictionary). Aqui a gente so
 * apresenta, filtra e dispara as acoes.
 */

import {
  state, on, setCatalog, loadCatalog, flushSave, reloadOpenPage, getCatalogIndex, setView,
} from '../store.js';
import { api } from '../api.js';
import { EVENT_TYPE_MAP, PARAM_SCOPES, PARAM_SCOPE_SHORT } from '../constants.js';
import { esc, downloadBlob, formatDate, plural, readFileAsText } from '../util.js';
import { toast } from '../ui/toast.js';
import { openModal, contextMenu } from '../ui/modal.js';
import { normalizeKey } from '../../shared/rules.js';
import { resolveEventParams } from '../../shared/catalog-sync.js';
import {
  openEventEditor, openParamEditor, openEventDetails, openParamDetails,
  deleteCatalogEvent, deleteCatalogParam, setCatalogUsage, usageOf,
} from './catalog-forms.js';
import { pickStorageObject, describeStorageObject, gcsReadyOrExplain } from './storage.js';

let root = null;
let dictionary = null;
let activeTab = 'events';
let query = '';

const SCOPES = ['eventParams', 'userParams', 'itemParams'];

export function initCatalog() {
  root = document.getElementById('catalog-root');

  on('view', (view) => {
    if (view === 'catalog') refresh();
  });
  on('workspace', () => {
    dictionary = null;
    activeTab = 'events';
    query = '';
    setCatalogUsage({});
    if (root) root.innerHTML = '';
  });
  on('catalog', () => {
    if (state.view === 'catalog' && dictionary) render();
  });

  window.addEventListener('papyrus:catalog-changed', () => {
    if (state.view === 'catalog') refresh();
  });
  // Arquivo de catalogo escolhido na importacao de mapas: a importacao continua aqui.
  window.addEventListener('papyrus:catalog-import', (e) => {
    setView('catalog');
    importFromStorage(e.detail?.object);
  });
  // A troca de aba ja dispara o refresh; a ficha abre por cima com o catalogo
  // que esta em memoria, e o uso nos mapas chega quando o refresh termina.
  window.addEventListener('papyrus:catalog-focus', (e) => {
    setView('catalog');
    if (e.detail?.eventId) openEventDetails(e.detail.eventId);
  });
}

export async function refresh() {
  if (!root || !state.workspace) return;
  if (!dictionary) {
    root.innerHTML = '<div class="card" style="text-align:center;color:var(--text-muted)">Carregando o catálogo…</div>';
  }
  try {
    const [, dict] = await Promise.all([loadCatalog(), api.getDictionary()]);
    dictionary = dict;
    setCatalogUsage(dict.catalogUsage);
    render();
  } catch (err) {
    root.innerHTML = `<div class="card" style="color:var(--danger)">${esc(err.message)}</div>`;
  }
}

/* Render */

function render() {
  if (!root || !dictionary) return;
  const catalog = state.catalog;
  const totals = dictionary.totals;
  const offCatalog = (totals.unlinked || 0) + (totals.missing || 0);
  const collisions = dictionary.eventIdCollisions || [];
  const conflicts = dictionary.conflicts || [];

  const tabs = [
    { id: 'events', label: 'Eventos', count: catalog.events.length },
    { id: 'params', label: 'Parâmetros', count: catalog.params.length },
    { id: 'matrix', label: 'De-para' },
    { id: 'usage', label: 'Uso nos mapas', count: totals.events },
  ];

  root.innerHTML = `
    <div class="page-head">
      <div>
        <h1>Catálogo</h1>
        <p>
          Eventos e parâmetros oficiais de <strong>${esc(state.workspace.name)}</strong>. Todo card do canvas nasce de
          um evento daqui, e mudar um evento atualiza todos os cards dele.
        </p>
      </div>
      <div class="page-head__actions">
        <button class="btn btn--ghost" id="cat-import">Importar</button>
        <button class="btn btn--ghost" id="cat-export">Exportar ▾</button>
        <button class="btn btn--ghost" id="cat-refresh" title="Recarregar catálogo e mapas">Atualizar</button>
      </div>
    </div>

    <div class="stat-row">
      <div class="stat"><div class="stat__value">${catalog.events.length}</div><div class="stat__label">Eventos no catálogo</div></div>
      <div class="stat"><div class="stat__value">${catalog.params.length}</div><div class="stat__label">Parâmetros no catálogo</div></div>
      <div class="stat"><div class="stat__value">${totals.events}</div><div class="stat__label">Cards em ${plural(totals.pages, 'página')}</div></div>
      <div class="stat${offCatalog ? ' stat--warn' : ''}"><div class="stat__value">${offCatalog}</div><div class="stat__label">Cards fora do catálogo</div></div>
      <div class="stat${conflicts.length ? ' stat--alert' : ''}"><div class="stat__value">${conflicts.length}</div><div class="stat__label">Conflitos de tipo</div></div>
      <div class="stat${collisions.length ? ' stat--alert' : ''}"><div class="stat__value">${collisions.length}</div><div class="stat__label">event_id repetidos</div></div>
    </div>

    ${offCatalog ? adoptionBanner(totals) : ''}
    ${collisions.length ? collisionBanner(collisions) : ''}
    ${conflicts.length ? conflictBanner(conflicts) : ''}

    <div class="catalog-toolbar">
      <div class="segmented" role="tablist">
        ${tabs
          .map(
            (t) => `<button class="segmented__item${activeTab === t.id ? ' is-active' : ''}" data-tab="${t.id}" role="tab">
                      ${esc(t.label)}${t.count != null ? ` <span class="segmented__count">${t.count}</span>` : ''}
                    </button>`,
          )
          .join('')}
      </div>
      <input class="input input--search" id="cat-search" placeholder="Filtrar…" value="${esc(query)}" />
      <span class="catalog-toolbar__spacer"></span>
      ${activeTab === 'params'
        ? '<button class="btn btn--primary" id="cat-new-param">+ Novo parâmetro</button>'
        : '<button class="btn btn--primary" id="cat-new-event">+ Novo evento</button>'}
    </div>

    <div id="cat-body">${renderTab()}</div>`;

  bind();
}

const adoptionBanner = (totals) => `
  <div class="banner banner--warn">
    <div>
      <strong>${plural((totals.unlinked || 0) + (totals.missing || 0), 'card usa', 'cards usam')} evento que não está no catálogo.</strong>
      <p>São cards criados antes do catálogo, ou de eventos que foram excluídos dele. Eles exportam normalmente, mas não acompanham as mudanças do catálogo.</p>
    </div>
    <button class="btn btn--primary" id="cat-adopt">Revisar e trazer para o catálogo</button>
  </div>`;

const collisionBanner = (collisions) => `
  <div class="banner banner--danger">
    <div>
      <strong>${plural(collisions.length, '<code>event_id</code> usado', '<code>event_id</code> usados')} por mais de um card</strong>
      <p>O <code>event_id</code> liga o planejamento ao dado coletado. Repetido, dois eventos diferentes chegam como o mesmo. Cada card precisa do seu.</p>
      <div class="banner__list">
        ${collisions
          .map((c) => `<div><code>${esc(c.id)}</code> <span class="faint">em ${c.uses.map((u) => `${esc(u.event)} (${esc(u.page)})`).join(', ')}</span></div>`)
          .join('')}
      </div>
    </div>
  </div>`;

const conflictBanner = (conflicts) => `
  <div class="banner banner--danger">
    <div>
      <strong>${plural(conflicts.length, 'parâmetro declarado', 'parâmetros declarados')} com tipos diferentes nos mapas</strong>
      <p>O mesmo nome com tipos diferentes vira coluna inconsistente no BigQuery e quebra relatório. Trazer os cards para o catálogo padroniza o tipo.</p>
      <div class="chip-cloud">
        ${conflicts.map((c) => `<span class="chip chip--danger"><code>${esc(c.name)}</code>: ${c.types.map(esc).join(' / ')}</span>`).join('')}
      </div>
    </div>
  </div>`;

const typeChip = (eventType) => {
  const type = EVENT_TYPE_MAP[eventType];
  return `<span class="chip chip--${esc(eventType)}">${esc(type?.label || eventType)}</span>`;
};

const emptyRow = (cols, text) =>
  `<tr><td colspan="${cols}" class="table__empty">${text}</td></tr>`;

const table = (headers, rows, count, emptyText = 'Nenhum resultado.') => `
  <div class="table-scroll">
    <table class="table">
      <thead><tr>${headers.map((h) => `<th>${esc(h)}</th>`).join('')}</tr></thead>
      <tbody>${rows.join('') || emptyRow(headers.length, emptyText)}</tbody>
    </table>
  </div>
  <div class="field__hint" style="margin-top:8px">${plural(count, 'registro')}.</div>`;

function matches(...texts) {
  const q = normalizeKey(query);
  return !q || texts.some((t) => normalizeKey(t).includes(q));
}

function renderTab() {
  const index = getCatalogIndex();

  if (activeTab === 'events') {
    const rows = [...state.catalog.events]
      .filter((e) => matches(e.name, e.description, EVENT_TYPE_MAP[e.eventType]?.label))
      .sort((a, b) => a.name.localeCompare(b.name));

    return table(
      ['Evento', 'Tipo', 'Parâmetros', 'Uso nos mapas', 'Atualizado', ''],
      rows.map((e) => {
        const params = Object.values(resolveEventParams(e, index)).flat();
        const usage = usageOf(e.id);
        return `
          <tr>
            <td>
              <button class="link-cell" data-event-open="${e.id}"><code>${esc(e.name)}</code></button>
              ${e.description ? `<div class="cell-sub">${esc(e.description)}</div>` : ''}
            </td>
            <td>${typeChip(e.eventType)}</td>
            <td class="cell-chips">
              ${params.slice(0, 5).map(({ def, required }) => `<span class="chip" title="${esc(PARAM_SCOPES[def.scope])}">${esc(def.name)}${required ? ' *' : ''}</span>`).join('')}
              ${params.length > 5 ? `<span class="chip">+${params.length - 5}</span>` : ''}
              ${!params.length ? '<span class="faint">só event_id</span>' : ''}
            </td>
            <td class="muted">${usage ? `${plural(usage.cards, 'card')} · ${plural(usage.pages.length, 'página')}` : '<span class="faint">—</span>'}</td>
            <td class="muted">${formatDate(e.updatedAt)}</td>
            <td class="cell-actions">
              <button class="btn btn--mini" data-event-edit="${e.id}">Editar</button>
              <button class="btn btn--mini btn--mini-danger" data-event-delete="${e.id}">Excluir</button>
            </td>
          </tr>`;
      }),
      rows.length,
      state.catalog.events.length
        ? 'Nenhum evento nesta busca.'
        : 'O catálogo ainda não tem eventos. Crie o primeiro em <strong>+ Novo evento</strong>, ou traga os eventos que já estão nos mapas.',
    );
  }

  if (activeTab === 'params') {
    const eventsUsing = new Map();
    for (const e of state.catalog.events) {
      for (const ref of e.params) {
        if (!eventsUsing.has(ref.id)) eventsUsing.set(ref.id, []);
        eventsUsing.get(ref.id).push({ event: e, required: ref.required });
      }
    }

    const rows = [...state.catalog.params]
      .filter((p) => matches(p.name, p.description, PARAM_SCOPES[p.scope]))
      .sort((a, b) => SCOPES.indexOf(a.scope) - SCOPES.indexOf(b.scope) || a.name.localeCompare(b.name));

    return table(
      ['Parâmetro', 'Escopo', 'Tipo', 'Padrão', 'Exemplo', 'Eventos associados', ''],
      rows.map((p) => {
        const users = eventsUsing.get(p.id) || [];
        return `
          <tr>
            <td>
              <button class="link-cell" data-param-open="${p.id}"><code>${esc(p.name)}</code></button>
              ${p.description ? `<div class="cell-sub">${esc(p.description)}</div>` : ''}
            </td>
            <td><span class="chip">${esc(PARAM_SCOPE_SHORT[p.scope])}</span></td>
            <td>${esc(p.type)}</td>
            <td class="muted">${p.required ? 'obrigatório' : 'opcional'}</td>
            <td class="faint">${p.example ? `<code>${esc(p.example)}</code>` : '—'}</td>
            <td class="cell-chips">
              ${users.slice(0, 5).map(({ event, required }) => `<button class="chip chip--button" data-event-open="${event.id}">${esc(event.name)}${required ? ' *' : ''}</button>`).join('')}
              ${users.length > 5 ? `<span class="chip">+${users.length - 5}</span>` : ''}
              ${!users.length ? '<span class="faint">nenhum evento</span>' : ''}
            </td>
            <td class="cell-actions">
              <button class="btn btn--mini" data-param-edit="${p.id}">Editar</button>
              <button class="btn btn--mini btn--mini-danger" data-param-delete="${p.id}" ${users.length ? 'disabled title="Remova dos eventos antes de excluir"' : ''}>Excluir</button>
            </td>
          </tr>`;
      }),
      rows.length,
      state.catalog.params.length ? 'Nenhum parâmetro nesta busca.' : 'Nenhum parâmetro no catálogo ainda.',
    );
  }

  if (activeTab === 'matrix') {
    const params = [...state.catalog.params]
      .filter((p) => matches(p.name))
      .sort((a, b) => SCOPES.indexOf(a.scope) - SCOPES.indexOf(b.scope) || a.name.localeCompare(b.name))
      .slice(0, 80);
    const events = [...state.catalog.events].sort((a, b) => a.name.localeCompare(b.name)).slice(0, 50);

    if (!params.length || !events.length) {
      return '<div class="card empty-card">O de-para aparece quando o catálogo tiver eventos com parâmetros.</div>';
    }

    return `
      <div class="table-scroll">
        <table class="table table--matrix">
          <thead>
            <tr>
              <th class="matrix__corner">Parâmetro</th>
              ${events.map((e) => `<th class="matrix__head"><span>${esc(e.name)}</span></th>`).join('')}
            </tr>
          </thead>
          <tbody>
            ${params
              .map((p) => `
                <tr>
                  <td class="matrix__label"><code>${esc(p.name)}</code> <span class="faint">${esc(PARAM_SCOPE_SHORT[p.scope])}</span></td>
                  ${events
                    .map((e) => {
                      const ref = e.params.find((r) => r.id === p.id);
                      return `<td class="matrix__cell">${
                        ref
                          ? `<span class="matrix__dot${ref.required ? ' is-required' : ''}" title="${ref.required ? 'obrigatório' : 'opcional'}">${ref.required ? '●' : '○'}</span>`
                          : '<span class="faint">·</span>'
                      }</td>`;
                    })
                    .join('')}
                </tr>`)
              .join('')}
          </tbody>
        </table>
      </div>
      <div class="field__hint" style="margin-top:8px">
        ● obrigatório no evento · ○ opcional. Exibindo até 80 parâmetros × 50 eventos; use o filtro para recortar.
      </div>`;
  }

  // Uso nos mapas: o que antes era a lista de eventos do Dicionario Global.
  const statusChip = {
    linked: '<span class="chip chip--interaction">no catálogo</span>',
    unlinked: '<span class="chip chip--warn">fora do catálogo</span>',
    missing: '<span class="chip chip--danger">removido do catálogo</span>',
  };
  const rows = dictionary.events.filter((e) => matches(e.event_name, e.page, e.governance.squad));

  return table(
    ['Evento', 'Tipo', 'Catálogo', 'Página', 'Plataforma', 'Squad / Responsável', 'Params', 'Card', ''],
    rows.map((e) => {
      const paramCount = e.parameters.event.length + e.parameters.user.length + (e.parameters.items?.length || 0);
      return `
        <tr>
          <td><code>${esc(e.event_name)}</code></td>
          <td>${typeChip(e.event_type)}</td>
          <td>${statusChip[e.catalogStatus] || ''}</td>
          <td>${esc(e.page)}</td>
          <td class="muted">${e.platform.map(esc).join(', ') || '—'}</td>
          <td class="muted">${esc([e.governance.squad, e.governance.owner].filter(Boolean).join(' · ') || '—')}</td>
          <td>${paramCount}</td>
          <td>${
            e.tracker.url
              ? `<a href="${esc(e.tracker.url)}" target="_blank" rel="noopener" style="color:var(--azul)">${esc(e.tracker.card_id || 'abrir')}</a>`
              : `<span class="faint">${esc(e.tracker.card_id || '—')}</span>`
          }</td>
          <td class="cell-actions"><button class="btn btn--mini" data-goto="${esc(e.pagePath)}" data-element="${esc(e.elementId)}">Abrir</button></td>
        </tr>`;
    }),
    rows.length,
    'Nenhum card nos mapas ainda.',
  );
}

/* Interacao */

function bind() {
  root.querySelector('#cat-refresh').onclick = () => refresh();
  root.querySelector('#cat-adopt')?.addEventListener('click', () => openAdoption());

  root.querySelector('#cat-export').onclick = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    contextMenu(rect.left, rect.bottom + 4, [
      { label: 'Para o Google Cloud Storage…', onClick: () => exportToStorage() },
      '-',
      { label: 'CSV do catálogo (eventos × parâmetros)', onClick: () => exportCatalogCSV() },
      { label: 'CSV dos mapas (página × evento × parâmetro)', onClick: () => exportMapsCSV() },
    ]);
  };
  root.querySelector('#cat-import').onclick = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    contextMenu(rect.left, rect.bottom + 4, [
      { label: 'Do Google Cloud Storage…', onClick: () => importFromStorage() },
      { label: 'Arquivo do computador…', onClick: () => importFromFile() },
    ]);
  };

  root.querySelector('#cat-new-event')?.addEventListener('click', async () => {
    if (await openEventEditor()) refresh();
  });
  root.querySelector('#cat-new-param')?.addEventListener('click', async () => {
    if (await openParamEditor()) refresh();
  });

  root.querySelectorAll('[data-tab]').forEach((btn) => {
    btn.onclick = () => {
      activeTab = btn.dataset.tab;
      render();
    };
  });

  const search = root.querySelector('#cat-search');
  search.oninput = () => {
    query = search.value;
    root.querySelector('#cat-body').innerHTML = renderTab();
    bindBody();
  };
  if (query) {
    search.focus();
    search.setSelectionRange(query.length, query.length);
  }

  bindBody();
}

/** Acoes de dentro da tabela, religadas a cada filtro. */
function bindBody() {
  const body = root.querySelector('#cat-body');
  const byId = (list, id) => list.find((item) => item.id === id);

  body.querySelectorAll('[data-event-open]').forEach((btn) => {
    btn.onclick = () => openEventDetails(btn.dataset.eventOpen);
  });
  body.querySelectorAll('[data-event-edit]').forEach((btn) => {
    btn.onclick = async () => {
      const event = byId(state.catalog.events, btn.dataset.eventEdit);
      if (event && (await openEventEditor({ event }))) refresh();
    };
  });
  body.querySelectorAll('[data-event-delete]').forEach((btn) => {
    btn.onclick = async () => {
      const event = byId(state.catalog.events, btn.dataset.eventDelete);
      if (event && (await deleteCatalogEvent(event))) refresh();
    };
  });
  body.querySelectorAll('[data-param-open]').forEach((btn) => {
    btn.onclick = () => openParamDetails(btn.dataset.paramOpen);
  });
  body.querySelectorAll('[data-param-edit]').forEach((btn) => {
    btn.onclick = async () => {
      const param = byId(state.catalog.params, btn.dataset.paramEdit);
      if (param && (await openParamEditor({ param }))) refresh();
    };
  });
  body.querySelectorAll('[data-param-delete]').forEach((btn) => {
    btn.onclick = async () => {
      const param = byId(state.catalog.params, btn.dataset.paramDelete);
      if (param && (await deleteCatalogParam(param))) refresh();
    };
  });
  body.querySelectorAll('[data-goto]').forEach((btn) => {
    btn.onclick = () =>
      window.dispatchEvent(new CustomEvent('papyrus:goto', { detail: { path: btn.dataset.goto, elementId: btn.dataset.element } }));
  });
}

/* Trazer os eventos dos mapas */

async function openAdoption() {
  let plan;
  try {
    await flushSave();
    ({ plan } = await api.planAdoption());
  } catch (err) {
    toast.error(err.message);
    return;
  }
  if (!plan.cards) {
    toast.info('Todos os cards com nome já estão no catálogo.');
    return;
  }

  const confirmed = await openModal({
    title: 'Trazer eventos dos mapas para o catálogo',
    subtitle: `${plural(plan.cards, 'card')} em ${plural(plan.pages, 'página')} passam a ser vinculados ao catálogo.`,
    wide: true,
    body: `
      <div class="stat-row stat-row--compact">
        <div class="stat"><div class="stat__value">${plan.createEvents.length}</div><div class="stat__label">Eventos novos</div></div>
        <div class="stat"><div class="stat__value">${plan.extendEvents.length}</div><div class="stat__label">Eventos completados</div></div>
        <div class="stat"><div class="stat__value">${plan.createParams}</div><div class="stat__label">Parâmetros novos</div></div>
        <div class="stat"><div class="stat__value">${plan.cards}</div><div class="stat__label">Cards vinculados</div></div>
      </div>
      ${
        plan.createEvents.length
          ? `<h4 class="detail-title">Eventos que entram no catálogo</h4>
             <div class="table-scroll" style="max-height:240px">
               <table class="table">
                 <thead><tr><th>Evento</th><th>Tipo</th><th>Parâmetros</th><th>Cards</th><th>Páginas</th></tr></thead>
                 <tbody>${plan.createEvents
                   .map((e) => `<tr><td><code>${esc(e.name)}</code></td><td>${typeChip(e.eventType)}</td><td>${e.params}</td><td>${e.cards}</td><td>${e.pages}</td></tr>`)
                   .join('')}</tbody>
               </table>
             </div>`
          : ''
      }
      ${
        plan.extendEvents.length
          ? `<h4 class="detail-title">Eventos que já existem e ganham parâmetros</h4>
             ${plan.extendEvents.map((e) => `<div class="usage-row"><code>${esc(e.name)}</code> ${e.addParams.map((p) => `<span class="chip">+ ${esc(p)}</span>`).join(' ')}</div>`).join('')}`
          : ''
      }
      ${
        plan.conflicts.length
          ? `<div class="banner banner--warn banner--compact">
               <div>
                 <strong>${plural(plan.conflicts.length, 'parâmetro aparece', 'parâmetros aparecem')} com tipos diferentes</strong>
                 <p>Vale o tipo mais usado (ou o que já está no catálogo). Confira depois na aba Parâmetros.</p>
                 <div class="chip-cloud">${plan.conflicts.map((c) => `<span class="chip chip--warn"><code>${esc(c.name)}</code>: ${c.types.map(esc).join(' / ')} → ${esc(c.chosen)}</span>`).join('')}</div>
               </div>
             </div>`
          : ''
      }
      ${plan.skipped ? `<p class="field__hint">${plural(plan.skipped, 'card sem nome ficou', 'cards sem nome ficaram')} de fora.</p>` : ''}
      <p class="field__hint">
        Os valores de exemplo, o <code>event_id</code> e o resto de cada card não mudam. Nome fora do padrão entra como
        está: renomeie depois no catálogo e todos os cards acompanham.
      </p>`,
    footer: `
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--primary" data-close="yes">Trazer para o catálogo</button>`,
  });
  if (confirmed !== 'yes') return;

  try {
    await flushSave();
    const { catalog, report } = await api.applyAdoption();
    setCatalog(catalog, { resync: false });
    await reloadOpenPage();
    toast.ok(
      `${plural(report.linkedCards, 'card vinculado', 'cards vinculados')} · ${report.createdEvents} evento(s) e ${report.createdParams} parâmetro(s) criados.`,
      5000,
    );
    refresh();
  } catch (err) {
    toast.error(err.message);
  }
}

/* Exportar */

async function exportToStorage() {
  const gcs = await gcsReadyOrExplain();
  if (!gcs) return;

  const filename = await openModal({
    title: 'Exportar catálogo para o Storage',
    subtitle: 'JSON com cada evento e os parâmetros dele por extenso, mais a lista completa de parâmetros.',
    body: `
      <div class="field">
        <label class="field__label" for="ce-name">Nome do arquivo</label>
        <input class="input input--mono" id="ce-name" value="catalogo-${esc(state.workspace.id)}" />
      </div>
      <div class="field">
        <label class="field__label">Destino</label>
        <div class="card" style="padding:12px 16px">
          <code>gs://${esc(gcs.bucket)}/${esc(gcs.prefix ? `${gcs.prefix.replace(/\/+$/, '')}/` : '')}catalog/</code>
          <div class="field__hint">Arquivo com o mesmo nome é substituído.</div>
        </div>
      </div>
      <p class="field__hint">${plural(state.catalog.events.length, 'evento')} e ${plural(state.catalog.params.length, 'parâmetro')}. O arquivo pode ser importado de volta aqui ou em outro mapeamento.</p>`,
    footer: `
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--primary" id="ce-go">Exportar</button>`,
    onMount: (modal, close) => {
      const input = modal.querySelector('#ce-name');
      input.focus();
      input.select();
      modal.querySelector('#ce-go').onclick = () => close(input.value.trim() || `catalogo-${state.workspace.id}`);
    },
  });
  if (!filename) return;

  try {
    const res = await api.exportCatalog(filename);
    toast.ok(`Catálogo exportado para ${res.gcs.gsUri}`, 5000);
  } catch (err) {
    toast.error(err.message);
  }
}

const csvCell = (value) => `"${String(value ?? '').replace(/"/g, '""')}"`;

function downloadCSV(rows, filename) {
  const csv = rows.map((r) => r.map(csvCell).join(';')).join('\r\n');
  // BOM, senao o Excel abre com a acentuacao quebrada.
  downloadBlob(new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' }), filename);
  toast.ok('CSV gerado.');
}

function exportCatalogCSV() {
  const index = getCatalogIndex();
  const rows = [['evento', 'tipo_evento', 'descricao_evento', 'escopo', 'parametro', 'tipo', 'obrigatorio', 'descricao_parametro', 'exemplo', 'cards_nos_mapas']];

  for (const e of state.catalog.events) {
    const usage = usageOf(e.id)?.cards || 0;
    const resolved = resolveEventParams(e, index);
    rows.push([e.name, e.eventType, e.description, 'event', 'event_id', 'string', 'sim', 'automático', '', usage]);
    for (const scope of SCOPES) {
      for (const { def, required } of resolved[scope]) {
        rows.push([e.name, e.eventType, e.description, { eventParams: 'event', userParams: 'user', itemParams: 'items' }[scope], def.name, def.type, required ? 'sim' : 'nao', def.description, def.example, usage]);
      }
    }
  }
  downloadCSV(rows, `papyrus-catalogo-${state.workspace.id}.csv`);
}

/** O de-para completo dos mapas, formato que o time de dados le direto. */
function exportMapsCSV() {
  const rows = [['pagina', 'evento', 'tipo_evento', 'no_catalogo', 'plataforma', 'squad', 'responsavel', 'escopo', 'parametro', 'tipo', 'obrigatorio']];
  for (const e of dictionary.events) {
    for (const [scope, list] of Object.entries(e.parameters)) {
      for (const p of list) {
        rows.push([
          e.page, e.event_name, e.event_type, e.catalogStatus === 'linked' ? 'sim' : 'nao', e.platform.join('|'),
          e.governance.squad, e.governance.owner, scope, p.name, p.type, p.required ? 'sim' : 'nao',
        ]);
      }
    }
  }
  downloadCSV(rows, `papyrus-mapas-${state.workspace.id}.csv`);
}

/* Importar */

/**
 * Opcoes da importacao de catalogo. Mesclar e o caminho seguro; substituir
 * deixa o catalogo igual ao arquivo e solta os cards de quem saiu.
 */
function importOptions({ label, summary }) {
  const backup = summary?.kind === 'backup' ? summary : null;
  const defaultSource = backup?.workspaces.find((w) => w.id === state.workspace.id)?.id || backup?.workspaces[0]?.id;

  const describe = () => {
    if (!summary) return '';
    if (summary.kind === 'catalog') return `Catálogo com ${plural(summary.events, 'evento')} e ${plural(summary.params, 'parâmetro')}${summary.workspace?.name ? `, exportado de "${esc(summary.workspace.name)}"` : ''}.`;
    if (summary.kind === 'backup') return `Backup ${summary.date ? `de ${esc(formatBackupDate(summary.date))}` : ''} com ${plural(summary.workspaces.length, 'mapeamento')}. Vale o catálogo de um deles.`;
    if (summary.kind === 'contract') return `Contrato exportado com ${plural(summary.events, 'evento')}: o catálogo é montado a partir deles.`;
    return '';
  };

  return openModal({
    title: 'Importar catálogo',
    subtitle: label,
    body: `
      ${summary ? `<p class="import-summary">${describe()}</p>` : ''}
      ${
        backup
          ? `<div class="field">
               <label class="field__label" for="ci-source">Catálogo de qual mapeamento do backup</label>
               <select class="select" id="ci-source">
                 ${backup.workspaces.map((w) => `<option value="${esc(w.id)}"${w.id === defaultSource ? ' selected' : ''}>${esc(w.name)} · ${plural(w.catalogEvents, 'evento')}</option>`).join('')}
               </select>
             </div>`
          : ''
      }
      <div class="field">
        <label class="field__label">Como importar</label>
        <label class="radio-card">
          <input type="radio" name="ci-mode" value="merge" checked />
          <span><strong>Mesclar</strong><br /><span class="field__hint">Acrescenta o que falta e atualiza os eventos e parâmetros que já existem, casando pelo nome. Nada sai do catálogo.</span></span>
        </label>
        <label class="radio-card">
          <input type="radio" name="ci-mode" value="replace" />
          <span><strong>Substituir</strong><br /><span class="field__hint">O catálogo fica igual ao arquivo. Evento que não está no arquivo sai do catálogo, e os cards dele ficam fora do catálogo (o conteúdo continua no canvas).</span></span>
        </label>
      </div>`,
    footer: `
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--primary" id="ci-go">Importar</button>`,
    onMount: (modal, close) => {
      modal.querySelector('#ci-go').onclick = () =>
        close({
          mode: modal.querySelector('input[name="ci-mode"]:checked').value,
          sourceWorkspace: modal.querySelector('#ci-source')?.value || null,
        });
    },
  });
}

const formatBackupDate = (key) => (/^\d{8}$/.test(key) ? `${key.slice(6, 8)}/${key.slice(4, 6)}/${key.slice(0, 4)}` : key);

async function runCatalogImport(body) {
  try {
    await flushSave();
    const { catalog, report } = await api.importCatalog(body);
    setCatalog(catalog, { resync: false });
    await reloadOpenPage();
    const parts = [
      `${report.addedEvents} evento(s) novo(s)`,
      `${report.updatedEvents} atualizado(s)`,
      `${report.addedParams} parâmetro(s) novo(s)`,
    ];
    if (report.removedEvents) parts.push(`${report.removedEvents} evento(s) removido(s)`);
    if (report.propagation?.cards) parts.push(`${plural(report.propagation.cards, 'card sincronizado', 'cards sincronizados')}`);
    toast.ok(`Catálogo importado · ${parts.join(' · ')}.`, 6000);
    refresh();
  } catch (err) {
    toast.error(err.message, 6000);
  }
}

async function importFromStorage(objectName = null) {
  if (!(await gcsReadyOrExplain())) return;

  const object = objectName || (await pickStorageObject({
    title: 'Importar catálogo do Storage',
    prefer: 'catalog',
  }))?.name;
  if (!object) return;

  let summary = null;
  try {
    ({ summary } = await api.inspectStorageObject(object));
  } catch (err) {
    toast.error(err.message);
    return;
  }
  if (!['catalog', 'backup', 'contract'].includes(summary.kind)) {
    toast.error('Este arquivo não traz catálogo: escolha um catálogo exportado, um backup (versions/) ou um contrato exportado.', 6000);
    return;
  }

  const options = await importOptions({ label: describeStorageObject(object), summary });
  if (!options) return;
  await runCatalogImport({ source: 'gcs', object, ...options });
}

function importFromFile() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'application/json,.json';
  input.onchange = async () => {
    const file = input.files?.[0];
    if (!file) return;
    const content = await readFileAsText(file);
    const options = await importOptions({ label: file.name, summary: null });
    if (!options) return;
    await runCatalogImport({ source: 'inline', content, ...options });
  };
  input.click();
}

/** Usado pelo inspetor para abrir o catalogo ja na ficha do evento do card. */
export function focusCatalogEvent(eventId) {
  window.dispatchEvent(new CustomEvent('papyrus:catalog-focus', { detail: { eventId } }));
}
