/*
 * Hub: a tela que aparece depois do login, com um card por mapeamento.
 *
 * O GA4 ja vem criado, e e o mesmo workspace de sempre. "Criar mapeamento"
 * abre outro projeto com a mesma estrutura (pastas, paginas, catalogo,
 * grupos) para Meta Ads, Google Ads, Criteo, RTB House, ou para separar outra
 * propriedade do GA4. Cada mapeamento exporta o proprio contrato.
 *
 * Criar e de qualquer pessoa logada; renomear e excluir, de administrador.
 */

import { state, on, loadWorkspaces } from '../store.js';
import { api } from '../api.js';
import { TOOLS, toolOf } from '../constants.js';
import { esc, formatDate, plural } from '../util.js';
import { openModal, contextMenu } from '../ui/modal.js';
import { toast } from '../ui/toast.js';
import { normalizeKey } from '../../shared/rules.js';
import { renderUserChip, openUserMenu, openChangePassword } from './users.js';

let enter = null;
let hub = null;
let grid = null;

/** @param {{ enter: (id: string) => void }} options */
export function initHub({ enter: onEnter }) {
  enter = onEnter;
  hub = document.getElementById('hub');
  grid = document.getElementById('hub-grid');

  const userHost = document.getElementById('hub-user');
  userHost.addEventListener('click', (e) => {
    const chip = e.target.closest('.user-chip');
    if (chip) openUserMenu(chip);
  });

  on('workspaces', () => render());
  on('user', () => {
    renderUserChip(userHost);
    renderGreeting();
  });
}

export async function showHub() {
  hub.hidden = false;
  hub.classList.remove('is-loading');
  document.body.classList.add('is-hub');
  document.title = 'Papyrus | Mapeamentos';
  render();
  try {
    await loadWorkspaces();
  } catch (err) {
    toast.error(err.message);
  }
}

export function hideHub() {
  hub.hidden = true;
  hub.classList.remove('is-loading');
  document.body.classList.remove('is-hub');
}

function renderGreeting() {
  const user = state.user;
  document.getElementById('hub-greeting').textContent = user ? `Olá, ${user.username}` : '';

  const notice = document.getElementById('hub-notice');
  if (user?.usingDefaultPassword) {
    notice.hidden = false;
    notice.innerHTML = `
      <span>Você ainda está usando a senha padrão do Papyrus, que está no README. Troque antes de compartilhar o acesso.</span>
      <button class="btn btn--mini" id="hub-change-pass">Trocar agora</button>`;
    notice.querySelector('#hub-change-pass').onclick = () => openChangePassword();
  } else {
    notice.hidden = true;
  }
}

function card(ws) {
  const tool = toolOf(ws.tool);
  const stats = ws.stats || {};
  return `
    <article class="ws-card" data-open="${esc(ws.id)}" tabindex="0" style="--tool:${tool.color}" aria-label="Abrir ${esc(ws.name)}">
      <div class="ws-card__top">
        <span class="ws-badge" style="background:${tool.color}">${esc(tool.short)}</span>
        ${state.user?.admin ? `<button class="ws-card__menu" data-menu="${esc(ws.id)}" title="Opções do mapeamento">⋯</button>` : ''}
      </div>
      <h3 class="ws-card__name">${esc(ws.name)}</h3>
      <div class="ws-card__tool">${esc(tool.label)}${ws.isDefault ? ' · padrão' : ''}</div>
      ${ws.description ? `<p class="ws-card__desc">${esc(ws.description)}</p>` : ''}
      <div class="ws-card__stats">
        <span><strong>${stats.pages ?? 0}</strong> ${stats.pages === 1 ? 'página' : 'páginas'}</span>
        <span><strong>${stats.cards ?? 0}</strong> ${stats.cards === 1 ? 'card' : 'cards'}</span>
        <span><strong>${stats.catalogEvents ?? 0}</strong> no catálogo</span>
      </div>
      <div class="ws-card__foot">
        <span class="faint">${stats.updatedAt ? `Atualizado em ${formatDate(stats.updatedAt)}` : 'Ainda sem páginas'}</span>
        <span class="ws-card__go">Abrir →</span>
      </div>
    </article>`;
}

function render() {
  if (!grid) return;
  if (!state.workspaces.length) {
    grid.innerHTML = '<div class="hub__loading">Carregando os mapeamentos…</div>';
    return;
  }

  grid.innerHTML = `
    ${state.workspaces.map(card).join('')}
    <button class="ws-card ws-card--create" id="hub-create" type="button">
      <span class="ws-card__plus">+</span>
      <strong>Criar mapeamento</strong>
      <span class="faint">Meta Ads, Google Ads, Criteo, RTB House ou outro GA4</span>
    </button>`;

  grid.querySelectorAll('[data-open]').forEach((node) => {
    const open = () => enter?.(node.dataset.open);
    node.onclick = (e) => {
      if (e.target.closest('[data-menu]')) return;
      open();
    };
    node.onkeydown = (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        open();
      }
    };
  });

  grid.querySelectorAll('[data-menu]').forEach((btn) => {
    btn.onclick = (e) => {
      e.stopPropagation();
      const ws = state.workspaces.find((w) => w.id === btn.dataset.menu);
      const rect = btn.getBoundingClientRect();
      contextMenu(rect.left, rect.bottom + 4, [
        { label: 'Abrir', onClick: () => enter?.(ws.id) },
        { label: 'Renomear', onClick: () => editWorkspace(ws) },
        ...(ws.isDefault ? [] : ['-', { label: 'Excluir mapeamento', danger: true, onClick: () => deleteWorkspace(ws) }]),
      ]);
    };
  });

  grid.querySelector('#hub-create').onclick = () => createWorkspace();
}

/** Primeiro nome livre para a ferramenta: "Meta Ads", depois "Meta Ads 2". */
function suggestName(tool) {
  const base = tool.id === 'ga4' ? 'GA4' : tool.id === 'other' ? 'Novo mapeamento' : tool.label;
  const taken = new Set(state.workspaces.map((w) => normalizeKey(w.name)));
  if (!taken.has(normalizeKey(base))) return base;
  for (let i = 2; i < 100; i += 1) {
    if (!taken.has(normalizeKey(`${base} ${i}`))) return `${base} ${i}`;
  }
  return base;
}

const rulesHint = (tool) =>
  tool.rules === 'ga4'
    ? 'Com as regras do GA4: snake_case, nomes e prefixos reservados e os limites oficiais.'
    : `Sem as regras de nome do GA4: eventos e parâmetros ficam com o nome que o ${tool.label} espera.`;

async function createWorkspace() {
  let tool = toolOf('meta-ads');
  let nameTouched = false;

  const created = await openModal({
    title: 'Novo mapeamento',
    subtitle: 'Mesma estrutura do GA4: pastas, páginas, catálogo e grupos próprios, e um contrato exportado só dele.',
    wide: true,
    body: `
      <div class="field">
        <label class="field__label">Ferramenta</label>
        <div class="tool-grid">
          ${TOOLS.map(
            (t) => `<button type="button" class="tool-tile" data-tool="${t.id}" aria-pressed="${t.id === tool.id}">
                      <span class="ws-badge ws-badge--small" style="background:${t.color}">${esc(t.short)}</span>
                      <span>${esc(t.label)}</span>
                    </button>`,
          ).join('')}
        </div>
        <div class="field__hint" id="nw-rules">${esc(rulesHint(tool))}</div>
      </div>
      <div class="grid-2">
        <div class="field">
          <label class="field__label" for="nw-name">Nome</label>
          <input class="input" id="nw-name" value="${esc(suggestName(tool))}" autocomplete="off" maxlength="60" />
        </div>
        <div class="field">
          <label class="field__label" for="nw-desc">Descrição (opcional)</label>
          <input class="input" id="nw-desc" placeholder="ex.: app iOS e Android, conta Brasil" autocomplete="off" maxlength="240" />
        </div>
      </div>
      <div class="form-error" id="nw-error" role="alert" hidden></div>`,
    footer: `
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--primary" id="nw-save">Criar mapeamento</button>`,
    onMount: (modal, close) => {
      const name = modal.querySelector('#nw-name');
      const error = modal.querySelector('#nw-error');
      const save = modal.querySelector('#nw-save');

      name.oninput = () => {
        nameTouched = true;
      };

      modal.querySelectorAll('[data-tool]').forEach((tile) => {
        tile.onclick = () => {
          tool = toolOf(tile.dataset.tool);
          modal.querySelectorAll('[data-tool]').forEach((t) => t.setAttribute('aria-pressed', String(t === tile)));
          modal.querySelector('#nw-rules').textContent = rulesHint(tool);
          if (!nameTouched) name.value = suggestName(tool);
        };
      });

      const submit = async () => {
        const value = name.value.trim();
        if (!value) {
          error.textContent = 'Dê um nome ao mapeamento.';
          error.hidden = false;
          return;
        }
        save.disabled = true;
        try {
          const { workspace } = await api.createWorkspace({
            name: value,
            tool: tool.id,
            description: modal.querySelector('#nw-desc').value.trim(),
          });
          close(workspace);
        } catch (err) {
          error.textContent = err.message;
          error.hidden = false;
          save.disabled = false;
        }
      };

      name.onkeydown = (e) => e.key === 'Enter' && submit();
      save.onclick = submit;
      name.focus();
      name.select();
    },
  });

  if (!created) return;
  await loadWorkspaces();
  toast.ok(`Mapeamento "${created.name}" criado.`);
  enter?.(created.id);
}

async function editWorkspace(ws) {
  const result = await openModal({
    title: 'Renomear mapeamento',
    subtitle: 'O endereço e os arquivos do mapeamento não mudam, só o nome exibido.',
    body: `
      <div class="field">
        <label class="field__label" for="ew-name">Nome</label>
        <input class="input" id="ew-name" value="${esc(ws.name)}" maxlength="60" autocomplete="off" />
      </div>
      <div class="field">
        <label class="field__label" for="ew-desc">Descrição</label>
        <input class="input" id="ew-desc" value="${esc(ws.description || '')}" maxlength="240" autocomplete="off" />
      </div>
      <div class="form-error" id="ew-error" role="alert" hidden></div>`,
    footer: `
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--primary" id="ew-save">Salvar</button>`,
    onMount: (modal, close) => {
      const error = modal.querySelector('#ew-error');
      const submit = async () => {
        try {
          const { workspace } = await api.updateWorkspace(ws.id, {
            name: modal.querySelector('#ew-name').value,
            description: modal.querySelector('#ew-desc').value,
          });
          close(workspace);
        } catch (err) {
          error.textContent = err.message;
          error.hidden = false;
        }
      };
      modal.querySelector('#ew-name').onkeydown = (e) => e.key === 'Enter' && submit();
      modal.querySelector('#ew-save').onclick = submit;
      modal.querySelector('#ew-name').select();
    },
  });
  if (!result) return;
  await loadWorkspaces();
  toast.ok('Mapeamento atualizado.');
}

/** Excluir apaga tudo do mapeamento, entao a confirmacao pede o nome digitado. */
async function deleteWorkspace(ws) {
  const confirmed = await openModal({
    title: 'Excluir mapeamento',
    subtitle: 'Esta ação não pode ser desfeita.',
    body: `
      <p class="import-summary">
        Excluir <strong>${esc(ws.name)}</strong> apaga ${plural(ws.stats?.pages || 0, 'página')}, as pastas, o catálogo e os grupos de
        parâmetros dele. Os backups já gravados no bucket continuam lá.
      </p>
      <div class="field">
        <label class="field__label" for="dw-name">Digite o nome do mapeamento para confirmar</label>
        <input class="input" id="dw-name" autocomplete="off" placeholder="${esc(ws.name)}" />
      </div>`,
    footer: `
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--danger" id="dw-go" disabled>Excluir mapeamento</button>`,
    onMount: (modal, close) => {
      const input = modal.querySelector('#dw-name');
      const go = modal.querySelector('#dw-go');
      input.oninput = () => {
        go.disabled = input.value.trim() !== ws.name;
      };
      go.onclick = () => close(true);
      input.focus();
    },
  });
  if (!confirmed) return;

  try {
    await api.deleteWorkspace(ws.id);
    await loadWorkspaces();
    toast.ok(`Mapeamento "${ws.name}" excluído.`);
  } catch (err) {
    toast.error(err.message);
  }
}
