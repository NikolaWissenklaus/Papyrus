/*
 * Navegador do bucket e os fluxos de importacao que saem dele.
 *
 * O bucket guarda tres tipos de arquivo do Papyrus, cada um em um lugar:
 *
 *   <prefixo>versions/AAAAMMDD.json   backup diario (mapas completos)
 *   <prefixo>catalog/<nome>.json      catalogo exportado
 *   <prefixo><nome>.json              contrato exportado pelo botao Exportar
 *
 * A lista mostra so os .json abaixo do prefixo configurado. O que o arquivo
 * realmente e, quem decide e o servidor, olhando o conteudo (ver
 * server/lib/importer.js); a pasta so serve de rotulo enquanto ele nao e lido.
 */

import { api } from '../api.js';
import { state, loadTree, loadCatalog, flushSave, reloadOpenPage } from '../store.js';
import { esc, formatDate, formatBytes, plural } from '../util.js';
import { openModal } from '../ui/modal.js';
import { toast } from '../ui/toast.js';

/** Status do GCS, ou null depois de explicar o que falta. */
export async function gcsReadyOrExplain() {
  try {
    const status = await api.gcsStatus();
    if (status.ready) return status;
    toast.error(status.reason || 'Configure o Google Cloud Storage na aba Configurações.', 6000);
  } catch (err) {
    toast.error(err.message);
  }
  return null;
}

const FOLDERS = [
  { id: 'all', label: 'Todos' },
  { id: 'versions', label: 'Backups', test: (name) => name.startsWith('versions/') },
  { id: 'catalog', label: 'Catálogos', test: (name) => name.startsWith('catalog/') },
  { id: 'maps', label: 'Mapas exportados', test: (name) => !name.startsWith('versions/') && !name.startsWith('catalog/') },
];

const backupDate = (name) => {
  const match = /^versions\/(\d{4})(\d{2})(\d{2})\.json$/i.exec(name);
  return match ? `${match[3]}/${match[2]}/${match[1]}` : null;
};

/** Rotulo do arquivo pela pasta onde ele esta. */
export function describeStorageObject(name) {
  const date = backupDate(name);
  if (date) return `Backup de ${date}`;
  if (name.startsWith('versions/')) return `Backup · ${name.slice('versions/'.length)}`;
  if (name.startsWith('catalog/')) return `Catálogo · ${name.slice('catalog/'.length)}`;
  return name;
}

const kindChip = (name) => {
  if (name.startsWith('versions/')) return '<span class="chip chip--view">backup</span>';
  if (name.startsWith('catalog/')) return '<span class="chip chip--automatic">catálogo</span>';
  return '<span class="chip">mapa</span>';
};

/**
 * Lista os .json do bucket e devolve o escolhido.
 * @param {{ title?: string, subtitle?: string, prefer?: 'all'|'versions'|'catalog'|'maps' }} options
 * @returns {Promise<{ name: string, size: number, updated: string } | null>}
 */
export function pickStorageObject({ title = 'Escolher arquivo do Storage', subtitle = '', prefer = 'all' } = {}) {
  let folder = prefer;
  let query = '';
  let objects = [];
  let selected = null;

  return openModal({
    title,
    subtitle: subtitle || 'Arquivos .json abaixo do prefixo configurado, do mais recente para o mais antigo.',
    wide: true,
    body: `
      <div class="storage-bar">
        <div class="pill-group" id="st-folders">
          ${FOLDERS.map((f) => `<button type="button" class="pill" data-folder="${f.id}" aria-pressed="${f.id === folder}">${esc(f.label)}</button>`).join('')}
        </div>
        <input class="input input--search" id="st-search" placeholder="Buscar arquivo…" autocomplete="off" />
      </div>
      <div class="storage-list" id="st-list"><div class="storage-list__state">Lendo o bucket…</div></div>
      <div class="field__hint" id="st-where"></div>`,
    footer: `
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--primary" id="st-go" disabled>Continuar</button>`,
    onMount: async (modal, close) => {
      const list = modal.querySelector('#st-list');
      const go = modal.querySelector('#st-go');

      function render() {
        const test = FOLDERS.find((f) => f.id === folder)?.test || (() => true);
        const q = query.trim().toLowerCase();
        const rows = objects.filter((o) => test(o.name) && (!q || o.name.toLowerCase().includes(q)));

        if (!rows.length) {
          list.innerHTML = `<div class="storage-list__state">${objects.length ? 'Nenhum arquivo neste filtro.' : 'Nenhum .json no bucket ainda.'}</div>`;
          return;
        }

        list.innerHTML = rows
          .map(
            (o) => `
            <button type="button" class="storage-row${selected?.name === o.name ? ' is-selected' : ''}" data-name="${esc(o.name)}">
              ${kindChip(o.name)}
              <span class="storage-row__name">
                <strong>${esc(describeStorageObject(o.name))}</strong>
                <code>${esc(o.name)}</code>
              </span>
              <span class="storage-row__meta">${formatBytes(o.size)}<br />${formatDate(o.updated)}</span>
            </button>`,
          )
          .join('');

        list.querySelectorAll('.storage-row').forEach((row) => {
          const object = objects.find((o) => o.name === row.dataset.name);
          row.onclick = () => {
            selected = object;
            go.disabled = false;
            list.querySelectorAll('.storage-row').forEach((r) => r.classList.toggle('is-selected', r === row));
          };
          row.ondblclick = () => close(object);
        });
      }

      modal.querySelectorAll('[data-folder]').forEach((btn) => {
        btn.onclick = () => {
          folder = btn.dataset.folder;
          modal.querySelectorAll('[data-folder]').forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
          render();
        };
      });
      modal.querySelector('#st-search').oninput = (e) => {
        query = e.target.value;
        render();
      };
      go.onclick = () => selected && close(selected);

      try {
        const res = await api.listGcsObjects();
        objects = res.objects || [];
        modal.querySelector('#st-where').innerHTML = `Bucket <code>${esc(res.bucket)}</code>${res.prefix ? ` · prefixo <code>${esc(res.prefix)}</code>` : ''}`;
        render();
      } catch (err) {
        list.innerHTML = `<div class="storage-list__state" style="color:var(--danger)">${esc(err.message)}</div>`;
      }
    },
  });
}

/* Importacao de mapas */

const conflictChoice = (allowOverwrite = true) => `
  <div class="field">
    <label class="field__label">Página com o mesmo nome</label>
    <label class="radio-card">
      <input type="radio" name="im-conflict" value="skip" checked />
      <span><strong>Manter a atual</strong><br /><span class="field__hint">O arquivo é ignorado para essa página e aparece no relatório.</span></span>
    </label>
    ${
      allowOverwrite
        ? `<label class="radio-card">
             <input type="radio" name="im-conflict" value="overwrite" />
             <span><strong>Substituir pelo arquivo</strong><br /><span class="field__hint">A página que já existe recebe o conteúdo do arquivo, no lugar onde está.</span></span>
           </label>`
        : ''
    }
  </div>`;

const destinationNote = (destination) =>
  `<p class="field__hint">Destino: ${destination ? `pasta <code>${esc(destination)}</code>` : 'raiz do mapeamento'}.</p>`;

/** Opcoes conforme o que o arquivo e. Devolve null quando a pessoa desiste. */
function mapImportOptions(object, summary, destination) {
  if (summary.kind === 'catalog') {
    return openModal({
      title: 'Este arquivo é um catálogo',
      subtitle: describeStorageObject(object),
      body: `<p class="import-summary">Catálogo com ${plural(summary.events, 'evento')} e ${plural(summary.params, 'parâmetro')}. Catálogo entra pela aba Catálogo, onde dá para escolher entre mesclar e substituir.</p>`,
      footer: `
        <button class="btn btn--ghost" data-close="null">Cancelar</button>
        <button class="btn btn--primary" data-close="catalog">Importar no Catálogo</button>`,
    }).then((choice) => {
      if (choice === 'catalog') window.dispatchEvent(new CustomEvent('papyrus:catalog-import', { detail: { object } }));
      return null;
    });
  }

  if (!['page', 'backup', 'contract'].includes(summary.kind)) {
    toast.error('Formato não reconhecido: escolha um backup (versions/), um contrato exportado ou uma página do Papyrus.', 6000);
    return Promise.resolve(null);
  }

  const backup = summary.kind === 'backup' ? summary : null;
  const defaultSource = backup?.workspaces.find((w) => w.id === state.workspace.id)?.id || backup?.workspaces[0]?.id;

  const intro = {
    page: () => `Página <strong>${esc(summary.name || object)}</strong>, com ${plural(summary.events, 'evento')}.`,
    contract: () =>
      `Contrato exportado com ${plural(summary.pages, 'página')} e ${plural(summary.events, 'evento')}. ` +
      'O contrato não tem o desenho do canvas: cada página é remontada com os cards em colunas, já ligados ao catálogo quando o evento existe nele.',
    backup: () =>
      `Backup${summary.date ? ` de ${esc(backupDate(`versions/${summary.date}.json`) || summary.date)}` : ''}, com ${plural(summary.workspaces.length, 'mapeamento')}. ` +
      'Voltam as páginas completas (com o desenho do canvas), as pastas e as cores. O catálogo do backup completa o deste mapeamento: entra o que falta, nada é sobrescrito.',
  }[summary.kind]();

  return openModal({
    title: 'Importar do Storage',
    subtitle: describeStorageObject(object),
    wide: summary.kind === 'backup',
    body: `
      <p class="import-summary">${intro}</p>
      ${
        backup
          ? `<div class="field">
               <label class="field__label" for="im-source">Restaurar qual mapeamento do backup</label>
               <select class="select" id="im-source">
                 ${backup.workspaces.map((w) => `<option value="${esc(w.id)}"${w.id === defaultSource ? ' selected' : ''}>${esc(w.name)} · ${plural(w.pages, 'página')} · ${plural(w.events, 'card')}</option>`).join('')}
               </select>
               <div class="field__hint">Entra em "${esc(state.workspace.name)}", o mapeamento aberto agora.</div>
             </div>`
          : destinationNote(destination)
      }
      ${conflictChoice(summary.kind !== 'contract')}
      ${summary.kind === 'contract' ? '<p class="field__hint">Página que já existe é sempre mantida: substituir por um contrato apagaria os prints, pins e conectores dela.</p>' : ''}`,
    footer: `
      <button class="btn btn--ghost" data-close="null">Cancelar</button>
      <button class="btn btn--primary" id="im-go">Importar</button>`,
    onMount: (modal, close) => {
      modal.querySelector('#im-go').onclick = () =>
        close({
          onConflict: modal.querySelector('input[name="im-conflict"]:checked')?.value || 'skip',
          sourceWorkspace: modal.querySelector('#im-source')?.value || null,
        });
    },
  });
}

/** Fluxo completo: escolher no bucket, ver o que e, decidir e importar. */
export async function importMapsFromStorage({ destination = '' } = {}) {
  if (!(await gcsReadyOrExplain())) return;

  const picked = await pickStorageObject({ title: 'Importar mapas do Storage', prefer: 'versions' });
  if (!picked) return;

  let summary;
  try {
    ({ summary } = await api.inspectStorageObject(picked.name));
  } catch (err) {
    toast.error(err.message);
    return;
  }

  const options = await mapImportOptions(picked.name, summary, destination);
  if (!options) return;

  try {
    await flushSave();
    const report = await api.importFromStorage({ object: picked.name, destination, ...options });
    await afterImport(report);
  } catch (err) {
    toast.error(err.message);
  }
}

/** Depois de qualquer importacao: arvore, catalogo e pagina aberta em dia, e o relatorio. */
export async function afterImport(report) {
  await loadTree();
  if (report.catalogAdded) await loadCatalog({ resync: false });
  if (state.currentPath && (report.replaced || []).includes(state.currentPath)) await reloadOpenPage();
  reportImport(report);
}

export function reportImport(report) {
  const imported = report.imported?.length || 0;
  const replaced = report.replaced?.length || 0;
  const ignored = report.ignored?.length || 0;

  const parts = [];
  if (imported) parts.push(`${plural(imported, 'página importada', 'páginas importadas')}`);
  if (replaced) parts.push(`${plural(replaced, 'página substituída', 'páginas substituídas')}`);
  if (report.folders) parts.push(`${plural(report.folders, 'pasta criada', 'pastas criadas')}`);
  if (report.catalogAdded) parts.push(`${report.catalogAdded} item(ns) no catálogo`);
  if (parts.length) toast.ok(`${parts.join(' · ')}.`, 5000);
  if (!imported && !replaced && !ignored) toast.info('Nada foi importado.');

  if (ignored) {
    openModal({
      title: 'Itens ignorados',
      subtitle: `${plural(ignored, 'item não foi importado', 'itens não foram importados')}.`,
      body: report.ignored
        .map(
          (i) => `<div class="issue">
                    <span class="issue__tag" data-level="warn">ignorado</span>
                    <span><code>${esc(i.file)}</code><div class="issue__where">${esc(i.reason)}</div></span>
                  </div>`,
        )
        .join(''),
      footer: '<button class="btn btn--primary" data-close="ok">Entendi</button>',
    });
  }
}
