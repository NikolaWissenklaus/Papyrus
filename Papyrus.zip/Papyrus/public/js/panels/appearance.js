/*
 * Aparencia do canvas: cor de fundo e estilo da malha.
 *
 * Os dois ficam na pagina (`doc.background` e `doc.grid`), como a cor de
 * fundo ja ficava, entao valem para todo mundo que abrir a pagina e saem
 * iguais na foto e no PDF. O padrao (cinza bem claro com pontos) nao e
 * gravado: a pagina sem esses campos segue o tema da ferramenta.
 *
 * O controle aparece em dois lugares, com o mesmo codigo: no botao de
 * aparencia ao lado do zoom e no inspetor, quando nada esta selecionado.
 */

import { state, commit, flushSave } from '../store.js';
import { api } from '../api.js';
import { CANVAS_PRESETS, DEFAULT_CANVAS_BG, GRID_STYLES } from '../constants.js';
import { esc } from '../util.js';
import { confirm } from '../ui/modal.js';
import { toast } from '../ui/toast.js';

let popover = null;

/** HTML dos controles. `idPrefix` separa o popover do inspetor na mesma tela. */
export function appearanceControls(idPrefix = 'ap') {
  const current = String(state.doc?.background || DEFAULT_CANVAS_BG).toUpperCase();
  const grid = state.doc?.grid || 'dots';
  const preset = CANVAS_PRESETS.find((p) => p.value === current);

  return `
    <div class="appearance" data-appearance>
      <div class="field">
        <label class="field__label">Fundo</label>
        <div class="appearance__presets">
          ${CANVAS_PRESETS.map(
            (p) => `<button type="button" class="appearance__preset" data-bg="${p.value}" aria-pressed="${p.value === current}">
                      <span class="appearance__swatch" style="background:${p.value}"></span>${esc(p.label)}
                    </button>`,
          ).join('')}
          <label class="appearance__preset appearance__preset--custom" aria-pressed="${!preset}" title="Outra cor">
            <input type="color" id="${idPrefix}-bg-custom" value="${esc(current)}" />
            <span>Outra</span>
          </label>
        </div>
      </div>
      <div class="field">
        <label class="field__label">Grade</label>
        <div class="pill-group">
          ${GRID_STYLES.map(
            (g) => `<button type="button" class="pill" data-grid="${g.id}" aria-pressed="${g.id === grid}">${esc(g.label)}</button>`,
          ).join('')}
        </div>
      </div>
      <div class="appearance__foot">
        <span class="field__hint">Fica salvo nesta página e sai igual na foto e no PDF.</span>
        <button type="button" class="btn btn--mini" data-apply-all>Aplicar em todas as páginas</button>
      </div>
    </div>`;
}

/** Grava fundo e grade na pagina aberta. Cor padrao nao e gravada. */
function applyToPage({ background, grid }, beforeCommit) {
  if (!state.doc) return;
  beforeCommit?.();
  commit((doc) => {
    if (background !== undefined) {
      if (!background || background.toUpperCase() === DEFAULT_CANVAS_BG) delete doc.background;
      else doc.background = background.toUpperCase();
    }
    if (grid !== undefined) {
      if (!grid || grid === 'dots') delete doc.grid;
      else doc.grid = grid;
    }
  }, { coalesceKey: 'doc.appearance' });
}

/**
 * Liga os controles renderizados por appearanceControls() dentro de `root`.
 * `beforeCommit` roda antes de cada gravacao (o inspetor usa para nao se
 * redesenhar por baixo do seletor de cor).
 */
export function bindAppearanceControls(root, idPrefix = 'ap', { beforeCommit } = {}) {
  const box = root.querySelector('[data-appearance]');
  if (!box) return;
  const apply = (values) => applyToPage(values, beforeCommit);

  const markBackground = (value) => {
    const upper = String(value).toUpperCase();
    let matched = false;
    box.querySelectorAll('[data-bg]').forEach((btn) => {
      const on = btn.dataset.bg === upper;
      matched ||= on;
      btn.setAttribute('aria-pressed', String(on));
    });
    box.querySelector('.appearance__preset--custom')?.setAttribute('aria-pressed', String(!matched));
  };

  box.querySelectorAll('[data-bg]').forEach((btn) => {
    btn.onclick = () => {
      apply({ background: btn.dataset.bg });
      const picker = box.querySelector(`#${idPrefix}-bg-custom`);
      if (picker) picker.value = btn.dataset.bg;
      markBackground(btn.dataset.bg);
    };
  });

  const picker = box.querySelector(`#${idPrefix}-bg-custom`);
  if (picker) {
    picker.oninput = () => {
      apply({ background: picker.value });
      markBackground(picker.value);
    };
  }

  box.querySelectorAll('[data-grid]').forEach((btn) => {
    btn.onclick = () => {
      apply({ grid: btn.dataset.grid });
      box.querySelectorAll('[data-grid]').forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
    };
  });

  box.querySelector('[data-apply-all]').onclick = async () => {
    const background = state.doc?.background || '';
    const grid = state.doc?.grid || 'dots';
    const ok = await confirm({
      title: 'Aplicar em todas as páginas',
      message: `O fundo e a grade desta página passam a valer para todas as páginas de "${state.workspace?.name}". Cada página continua podendo ser ajustada depois.`,
      confirmText: 'Aplicar',
      danger: false,
    });
    if (!ok) return;

    try {
      await flushSave();
      const { pages } = await api.applyAppearanceToAll({ background, grid });
      toast.ok(`Aparência aplicada em ${pages} página(s).`);
    } catch (err) {
      toast.error(err.message);
    }
  };
}

function closePopover() {
  popover?.remove();
  popover = null;
  document.removeEventListener('mousedown', onOutside, true);
  document.getElementById('canvas-appearance')?.classList.remove('is-active');
}

function onOutside(event) {
  if (popover && !popover.contains(event.target) && !event.target.closest('#canvas-appearance')) closePopover();
}

function togglePopover() {
  if (popover) return closePopover();
  if (!state.doc) {
    toast.info('Abra uma página para personalizar o canvas.');
    return;
  }

  popover = document.createElement('div');
  popover.className = 'appearance-popover';
  popover.innerHTML = `<div class="appearance-popover__title">Aparência do canvas</div>${appearanceControls('ap')}`;
  document.querySelector('.canvas-shell').appendChild(popover);
  bindAppearanceControls(popover, 'ap');

  document.getElementById('canvas-appearance')?.classList.add('is-active');
  setTimeout(() => document.addEventListener('mousedown', onOutside, true), 0);
}

export function initAppearance() {
  document.getElementById('canvas-appearance').onclick = () => togglePopover();
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && popover) closePopover();
  });
}

/** Fecha o popover quando a pagina troca: ele mostra o estado da pagina anterior. */
export function resetAppearance() {
  closePopover();
}
