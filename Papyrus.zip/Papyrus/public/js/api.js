/*
 * Unico ponto de contato com o back-end. Tudo passa por request(), que
 * normaliza os erros para a UI sempre receber um Error com mensagem legivel.
 *
 * As rotas de conteudo sao de um mapeamento: /api/w/<id>/... O id vem de
 * setApiWorkspace(), chamado pelo store ao entrar em um mapeamento. Usuarios,
 * mapeamentos, imagens e a integracao com o Storage sao globais.
 *
 * Resposta 401 com `code: unauthenticated` e sessao vencida. Quem decide o que
 * fazer (voltar para o login) e o session.js, avisado por configureApi().
 */

let workspaceId = null;
let unauthorizedHandler = null;
let contactHandler = null;

/** Liga os avisos de sessao vencida e de contato com o servidor. */
export function configureApi({ unauthorized, contact } = {}) {
  unauthorizedHandler = unauthorized || null;
  contactHandler = contact || null;
}

export function setApiWorkspace(id) {
  workspaceId = id || null;
}

async function request(url, options = {}) {
  const response = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  const text = await response.text();

  // Resposta que nao e JSON (proxy, pagina de erro, servidor que caiu no meio
  // da requisicao) nao pode virar um SyntaxError criptico na tela.
  let payload = {};
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = {};
    }
  }

  if (response.status === 401 && payload.code === 'unauthenticated') {
    unauthorizedHandler?.();
    const err = new Error(payload.error || 'Sua sessão expirou.');
    err.status = 401;
    throw err;
  }

  if (!response.ok) {
    const err = new Error(payload.error || `Erro ${response.status}`);
    err.status = response.status;
    err.payload = payload;
    throw err;
  }

  contactHandler?.();
  return payload;
}

const qs = (params) =>
  '?' + new URLSearchParams(Object.entries(params).filter(([, v]) => v != null)).toString();

/** Rota de conteudo do mapeamento aberto. */
function ws(path) {
  if (!workspaceId) throw new Error('Nenhum mapeamento aberto.');
  return `/api/w/${encodeURIComponent(workspaceId)}${path}`;
}

const enc = encodeURIComponent;

export const api = {
  /* Sessao */
  me: () => request('/api/auth/me'),
  logout: () => request('/api/auth/logout', { method: 'POST' }),
  touch: () => request('/api/auth/touch', { method: 'POST' }),
  changePassword: (currentPassword, newPassword) =>
    request('/api/auth/password', { method: 'POST', body: { currentPassword, newPassword } }),

  /* Usuarios (administrador) */
  listUsers: () => request('/api/users'),
  createUser: (body) => request('/api/users', { method: 'POST', body }),
  resetUserPassword: (username, password) =>
    request(`/api/users/${enc(username)}/password`, { method: 'PUT', body: { password } }),
  setUserAdmin: (username, admin) => request(`/api/users/${enc(username)}`, { method: 'PATCH', body: { admin } }),
  deleteUser: (username) => request(`/api/users/${enc(username)}`, { method: 'DELETE' }),

  /* Mapeamentos */
  listWorkspaces: () => request('/api/workspaces'),
  createWorkspace: (body) => request('/api/workspaces', { method: 'POST', body }),
  updateWorkspace: (id, body) => request(`/api/workspaces/${enc(id)}`, { method: 'PATCH', body }),
  deleteWorkspace: (id) => request(`/api/workspaces/${enc(id)}`, { method: 'DELETE' }),

  /* Arvore */
  getTree: () => request(ws('/tree')),
  createFolder: (parent, name, color) =>
    request(ws('/folders'), { method: 'POST', body: { parent, name, color } }),
  setFolderColor: (path, color) =>
    request(ws('/folders/color'), { method: 'PUT', body: { path, color } }),
  createPage: (parent, name) => request(ws('/pages'), { method: 'POST', body: { parent, name } }),
  rename: (path, name) => request(ws('/entry'), { method: 'PATCH', body: { path, name } }),
  remove: (path) => request(ws(`/entry${qs({ path })}`), { method: 'DELETE' }),
  move: (path, destination) => request(ws('/entry/move'), { method: 'POST', body: { path, destination } }),

  /* Paginas */
  readPage: (path) => request(ws(`/page${qs({ path })}`)),
  savePage: (path, doc) => request(ws('/page'), { method: 'PUT', body: { path, doc } }),
  applyAppearanceToAll: (body) => request(ws('/pages/appearance'), { method: 'POST', body }),

  /* Assets */
  uploadAsset: (dataUrl) => request('/api/assets', { method: 'POST', body: { dataUrl } }),

  /* Templates */
  getTemplates: () => request(ws('/templates')),
  saveTemplates: (groups) => request(ws('/templates'), { method: 'PUT', body: { groups } }),

  /* Consolidacao dos mapas */
  getDictionary: () => request(ws('/dictionary')),

  /* Catalogo */
  getCatalog: () => request(ws('/catalog')),
  createCatalogEvent: (body) => request(ws('/catalog/events'), { method: 'POST', body }),
  createCatalogEventFromCard: (body) => request(ws('/catalog/events/from-definition'), { method: 'POST', body }),
  updateCatalogEvent: (id, body) => request(ws(`/catalog/events/${enc(id)}`), { method: 'PUT', body }),
  deleteCatalogEvent: (id) => request(ws(`/catalog/events/${enc(id)}`), { method: 'DELETE' }),
  createCatalogParam: (body) => request(ws('/catalog/params'), { method: 'POST', body }),
  updateCatalogParam: (id, body) => request(ws(`/catalog/params/${enc(id)}`), { method: 'PUT', body }),
  deleteCatalogParam: (id) => request(ws(`/catalog/params/${enc(id)}`), { method: 'DELETE' }),
  planAdoption: () => request(ws('/catalog/adopt')),
  applyAdoption: () => request(ws('/catalog/adopt'), { method: 'POST' }),
  exportCatalog: (filename) => request(ws('/catalog/export'), { method: 'POST', body: { filename } }),
  importCatalog: (body) => request(ws('/catalog/import'), { method: 'POST', body }),

  /* Exportar */
  exportEvents: (body) => request(ws('/export/events'), { method: 'POST', body }),

  /* Google Cloud Storage e backup */
  gcsStatus: () => request('/api/gcs/status'),
  listGcsObjects: () => request('/api/gcs/objects'),
  getGcsSettings: () => request('/api/settings/gcs'),
  saveGcsSettings: (body) => request('/api/settings/gcs', { method: 'PUT', body }),
  testGcs: (body = {}) => request('/api/settings/gcs/test', { method: 'POST', body }),
  backupStatus: () => request('/api/backup/status'),
  runBackup: () => request('/api/backup/run', { method: 'POST' }),

  /* Importar */
  importFiles: (files, destination) =>
    request(ws('/import'), { method: 'POST', body: { source: 'inline', files, destination } }),
  inspectStorageObject: (object) => request(ws('/import/inspect'), { method: 'POST', body: { object } }),
  importFromStorage: (body) => request(ws('/import'), { method: 'POST', body: { source: 'gcs', ...body } }),
};
