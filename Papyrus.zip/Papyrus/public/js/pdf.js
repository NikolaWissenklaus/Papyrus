/*
 * PDF de uma imagem, sem biblioteca.
 *
 * A pagina do canvas ja sai como JPEG pelo Konva; o PDF so precisa embrulhar
 * esse JPEG. O formato permite isso direto (filtro DCTDecode): os bytes do
 * JPEG entram como estao no objeto de imagem, sem decodificar nem recomprimir.
 * Sao seis objetos (catalogo, arvore de paginas, pagina, imagem, conteudo e
 * metadados) mais a tabela de deslocamentos. Trazer uma biblioteca de PDF
 * inteira para isso pesaria mais que o resto do front-end junto.
 */

const encoder = new TextEncoder();

/** Tamanhos de pagina em pontos (1/72 de polegada). `fit` usa o tamanho do conteudo. */
export const PDF_PAGE_FORMATS = [
  { id: 'fit', label: 'Ajustada ao conteúdo' },
  { id: 'a4-landscape', label: 'A4 paisagem', width: 841.89, height: 595.28 },
  { id: 'a4-portrait', label: 'A4 retrato', width: 595.28, height: 841.89 },
  { id: 'a3-landscape', label: 'A3 paisagem', width: 1190.55, height: 841.89 },
];

/** Maior lado de pagina que os leitores de PDF aceitam (200 polegadas). */
const MAX_PAGE_SIDE = 14400;
const MARGIN = 28;

/**
 * Onde a imagem fica na pagina.
 *
 * Em `fit`, 1 pixel do canvas vira 0,75 ponto (96 dpi), e a resolucao extra da
 * imagem (2x, 3x) aparece como nitidez no zoom e na impressao, nao como pagina
 * maior. Nos formatos fixos a imagem e encaixada inteira, centralizada.
 */
export function pdfLayout({ format, imageWidth, imageHeight, ratio = 1 }) {
  const fixed = PDF_PAGE_FORMATS.find((f) => f.id === format && f.width);

  if (!fixed) {
    let width = (imageWidth / ratio) * 0.75;
    let height = (imageHeight / ratio) * 0.75;
    const shrink = Math.min(1, MAX_PAGE_SIDE / Math.max(width, height));
    width *= shrink;
    height *= shrink;
    return { pageWidth: width, pageHeight: height, drawX: 0, drawY: 0, drawWidth: width, drawHeight: height };
  }

  const scale = Math.min((fixed.width - MARGIN * 2) / imageWidth, (fixed.height - MARGIN * 2) / imageHeight);
  const drawWidth = imageWidth * scale;
  const drawHeight = imageHeight * scale;
  return {
    pageWidth: fixed.width,
    pageHeight: fixed.height,
    drawWidth,
    drawHeight,
    drawX: (fixed.width - drawWidth) / 2,
    drawY: (fixed.height - drawHeight) / 2,
  };
}

/** Texto do dicionario de metadados em UTF-16BE, que cobre acento e qualquer caractere. */
function pdfText(text) {
  const value = String(text ?? '');
  let hex = 'FEFF';
  for (let i = 0; i < value.length; i += 1) hex += value.charCodeAt(i).toString(16).padStart(4, '0');
  return `<${hex.toUpperCase()}>`;
}

function pdfDate(date) {
  const pad = (n) => String(n).padStart(2, '0');
  return (
    `D:${date.getUTCFullYear()}${pad(date.getUTCMonth() + 1)}${pad(date.getUTCDate())}` +
    `${pad(date.getUTCHours())}${pad(date.getUTCMinutes())}${pad(date.getUTCSeconds())}Z`
  );
}

const num = (value) => Number(value).toFixed(2).replace(/\.?0+$/, '');

/**
 * @param {{ jpeg: Uint8Array, imageWidth: number, imageHeight: number, title?: string,
 *           pageWidth: number, pageHeight: number, drawX: number, drawY: number,
 *           drawWidth: number, drawHeight: number }} spec
 * @returns {Uint8Array} bytes do arquivo .pdf
 */
export function buildImagePdf(spec) {
  const chunks = [];
  const offsets = [];
  let length = 0;

  const push = (data) => {
    const bytes = typeof data === 'string' ? encoder.encode(data) : data;
    chunks.push(bytes);
    length += bytes.length;
  };
  const object = (n, body) => {
    offsets[n] = length;
    push(`${n} 0 obj\n${body}\nendobj\n`);
  };

  // Cabecalho + linha com bytes acima de 127, que avisa os programas que o
  // arquivo e binario (recomendacao da especificacao).
  push('%PDF-1.4\n');
  push(new Uint8Array([0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a]));

  object(1, '<< /Type /Catalog /Pages 2 0 R >>');
  object(2, '<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
  object(
    3,
    `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${num(spec.pageWidth)} ${num(spec.pageHeight)}] ` +
      '/Resources << /XObject << /Im0 4 0 R >> /ProcSet [/PDF /ImageC] >> /Contents 5 0 R >>',
  );

  offsets[4] = length;
  push(
    `4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${spec.imageWidth} /Height ${spec.imageHeight} ` +
      `/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${spec.jpeg.length} >>\nstream\n`,
  );
  push(spec.jpeg);
  push('\nendstream\nendobj\n');

  const content =
    `q\n${num(spec.drawWidth)} 0 0 ${num(spec.drawHeight)} ${num(spec.drawX)} ${num(spec.drawY)} cm\n/Im0 Do\nQ\n`;
  object(5, `<< /Length ${encoder.encode(content).length} >>\nstream\n${content}endstream`);

  object(
    6,
    `<< /Title ${pdfText(spec.title || 'Papyrus')} /Producer ${pdfText('Papyrus')} ` +
      `/Creator ${pdfText('Papyrus')} /CreationDate (${pdfDate(new Date())}) >>`,
  );

  // Tabela de deslocamentos: cada linha tem exatamente 20 bytes.
  const xrefAt = length;
  let xref = 'xref\n0 7\n0000000000 65535 f \n';
  for (let n = 1; n <= 6; n += 1) xref += `${String(offsets[n]).padStart(10, '0')} 00000 n \n`;
  push(xref);
  push(`trailer\n<< /Size 7 /Root 1 0 R /Info 6 0 R >>\nstartxref\n${xrefAt}\n%%EOF\n`);

  const out = new Uint8Array(length);
  let position = 0;
  for (const chunk of chunks) {
    out.set(chunk, position);
    position += chunk.length;
  }
  return out;
}
