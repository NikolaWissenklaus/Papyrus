/*
 * Bootstrap da aplicacao. Confere a sessao, liga store, canvas, paineis e
 * teclado, e decide o que aparece primeiro: o hub de mapeamentos ou, quando a
 * URL ja aponta um (#/ga4), o proprio mapeamento.
 *
 * O mapeamento aberto fica no hash da URL. Recarregar a pagina volta para ele,
 * e o botao voltar do navegador leva de volta ao hub.
 */

import {
  state, on, setTool, setView, flushSave, undo, redo, removeElements, setUser,
  loadWorkspaces, enterWorkspace, leaveWorkspace, openPage, getValidationContext,
} from './store.js';
import { api, configureApi } from './api.js';
import { startSessionWatch, noteServerContact, endSession } from './session.js';
import {
  initStage, render as renderStage, applyViewport, zoomBy, resetZoom, fitToContent,
  duplicateSelection, selectAll, nudgeSelection, centerOn, isTyping,
} from './canvas/stage.js';
import { copySelection, handlePaste, insertImageFromFile } from './canvas/clipboard.js';
import { initSidebar } from './panels/sidebar.js';
import { initInspector } from './panels/inspector.js';
import { initTemplates } from './panels/templates.js';
import { initCatalog } from './panels/catalog.js';
import { initSettings } from './panels/settings.js';
import { initHub, showHub, hideHub } from './panels/hub.js';
import { renderUserChip, openUserMenu } from './panels/users.js';
import { initAppearance, resetAppearance } from './panels/appearance.js';
import { takeCanvasPhoto, exportEvents } from './panels/exporters.js';
import { validateDoc } from './quality/validation.js';
import { toast } from './ui/toast.js';
import { openModal, contextMenu } from './ui/modal.js';
import { esc, debounce } from './util.js';
import { toolOf, APP_VERSION, AUTHORSHIP } from './constants.js';

/* Inicializacao */

async function boot() {
  configureApi({ unauthorized: () => endSession('expired'), contact: noteServerContact });

  let session;
  try {
    session = await api.me();
  } catch (err) {
    // 401 ja mandou para o login. Qualquer outra coisa e servidor fora do ar.
    if (err.status !== 401) showBootError(err);
    return;
  }

  initStage(document.getElementById('stage-host'));
  initSidebar();
  initInspector();
  initTemplates();
  initCatalog();
  initSettings();
  initHub({ enter: (id) => openWorkspaceFromHub(id) });
  initAppearance();

  bindTabs();
  bindToolpad();
  bindTopbar();
  bindPanelToggles();
  bindHistoryButtons();
  bindZoom();
  bindValidationPanel();
  bindKeyboard();
  bindClipboard();
  bindSaveStatus();
  bindNavigation();
  renderFooters();

  updateEmptyState();
  on('page-opened', ({ doc }) => {
    updateEmptyState();
    resetAppearance();
    if (doc) {
      renderStage();
      applyViewport(doc.viewport);
    }
  });
  // Validar a cada tecla digitada disputaria o frame com o canvas. Rodar 250ms
  // depois da ultima alteracao passa despercebido e pesa bem menos.
  const scheduleValidation = debounce(refreshValidation, 250);
  on('doc', () => scheduleValidation());
  on('catalog', () => scheduleValidation());
  on('error', (err) => toast.error(err.message));
  on('workspace', (ws) => applyWorkspaceChrome(ws));
  on('user', () => renderUserChip(document.getElementById('app-user')));

  setUser(session.user);
  startSessionWatch({ ttlMs: session.sessionTtlMs, beforeEnd: () => flushSave() });

  try {
    await loadWorkspaces();
  } catch (err) {
    toast.error(`Falha ao carregar os mapeamentos: ${err.message}`);
  }

  // Antes da primeira navegacao: um voltar do navegador durante o boot nao se perde.
  window.addEventListener('hashchange', onHashChange);

  const wanted = workspaceFromHash();
  if (wanted && state.workspaces.some((w) => w.id === wanted)) await openWorkspace(wanted);
  else await goToHub({ replace: true });
}

function showBootError(err) {
  const grid = document.getElementById('hub-grid');
  document.getElementById('hub')?.classList.remove('is-loading');
  if (grid) {
    grid.innerHTML = `<div class="hub__loading" style="color:var(--danger)">
      Não foi possível falar com o servidor do Papyrus: ${esc(err.message)}. Confira se ele está no ar e recarregue a página.
    </div>`;
  }
}

function renderFooters() {
  document.querySelectorAll('[data-footer-credit]').forEach((node) => {
    node.textContent = AUTHORSHIP;
  });
  document.querySelectorAll('[data-footer-version]').forEach((node) => {
    node.textContent = `Papyrus v${APP_VERSION}`;
  });
}

/* Mapeamentos e hub */

const workspaceFromHash = () => decodeURIComponent(location.hash.replace(/^#\/?/, '').trim());

let switching = false;

async function openWorkspace(id) {
  if (switching) return;
  switching = true;
  try {
    await enterWorkspace(id);
    hideHub();
    setView('canvas');
  } catch (err) {
    toast.error(err.message);
    switching = false;
    await goToHub({ replace: true });
    return;
  }
  switching = false;
}

/** Vindo do hub, a entrada vira item do historico: o voltar do navegador leva ao hub. */
async function openWorkspaceFromHub(id) {
  await openWorkspace(id);
  if (state.workspace?.id === id && workspaceFromHash() !== id) location.hash = `#/${id}`;
}

async function goToHub({ replace = false } = {}) {
  await leaveWorkspace();
  if (location.hash) {
    if (replace) history.replaceState(null, '', location.pathname + location.search);
    else history.pushState(null, '', location.pathname + location.search);
  }
  await showHub();
}

function onHashChange() {
  const id = workspaceFromHash();
  if (!id) {
    if (state.workspace) goToHub({ replace: true });
    return;
  }
  if (id !== state.workspace?.id && state.workspaces.some((w) => w.id === id)) openWorkspace(id);
}

/** "Meta Ads" ou "GA4 · Google Analytics 4": a ferramenta so aparece quando acrescenta algo. */
function workspaceLabel(ws) {
  const tool = toolOf(ws.tool);
  const same = [tool.label, tool.short].some((name) => name.toLowerCase() === ws.name.toLowerCase());
  return same ? ws.name : `${ws.name} · ${tool.label}`;
}

/** Topbar, titulo da aba e rodape acompanham o mapeamento aberto. */
function applyWorkspaceChrome(ws) {
  const chip = document.getElementById('ws-chip');
  const footer = document.getElementById('footer-ws');
  resetAppearance();

  if (!ws) {
    chip.innerHTML = '';
    footer.textContent = '';
    return;
  }

  const tool = toolOf(ws.tool);
  chip.innerHTML = `
    <span class="ws-badge ws-badge--tiny" style="background:${tool.color}">${esc(tool.short)}</span>
    <span class="ws-chip__name">${esc(ws.name)}</span>
    <svg class="ws-chip__caret" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 4.5L6 7.5l3-3" /></svg>`;
  chip.title = `${workspaceLabel(ws)}. Clique para trocar de mapeamento.`;
  document.title = `Papyrus | ${ws.name}`;
  footer.textContent = workspaceLabel(ws);
}

function openWorkspaceMenu(anchor) {
  const rect = anchor.getBoundingClientRect();
  const others = state.workspaces.filter((w) => w.id !== state.workspace?.id);
  contextMenu(rect.left, rect.bottom + 6, [
    ...others.map((w) => ({
      label: `Abrir ${workspaceLabel(w)}`,
      onClick: () => openWorkspaceFromHub(w.id),
    })),
    ...(others.length ? ['-'] : []),
    { label: 'Ver todos os mapeamentos', onClick: () => goToHub() },
  ]);
}

/* Abas principais */

function bindTabs() {
  document.querySelectorAll('.topbar .tab').forEach((tab) => {
    tab.onclick = () => setView(tab.dataset.view);
  });

  // Qualquer modulo troca de aba com setView(); aqui so o DOM acompanha.
  on('view', (view) => {
    document.querySelectorAll('.topbar .tab').forEach((t) => t.classList.toggle('is-active', t.dataset.view === view));
    document.querySelectorAll('.view').forEach((v) => v.classList.toggle('is-active', v.dataset.view === view));
  });
}

/* Navegacao entre paineis */

function bindNavigation() {
  // "Abrir" no catalogo: vai para o canvas, abre a pagina e centraliza no card.
  window.addEventListener('papyrus:goto', async (e) => {
    const { path, elementId, catalogEventId } = e.detail || {};
    if (!path) return;
    setView('canvas');
    try {
      await openPage(path);
      requestAnimationFrame(() => {
        const target =
          elementId ||
          state.doc?.elements.find((el) => el.type === 'event' && el.data?.catalogEventId === catalogEventId)?.id;
        if (target) centerOn(target);
      });
    } catch (err) {
      toast.error(err.message);
    }
  });
}

/* Toolpad */

function bindToolpad() {
  document.querySelectorAll('.tool').forEach((btn) => {
    btn.onclick = () => setTool(btn.dataset.tool);
  });

  on('tool', (tool) => {
    document.querySelectorAll('.tool').forEach((b) => b.classList.toggle('is-active', b.dataset.tool === tool));
  });

  document.getElementById('file-image').addEventListener('change', async (e) => {
    const files = [...e.target.files];
    e.target.value = '';
    for (const file of files) await insertImageFromFile(file);
  });
}

/* Topbar */

function bindTopbar() {
  document.getElementById('btn-photo').onclick = () => takeCanvasPhoto();
  document.getElementById('btn-export').onclick = () => exportEvents();
  document.getElementById('btn-help').onclick = () => showShortcuts();
  document.getElementById('ws-chip').onclick = (e) => openWorkspaceMenu(e.currentTarget);
  document.getElementById('app-user').addEventListener('click', (e) => {
    const chip = e.target.closest('.user-chip');
    if (chip) openUserMenu(chip, { onSwitchWorkspace: () => goToHub() });
  });
}

/* Painéis recolhíveis */

const PANELS = {
  sidebar: { class: 'sidebar-collapsed', button: 'btn-toggle-sidebar', storage: 'papyrus.sidebar' },
  inspector: { class: 'inspector-collapsed', button: 'btn-toggle-inspector', storage: 'papyrus.inspector' },
};

export function togglePanel(name, force) {
  const panel = PANELS[name];
  const workspace = document.getElementById('workspace');
  const collapsed = force ?? !workspace.classList.contains(panel.class);

  workspace.classList.toggle(panel.class, collapsed);
  document.getElementById(panel.button).classList.toggle('is-active', collapsed);
  localStorage.setItem(panel.storage, collapsed ? '1' : '0');
}

function bindPanelToggles() {
  for (const name of Object.keys(PANELS)) {
    document.getElementById(PANELS[name].button).onclick = () => togglePanel(name);
    // Restaura o estado da ultima sessao.
    if (localStorage.getItem(PANELS[name].storage) === '1') togglePanel(name, true);
  }

  // Duplo clique em um card de evento reabre o inspetor, se ele estiver recolhido.
  window.addEventListener('papyrus:focus-inspector', () => togglePanel('inspector', false));
}

/* Botões de undo/redo */

function bindHistoryButtons() {
  const undoBtn = document.getElementById('btn-undo');
  const redoBtn = document.getElementById('btn-redo');

  undoBtn.onclick = () => undo();
  redoBtn.onclick = () => redo();

  on('history', ({ undo: canUndo, redo: canRedo }) => {
    undoBtn.disabled = !canUndo;
    redoBtn.disabled = !canRedo;
  });
  on('page-opened', () => {
    undoBtn.disabled = true;
    redoBtn.disabled = true;
  });
}

function bindSaveStatus() {
  const node = document.getElementById('save-status');
  const labels = { idle: '—', saving: 'salvando…', saved: 'salvo', error: 'erro ao salvar' };

  on('save-status', (status) => {
    node.dataset.state = status;
    node.textContent = labels[status] || '—';
  });

  // Garante que nada se perca quando a aba e fechada.
  window.addEventListener('beforeunload', () => {
    if (state.saveStatus === 'saving') flushSave();
  });
}

/* Zoom */

function bindZoom() {
  document.getElementById('zoom-in').onclick = () => zoomBy(1.2);
  document.getElementById('zoom-out').onclick = () => zoomBy(1 / 1.2);
  document.getElementById('zoom-level').onclick = () => resetZoom();
  document.getElementById('zoom-fit').onclick = () => fitToContent();

  window.addEventListener('papyrus:zoom', (e) => {
    document.getElementById('zoom-level').textContent = `${Math.round(e.detail * 100)}%`;
  });
}

/* Painel de validacao */

function bindValidationPanel() {
  const toggle = document.getElementById('validation-toggle');
  const body = document.getElementById('validation-body');

  toggle.onclick = () => {
    body.hidden = !body.hidden;
    if (!body.hidden) refreshValidation();
  };
}

function refreshValidation() {
  const dot = document.getElementById('validation-dot');
  const label = document.getElementById('validation-label');
  const body = document.getElementById('validation-body');

  if (!state.doc) {
    dot.dataset.level = '';
    label.textContent = 'Validação';
    body.innerHTML = '';
    return;
  }

  const { issues, counts } = validateDoc(state.doc, getValidationContext());

  dot.dataset.level = counts.error ? 'error' : counts.warn ? 'warn' : '';
  label.textContent = issues.length
    ? `${counts.error} erro(s) · ${counts.warn} aviso(s)`
    : 'Sem problemas';

  if (body.hidden) return;

  body.innerHTML = issues.length
    ? issues
        .slice(0, 80)
        .map(
          (i) => `
        <div class="issue" data-goto="${esc(i.elementId)}">
          <span class="issue__tag" data-level="${i.level}">${i.level === 'error' ? 'erro' : 'aviso'}</span>
          <span>
            ${esc(i.message)}
            <div class="issue__where">${esc(i.where || '')}</div>
          </span>
        </div>`,
        )
        .join('')
    : '<div class="field__hint" style="color:var(--ok);padding:6px">✓ Nenhum problema encontrado nesta página.</div>';

  body.querySelectorAll('[data-goto]').forEach((row) => {
    row.onclick = () => centerOn(row.dataset.goto);
  });
}

/* Estado vazio */

function updateEmptyState() {
  document.getElementById('canvas-empty').classList.toggle('is-visible', !state.doc);
}

/* Clipboard */

function bindClipboard() {
  document.addEventListener('paste', (e) => {
    if (state.view !== 'canvas' || !state.workspace) return;
    handlePaste(e);
  });

  document.addEventListener('copy', (e) => {
    if (state.view !== 'canvas' || !state.workspace || isTyping(e) || !state.selection.length) return;
    copySelection();
  });
}

/* Atalhos de teclado */

const TOOL_KEYS = {
  v: 'select', h: 'hand', e: 'event', n: 'sticky',
  t: 'text', r: 'rect', o: 'ellipse', p: 'pin', c: 'connector',
};

function bindKeyboard() {
  window.addEventListener('keydown', (e) => {
    if (isTyping(e)) return;
    // Com o hub na tela ou um modal aberto, os atalhos do canvas ficam quietos.
    if (!state.workspace || !document.getElementById('modal-layer').hidden) return;
    const mod = e.ctrlKey || e.metaKey;

    // Com modificador
    if (mod) {
      switch (e.key.toLowerCase()) {
        case 'z':
          e.preventDefault();
          e.shiftKey ? redo() : undo();
          return;
        case 'y':
          e.preventDefault();
          redo();
          return;
        case 'd':
          e.preventDefault();
          duplicateSelection();
          return;
        case 'a':
          if (state.view !== 'canvas') return;
          e.preventDefault();
          selectAll();
          return;
        case 's':
          e.preventDefault();
          if (state.doc) flushSave().then(() => toast.ok('Salvo.'));
          return;
        case '=':
        case '+':
          e.preventDefault();
          zoomBy(1.2);
          return;
        case '-':
          e.preventDefault();
          zoomBy(1 / 1.2);
          return;
        case '0':
          e.preventDefault();
          resetZoom();
          return;
        default:
          return;
      }
    }

    if (state.view !== 'canvas') return;

    // Sem modificador
    if (e.key === 'Delete' || e.key === 'Backspace') {
      if (state.selection.length) {
        e.preventDefault();
        removeElements(state.selection);
      }
      return;
    }

    if (e.key === '?' || (e.key === '/' && e.shiftKey)) {
      e.preventDefault();
      showShortcuts();
      return;
    }

    if (e.key === '[') {
      e.preventDefault();
      togglePanel('sidebar');
      return;
    }
    if (e.key === ']') {
      e.preventDefault();
      togglePanel('inspector');
      return;
    }

    if (e.key === '!' || (e.shiftKey && e.key === '1')) {
      e.preventDefault();
      fitToContent();
      return;
    }

    if (e.key.startsWith('Arrow')) {
      const step = e.shiftKey ? 10 : 1;
      const map = {
        ArrowUp: [0, -step], ArrowDown: [0, step],
        ArrowLeft: [-step, 0], ArrowRight: [step, 0],
      };
      const [dx, dy] = map[e.key];
      if (state.selection.length) {
        e.preventDefault();
        nudgeSelection(dx, dy);
      }
      return;
    }

    const tool = TOOL_KEYS[e.key.toLowerCase()];
    if (tool) setTool(tool);
  });
}

/* Ajuda */

const SHORTCUTS = [
  ['Selecionar', 'V'], ['Navegar (pan)', 'H ou Espaço'],
  ['Card de evento (do catálogo)', 'E'], ['Nota adesiva', 'N'],
  ['Texto', 'T'], ['Retângulo', 'R'],
  ['Círculo', 'O'], ['Pin', 'P'],
  ['Conector', 'C'], ['Colar print / elementos', 'Ctrl + V'],
  ['Copiar seleção', 'Ctrl + C'], ['Duplicar', 'Ctrl + D'],
  ['Desfazer', 'Ctrl + Z'], ['Refazer', 'Ctrl + Shift + Z'],
  ['Selecionar tudo', 'Ctrl + A'], ['Salvar agora', 'Ctrl + S'],
  ['Excluir seleção', 'Delete'], ['Mover 1px / 10px', 'Setas / Shift + Setas'],
  ['Zoom', 'Ctrl + Scroll'], ['Zoom 100%', 'Ctrl + 0'],
  ['Enquadrar conteúdo', 'Shift + 1'], ['Barra lateral', '['],
  ['Inspetor', ']'], ['Esta ajuda', '?'],
];

function showShortcuts() {
  openModal({
    title: 'Atalhos de teclado',
    subtitle: 'Tudo que dá para fazer sem tirar a mão do teclado.',
    wide: true,
    body: `<div class="shortcut-grid">
      ${SHORTCUTS.map(([label, keys]) => `
        <div class="shortcut">
          <span>${esc(label)}</span>
          <span>${keys.split(' ').map((k) => (k === '+' || k === 'ou' || k === '/' ? k : `<kbd>${esc(k)}</kbd>`)).join(' ')}</span>
        </div>`).join('')}
    </div>
    <div class="field__hint" style="margin-top:18px">
      <strong>Fluxo recomendado:</strong> cadastre os eventos e parâmetros no Catálogo → cole o print da tela (Ctrl+V)
      → marque os pontos de interação com pins (P) → crie os cards escolhendo o evento do catálogo (E) → conecte pin e
      card (C) → preencha exemplos, gatilho e governança no inspetor → valide no rodapé → exporte o JSON.
    </div>`,
    footer: `
      <a class="btn btn--ghost" href="/docs/papyrus-handbook.html" target="_blank" rel="noopener" style="margin-right:auto;text-decoration:none">Abrir a documentação ↗</a>
      <button class="btn btn--primary" data-close="ok">Fechar</button>`,
  });
}

boot();
