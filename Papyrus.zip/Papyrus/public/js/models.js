/*
 * Fabricas dos elementos do canvas.
 *
 * A forma de cada elemento que vai para o JSON nasce aqui, e so aqui. O
 * renderer e o inspetor sao consumidores: se um campo novo precisa existir,
 * ele comeca neste arquivo.
 *
 * Geometria (id, type, x, y, width...) fica na raiz do objeto. Regra de
 * negocio fica em `data`, e so o card de evento tem `data`.
 */

import { uid } from './util.js';
import { state } from './store.js';
import { DEFAULTS, GA4_ITEM_PARAMS, STICKY_COLORS } from './constants.js';
import {
  EVENT_ID_PARAM, generateEventId as buildEventId, linkCardData,
} from '../shared/catalog-sync.js';

/*
 * Parametro que identifica o evento. O Papyrus preenche na criacao e em toda
 * copia de card, mas o campo fica editavel: o valor gerado e um ponto de
 * partida, e o id pode vir de outro sistema. O que nao pode e repetir, e disso
 * cuida o validador.
 */
export { EVENT_ID_PARAM };

/** True na linha do event_id de um card. */
export function isEventIdParam(scope, param) {
  return scope === 'eventParams' && param?.name === EVENT_ID_PARAM;
}

/** Parametro individual da tabela de um card. */
export function createParam(overrides = {}) {
  return {
    id: uid('p'),
    name: '',
    type: 'string',
    required: false,
    example: '',
    description: '',
    ...overrides,
  };
}

/** Nome da pasta onde a pagina aberta esta gravada. Vazio se ela esta na raiz. */
export function currentFolderName() {
  const parts = String(state.currentPath || '').split('/');
  return parts.length > 1 ? parts[parts.length - 2] : '';
}

/*
 * O `event_id` (d + ASCII da pasta, p + timestamp, 6 + sorteio) e montado em
 * shared/catalog-sync.js, porque o servidor tambem gera ids ao remontar
 * paginas importadas. Aqui so entra a pasta da pagina aberta como padrao.
 */
export function generateEventId(folderName = currentFolderName()) {
  return buildEventId(folderName);
}

/** Card de Evento, o elemento central da ferramenta. */
export function createEventCard(x, y, overrides = {}) {
  return {
    id: uid('evt'),
    type: 'event',
    x,
    y,
    width: DEFAULTS.eventCardWidth,
    collapsed: false,
    data: {
      name: 'novo_evento',
      eventType: 'interaction',
      platform: ['web'],
      trigger: '',
      squad: '',
      owner: '',
      notes: '',
      ticketName: '',
      ticketId: '',
      ticketUrl: '',
      // O event_id ja vem preenchido. E a chave que amarra o planejamento ao
      // dado coletado, entao nao da para depender de alguem lembrar de criar.
      eventParams: [
        createParam({ name: EVENT_ID_PARAM, type: 'string', required: true, example: generateEventId() }),
      ],
      userParams: [],
      itemParams: [],
      /** IDs dos grupos ja importados, para nao importar o mesmo duas vezes. */
      linkedGroups: [],
    },
    ...overrides,
  };
}

/**
 * Card de evento nascido do catalogo: nome, tipo e parametros vem do evento
 * escolhido; o resto (gatilho, plataforma, governanca, ticket e os valores de
 * exemplo) e preenchido a mao no inspetor.
 */
export function createEventCardFromCatalog(x, y, catalogEvent, catalogIndex) {
  const card = createEventCard(x, y);
  card.data = linkCardData(card.data, catalogEvent, catalogIndex, { folderName: currentFolderName() });
  return card;
}

/*
 * Da um `event_id` novo a cada card de evento da lista.
 *
 * Copia de card e copia de tudo, menos da chave que identifica a coleta: dois
 * cards com o mesmo event_id apontariam para o mesmo evento no GA4. Vale para
 * colar, duplicar no canvas e duplicar a pagina inteira.
 *
 * `folderName` fica de fora quando o destino e a pagina aberta; a duplicacao de
 * pagina passa a pasta de destino, que nem sempre e a da pagina aberta.
 *
 * O Set evita repeticao dentro do proprio lote: o sufixo aleatorio ja torna a
 * colisao improvavel, mas duplicar dez cards de uma vez cai todo no mesmo
 * segundo, e ai o sorteio e a unica coisa separando um id do outro.
 */
export function renewEventIds(elements, folderName) {
  const used = new Set();

  for (const el of elements) {
    if (el.type !== 'event') continue;

    for (const param of el.data?.eventParams || []) {
      if (param.name !== EVENT_ID_PARAM) continue;

      let next = generateEventId(folderName);
      while (used.has(next)) next = generateEventId(folderName);
      used.add(next);
      param.example = next;
    }
  }

  return elements;
}

/** Injeta o bloco padrao de `items` do GA4 (chamado ao virar tipo Ecommerce). */
export function defaultItemParams() {
  return GA4_ITEM_PARAMS.map((p) => createParam(p));
}

/** Retangulo / elipse. */
export function createShape(kind, x, y) {
  return {
    id: uid(kind),
    type: kind, // 'rect' | 'ellipse'
    x,
    y,
    width: DEFAULTS.shapeSize.width,
    height: DEFAULTS.shapeSize.height,
    fill: 'transparent',
    stroke: '#5F6368',
    strokeWidth: 2,
    cornerRadius: kind === 'rect' ? 12 : 0,
    opacity: 1,
    label: '',
  };
}

/** Nota adesiva. */
export function createSticky(x, y) {
  return {
    id: uid('note'),
    type: 'sticky',
    x,
    y,
    width: DEFAULTS.stickySize,
    height: DEFAULTS.stickySize,
    fill: STICKY_COLORS[0],
    text: 'Nota',
    fontSize: 14,
  };
}

/** Caixa de texto livre. */
export function createText(x, y) {
  return {
    id: uid('txt'),
    type: 'text',
    x,
    y,
    width: DEFAULTS.textWidth,
    text: 'Texto',
    fontSize: 18,
    fontStyle: 'normal',
    fill: '#202124',
    align: 'left',
  };
}

/** Imagem (print de tela de referencia). */
export function createImage(x, y, { url, width, height }) {
  return {
    id: uid('img'),
    type: 'image',
    x,
    y,
    width,
    height,
    url,
    opacity: 1,
    cornerRadius: 8,
  };
}

/** Pin numerado que referencia um ponto especifico de uma imagem. */
export function createPin(x, y, label) {
  return {
    id: uid('pin'),
    type: 'pin',
    x,
    y,
    label: String(label ?? 1),
    color: '#EA4335',
    note: '',
  };
}

/*
 * Conector magnetico entre dois elementos.
 *
 * `from` e `to` guardam apenas { id, anchor }. A posicao real e recalculada a
 * cada render, e por isso a seta acompanha o elemento quando ele e movido ou
 * redimensionado.
 */
export function createConnector(from, to) {
  return {
    id: uid('cnn'),
    type: 'connector',
    from,
    to,
    stroke: '#5F6368',
    strokeWidth: 2,
    dash: false,
    arrow: true,
    label: '',
  };
}
