/*
 * Tela de login. Fica fora da barreira de sessao, entao nao importa nada do
 * app: so fala com /api/auth/login e manda para o hub quando der certo.
 */

const form = document.getElementById('login-form');
const user = document.getElementById('login-user');
const pass = document.getElementById('login-pass');
const submit = document.getElementById('login-submit');
const error = document.getElementById('login-error');
const notice = document.getElementById('login-notice');

/** Por que a pessoa caiu aqui, vindo do app. */
const REASONS = {
  idle: 'Sua sessão foi encerrada depois de 30 minutos sem atividade. Entre de novo para continuar.',
  expired: 'Sua sessão expirou. Entre de novo para continuar.',
  logout: 'Você saiu do Papyrus.',
};

const reason = new URLSearchParams(location.search).get('reason');
if (REASONS[reason]) {
  notice.textContent = REASONS[reason];
  notice.hidden = false;
}

// O endereco limpo evita que o aviso volte num F5 depois de entrar.
if (location.search) history.replaceState(null, '', '/login');

function showError(message) {
  error.textContent = message;
  error.hidden = !message;
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  showError('');

  const username = user.value.trim();
  const password = pass.value;
  if (!username || !password) {
    showError('Informe usuário e senha.');
    (username ? pass : user).focus();
    return;
  }

  submit.disabled = true;
  submit.textContent = 'Entrando…';

  try {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ username, password }),
    });
    const payload = await response.json().catch(() => ({}));

    if (!response.ok) {
      showError(payload.error || `Não foi possível entrar (erro ${response.status}).`);
      pass.select();
      return;
    }

    // Entrada nova sempre comeca pelo hub de mapeamentos.
    location.replace('/');
  } catch {
    showError('Sem conexão com o servidor do Papyrus. Confira se ele está no ar.');
  } finally {
    submit.disabled = false;
    submit.textContent = 'Entrar';
  }
});

user.focus();
