/*
 * Vocabulario fixo da ferramenta: taxonomias, cores funcionais e catalogos do
 * GA4. Fica tudo em um arquivo so para que canvas, inspetor, catalogo e
 * validador falem exatamente a mesma lingua.
 *
 * O que o servidor tambem precisa aplicar (tipos de parametro, nomes
 * reservados, limites) mora em /shared e e reexportado daqui.
 */

export {
  PARAM_TYPES, RESERVED_EVENT_NAMES, RESERVED_PREFIXES, GA4_LIMITS, GENERIC_NAME_LENGTH,
} from '../shared/rules.js';
export { TOOLS, TOOL_MAP, toolOf } from '../shared/tools.js';

/*
 * Tipos de evento e a cor da tarja do card. `color` e o tom pleno usado como
 * acento, `soft` e o fundo tintado do cabecalho e `text` e a variante escura,
 * legivel sobre o `soft`.
 */
export const EVENT_TYPES = [
  { id: 'view', label: 'View', color: '#1A73E8', soft: '#E8F0FE', text: '#1967D2' },
  { id: 'interaction', label: 'Interaction', color: '#188038', soft: '#E6F4EA', text: '#137333' },
  { id: 'ecommerce', label: 'Ecommerce', color: '#F9AB00', soft: '#FEF7E0', text: '#B06000' },
  { id: 'automatic', label: 'Automatic', color: '#A142F4', soft: '#F3E8FD', text: '#8430CE' },
];

export const EVENT_TYPE_MAP = Object.fromEntries(EVENT_TYPES.map((t) => [t.id, t]));

/** Plataformas de coleta (multi-selecao). */
export const PLATFORMS = [
  { id: 'web', label: 'Web' },
  { id: 'app', label: 'App' },
  { id: 'server', label: 'Server' },
];

/** Escopos de parametro dentro de um card. */
export const PARAM_SCOPES = {
  eventParams: 'Parâmetros de Evento',
  userParams: 'Propriedades de Usuário',
  itemParams: 'Parâmetros de Item (items[])',
};

/** Rotulo curto do escopo, usado em tabela e chip. */
export const PARAM_SCOPE_SHORT = {
  eventParams: 'Evento',
  userParams: 'Usuário',
  itemParams: 'Item',
};

/**
 * Parametros padrao do array `items` do GA4 Ecommerce.
 * Injetados automaticamente quando o card vira tipo "ecommerce".
 */
export const GA4_ITEM_PARAMS = [
  { name: 'item_id', type: 'string', required: true },
  { name: 'item_name', type: 'string', required: true },
  { name: 'affiliation', type: 'string', required: false },
  { name: 'coupon', type: 'string', required: false },
  { name: 'discount', type: 'float', required: false },
  { name: 'index', type: 'int', required: false },
  { name: 'item_brand', type: 'string', required: false },
  { name: 'item_category', type: 'string', required: false },
  { name: 'item_category2', type: 'string', required: false },
  { name: 'item_category3', type: 'string', required: false },
  { name: 'item_category4', type: 'string', required: false },
  { name: 'item_category5', type: 'string', required: false },
  { name: 'item_list_id', type: 'string', required: false },
  { name: 'item_list_name', type: 'string', required: false },
  { name: 'item_variant', type: 'string', required: false },
  { name: 'location_id', type: 'string', required: false },
  { name: 'price', type: 'float', required: true },
  { name: 'quantity', type: 'int', required: true },
];

/** Parametros de nivel de evento tipicos do Ecommerce GA4. */
export const GA4_ECOMMERCE_EVENT_PARAMS = [
  { name: 'currency', type: 'string', required: true },
  { name: 'value', type: 'float', required: true },
];

/** Paleta de preenchimento para formas e notas adesivas (tons discretos). */
export const SHAPE_COLORS = [
  '#FFFFFF', '#F1F3F4', '#E8F0FE', '#E6F4EA',
  '#FEF7E0', '#FCE8E6', '#F3E8FD', '#202124',
];

export const STICKY_COLORS = ['#FEF7C3', '#D8F0E1', '#DCE6FB', '#FBDDE3', '#F3E8FD', '#F1F3F4'];

/** Fundo do canvas quando a pagina nao define um. Espelha `--canvas-bg` do CSS. */
export const DEFAULT_CANVAS_BG = '#F8F9FA';

/**
 * Fundos prontos do canvas, os do seletor "Aparencia". A cor livre continua
 * disponivel ao lado deles.
 */
export const CANVAS_PRESETS = [
  { id: 'default', label: 'Padrão', value: DEFAULT_CANVAS_BG },
  { id: 'white', label: 'Branco', value: '#FFFFFF' },
  { id: 'gray', label: 'Cinza', value: '#E8EAED' },
  { id: 'black', label: 'Preto', value: '#202124' },
];

/** Estilos da malha de fundo. `dots` e o padrao e nao e gravado na pagina. */
export const GRID_STYLES = [
  { id: 'dots', label: 'Pontos' },
  { id: 'lines', label: 'Linhas' },
  { id: 'none', label: 'Sem grade' },
];

/** True para cor #RRGGBB escura, onde a tinta padrao (quase preta) sumiria. */
export function isDarkColor(hex) {
  const m = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex || '');
  if (!m) return false;
  const [r, g, b] = m.slice(1).map((c) => parseInt(c, 16));
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.5;
}

/** Cores que os elementos usam quando ninguem escolheu outra. */
export const DEFAULT_INK = {
  text: '#202124',
  stroke: '#5F6368',
};

/*
 * Tinta do canvas conforme o fundo. Em fundo escuro, texto, traco de forma e
 * conector que estao na cor padrao passam a ser desenhados claros; cor
 * escolhida a mao e respeitada sempre. O card de evento e a nota adesiva tem
 * fundo proprio e nao mudam.
 */
export function canvasInk(background) {
  if (isDarkColor(background)) {
    return {
      key: 'dark',
      text: '#E8EAED',
      stroke: '#BDC1C6',
      connector: '#BDC1C6',
      labelBg: '#303134',
      labelText: '#E8EAED',
    };
  }
  return {
    key: 'light',
    text: DEFAULT_INK.text,
    stroke: DEFAULT_INK.stroke,
    connector: DEFAULT_INK.stroke,
    labelBg: '#F8F9FA',
    labelText: '#5F6368',
  };
}

/** Cores da borda opcional de imagem e card de evento. `transparent` e "sem borda". */
export const BORDER_COLORS = [
  'transparent', '#DADCE0', '#5F6368', '#202124', '#1A73E8', '#D93025', '#188038', '#F9AB00',
];

/** Espessura usada quando a borda e ligada sem espessura definida. */
export const DEFAULT_BORDER_WIDTH = 2;

/** Cor do icone de pagina na barra lateral. E fixa: so pasta aceita cor propria. */
export const PAGE_COLOR = '#1A73E8';

/** Cor de pasta usada quando o usuario nao escolhe nenhuma. */
export const DEFAULT_FOLDER_COLOR = '#F29900';

/** Paleta oferecida no seletor de cor de pasta. */
export const FOLDER_COLORS = [
  { value: '#F29900', label: 'Laranja' },
  { value: '#1A73E8', label: 'Azul' },
  { value: '#188038', label: 'Verde' },
  { value: '#D93025', label: 'Vermelho' },
  { value: '#A142F4', label: 'Roxo' },
  { value: '#E52592', label: 'Rosa' },
  { value: '#12B5CB', label: 'Ciano' },
  { value: '#5F6368', label: 'Cinza' },
];

/** Geometria padrao dos elementos criados no canvas. */
export const DEFAULTS = {
  eventCardWidth: 320,
  stickySize: 180,
  shapeSize: { width: 200, height: 130 },
  textWidth: 240,
  pinRadius: 14,
  maxPreviewParams: 6,
};

/** Versao exibida no rodape. Acompanha o package.json. */
export const APP_VERSION = '3.0.0';

/** Autoria, no rodape de todas as telas. */
export const AUTHORSHIP = '© 2026 · Chico / Nikola Wissenklaus / Francisco Lucas';
