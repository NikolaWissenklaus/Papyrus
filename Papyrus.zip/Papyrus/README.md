# Papyrus `v3.0.0`

Ferramenta visual de **planejamento de mensuração e mapas de coleta** para o GA4 e para
outras ferramentas (Meta Ads, Google Ads, Criteo, RTB House…). Canvas infinito para desenhar a
arquitetura de dados de uma tela, com prints de referência, pins, conectores e cards de evento
que nascem de um **catálogo oficial de eventos e parâmetros**, e exportação disso como contrato
de coleta para o time de engenharia.

<img width="1024" height="559" alt="image" src="https://github.com/user-attachments/assets/b36510bd-326b-4f93-8413-f450dc301165" />

(Imagem gerada por I.A para representar o projeto)

---

## O que tem na 3.0

| Novidade | Em uma linha |
|---|---|
| **Login e senha** | Ninguém entra sem usuário. A sessão cai depois de 30 minutos sem atividade. O filtro de IP continua valendo, antes do login. |
| **Gerenciamento de usuários** | Adicionar, remover, redefinir senha e mudar perfil. Senha nunca é exibida. O usuário padrão não pode ser removido. |
| **Mapeamentos** | Depois do login, um hub com um card por mapeamento: o GA4 de sempre e quantos outros você criar (Meta Ads, Google Ads, Criteo, RTB House, outro GA4…), cada um com a mesma estrutura e tudo próprio. |
| **Catálogo** | A fonte oficial dos eventos e parâmetros. Criar evento escolhendo os parâmetros dele, criar parâmetro, ver quais eventos usam cada parâmetro, de-para, uso nos mapas. Substitui o antigo Dicionário Global, com tudo o que ele tinha. |
| **Cards a partir do catálogo** | No canvas, todo card novo nasce de um evento do catálogo: nome, tipo e parâmetros vêm prontos; o resto do card é preenchido à mão. Mudou o evento no catálogo, mudaram todos os cards dele. |
| **Storage de ida e volta** | Exportar o catálogo para o bucket e importar de volta, importar mapas do bucket (backup, contrato exportado ou página). |
| **Backup diário** | Com a integração configurada, todo dia às 00h o Papyrus grava `versions/AAAAMMDD.json` com todos os mapas no estado atual. |
| **Aparência do canvas** | Fundo cinza, branco, preto (ou qualquer cor) e grade de pontos, linhas ou nenhuma. No fundo escuro, texto e conector se adaptam sozinhos. |
| **PDF** | A foto do canvas também sai em PDF, com cabeçalho e tamanho de página ajustado ao conteúdo, A4 ou A3. |
| **Autoria no rodapé** | © 2026 · Chico / Nikola Wissenklaus / Francisco Lucas, em todas as telas. |

A documentação completa (instalação, uso passo a passo, arquitetura, API e decisões) está em
[`docs/papyrus-handbook.html`](docs/papyrus-handbook.html). Com o Papyrus no ar, ela abre pelo
menu **?** → *Abrir a documentação*, ou em `/docs/papyrus-handbook.html`. Os requisitos de
máquina estão em [`REQUISITOS.txt`](REQUISITOS.txt).

---

## 1. Como rodar

Pré-requisito: **Node.js 18 ou superior** (testado no Node 24; em servidor, prefira o 22 LTS).

```bash
npm install
npm start
```

Abra **http://localhost:4173** e entre com o usuário padrão:

| Usuário | Senha |
|---|---|
| `abacate` | `40028922` |

> A senha padrão está escrita aqui, no README. Troque no primeiro acesso: menu do usuário
> (canto superior direito) → **Trocar minha senha**. Enquanto ela não for trocada, o hub mostra
> um aviso.

Outros comandos:

| Comando | O que faz |
|---|---|
| `npm start` | Sobe o servidor |
| `npm run dev` | Sobe com auto-reload do back-end (`node --watch`). Cada reload encerra as sessões. |
| `npm run reset-password` | Volta o usuário padrão para a senha padrão (para quando ela se perdeu) |
| `npm run reset-password -- joao NovaSenha123` | Define a senha de outro usuário pelo terminal |

### Variáveis de ambiente

| Variável | Padrão | Para quê |
|---|---|---|
| `PORT` | `4173` | Porta do servidor |
| `PAPYRUS_DIR` | `./papyrus` | Pasta de trabalho (mapas, usuários, configuração) |
| `ALLOWED_IPS` | — | IPs liberados pelo filtro, separados por vírgula. Somam com a lista do `server/index.js` |
| `TRUST_PROXY` | — | Atrás de Nginx/Cloudflare: `loopback` (proxy na mesma máquina), um número de saltos ou `true` |
| `COOKIE_SECURE` | — | `1` força o cookie `Secure`. Sem ela, o cookie vira `Secure` sozinho quando a conexão é HTTPS |
| `SESSION_IDLE_MINUTES` | `30` | Minutos de inatividade até a sessão cair |
| `BACKUP_TZ` | `America/Sao_Paulo` | Fuso das 00h do backup diário |
| `GCS_BUCKET`, `GCS_PREFIX`, `GCS_KEYFILE`, `GCS_PROJECT_ID` | — | Configuração do Google Cloud Storage por ambiente (vence a da tela) |

No PowerShell, variáveis de ambiente vão assim: `$env:PORT=3000; npm start`.

### Hospedando em Linux (máquina ou VPS)

Os requisitos mínimos (CPU, RAM, disco, rede) estão em [`REQUISITOS.txt`](REQUISITOS.txt). Um
roteiro direto, em Ubuntu/Debian:

```bash
# 1. Node 22 LTS e o código
sudo apt install -y nodejs npm        # ou instale o Node 22 pelo NodeSource / nvm
sudo mkdir -p /opt/papyrus && sudo chown $USER /opt/papyrus
cp -r Papyrus/* /opt/papyrus && cd /opt/papyrus
npm install --omit=dev
```

```ini
# 2. /etc/systemd/system/papyrus.service
[Unit]
Description=Papyrus
After=network.target

[Service]
WorkingDirectory=/opt/papyrus
ExecStart=/usr/bin/node server/index.js
Environment=PORT=4173
Environment=TRUST_PROXY=loopback
Environment=ALLOWED_IPS=200.100.50.25,10.0.0.8
Environment=BACKUP_TZ=America/Sao_Paulo
Restart=always
User=papyrus

[Install]
WantedBy=multi-user.target
```

```bash
sudo useradd --system --home /opt/papyrus papyrus && sudo chown -R papyrus /opt/papyrus
sudo systemctl daemon-reload && sudo systemctl enable --now papyrus
journalctl -u papyrus -f              # logs, inclusive os do backup diário
```

Com um Nginx na frente (recomendado, para ter HTTPS):

```nginx
server {
  server_name papyrus.suaempresa.com;
  client_max_body_size 60m;            # prints grandes e importações
  location / {
    proxy_pass http://127.0.0.1:4173;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```

> **Atenção ao filtro de IP atrás de proxy.** Sem `TRUST_PROXY`, todo acesso parece vir do
> próprio Nginx (`127.0.0.1`), que está liberado, e o filtro deixa de filtrar. Com
> `TRUST_PROXY=loopback`, o Papyrus lê o IP real do `X-Forwarded-For`.

Faça backup da pasta `papyrus` da máquina (ou da `PAPYRUS_DIR`): o backup diário no bucket cobre
os mapas, mas não as imagens coladas (`_assets`) nem os usuários.

### Por que Express e não Electron

A ferramenta precisa de acesso real ao sistema de arquivos (criar pastas, ler e gravar JSON),
algo impossível num front-end puro no navegador. Entre Electron e um servidor Node, o servidor
venceu por três motivos: sobe em ~1s sem build step, roda em qualquer máquina que tenha Node, e
permite abrir o mapa em várias abas ou compartilhar com o time inteiro, que é o caso agora, com
login e hospedagem em VPS.

---

## 2. Acesso e segurança

### Login e sessão

Toda a ferramenta fica atrás do login: telas, API, imagens e documentação. Sem sessão, a página
manda para `/login`; a API responde `401`.

- A sessão é um cookie `HttpOnly` com um token aleatório de 32 bytes, guardado só na memória do
  servidor.
- **30 minutos sem atividade derrubam a sessão.** Atividade é qualquer coisa: editar, rolar,
  ler o catálogo. A interface avisa o servidor no máximo uma vez por minuto enquanto alguém mexe
  na tela, e com várias abas abertas a sessão só cai quando todas ficaram paradas. Ao cair, a
  pessoa volta para o login com o aviso do motivo.
- Oito senhas erradas em dez minutos, do mesmo IP, bloqueiam o login desse IP por dez minutos.
- Reiniciar o servidor encerra todas as sessões.

### O filtro de IP continua

Ele roda **antes** do login: quem não está na lista nem vê a tela de entrada. A lista está em
`server/index.js`, como antes, e agora também pode ser completada por `ALLOWED_IPS`.

### Usuários e perfis

Menu do usuário → **Gerenciar usuários** (só administradores):

| Ação | Como funciona |
|---|---|
| Adicionar | Usuário, senha (duas vezes, mascarada) e se é administrador |
| Redefinir senha | O administrador define a nova senha; quem estava logado com a antiga sai na hora |
| Mudar perfil | Administrador ↔ Editor |
| Remover | A pessoa perde o acesso na hora, inclusive a sessão aberta. Os mapas dela continuam |

| Perfil | Pode |
|---|---|
| **Administrador** | Tudo, mais gerenciar usuários, configurar o Google Cloud Storage e rodar o backup manual |
| **Editor** | Usar a ferramenta inteira: mapas, catálogo, importar, exportar |

O usuário padrão (`abacate`) é sempre administrador e **não pode ser removido**. Ninguém remove
o próprio usuário. As senhas viram hash `scrypt` com sal por usuário e nunca são exibidas,
gravadas em texto ou devolvidas pela API. Qualquer pessoa troca a própria senha em **Trocar
minha senha**.

Perdeu a senha do administrador? No terminal do servidor: `npm run reset-password`.

### O que mudou por baixo, por segurança

Antes, `/papyrus/*` servia a pasta de trabalho inteira, inclusive `_system/` com a chave da
service account. Agora só `/papyrus/_assets/*` (as imagens) é servido, e só com sessão. Os
arquivos de usuários e credenciais não têm rota nenhuma.

---

## 3. Mapeamentos

Depois do login aparece o hub: um card por mapeamento, com páginas, cards e eventos no catálogo.

- **GA4** é o mapeamento padrão e é o mesmo workspace de antes: tudo o que já existia continua
  exatamente onde estava, sem migração.
- **Criar mapeamento** abre outro projeto com a mesma estrutura (pastas, páginas, catálogo,
  grupos de parâmetros), escolhendo a ferramenta: Google Analytics 4, Google Ads, Meta Ads,
  Criteo, RTB House, TikTok Ads, LinkedIn Ads, Pinterest Ads ou outra. Serve também para
  separar outra propriedade do GA4 ("GA4 · App").
- Cada mapeamento é independente: tem o próprio catálogo, os próprios nomes (a página "Home" pode
  existir no GA4 e no Meta Ads) e exporta o próprio contrato.
- Renomear e excluir ficam no `⋯` do card (administradores). Excluir pede o nome digitado e
  apaga tudo do mapeamento; o GA4 não pode ser excluído.
- Dentro do mapeamento, o chip ao lado do logo troca de mapeamento. O endereço guarda o
  mapeamento aberto (`/#/meta-ads`), então recarregar volta para ele e o *voltar* do navegador
  leva ao hub.

**O que a ferramenta muda.** As regras de nome do GA4 (snake_case, nomes e prefixos reservados,
40 caracteres, 25 parâmetros) só valem nos mapeamentos de GA4. Meta Ads tem eventos padrão em
PascalCase (`AddToCart`), e cobrar snake_case ali travaria a exportação por um erro que não
existe. O gerador `gtag()` aparece só para GA4 e Google Ads; `dataLayer.push` e JSON Schema
valem para todas.

---

## 4. Catálogo

A aba **Catálogo** é a fonte oficial dos eventos e parâmetros do mapeamento, e também o retrato
do que está nos mapas.

### Eventos e parâmetros

- **+ Novo parâmetro**: nome, escopo (evento, usuário ou `items[]`), tipo, se é obrigatório por
  padrão, descrição e valor de exemplo. O parâmetro fica no catálogo, solto.
- **+ Novo evento**: nome, tipo (View, Interaction, Ecommerce, Automatic), descrição e **os
  parâmetros que ele carrega**, escolhidos da lista do catálogo. Parâmetro só entra em evento
  assim, na criação (ou edição) do evento. Cada parâmetro escolhido pode ser obrigatório em um
  evento e opcional em outro.
- No editor de evento dá para criar um parâmetro na hora (**+ Criar parâmetro**), usar um
  **Grupo de Parâmetros** inteiro e, no GA4, trazer o **Padrão GA4 de ecommerce** (`currency`,
  `value` e os 18 parâmetros de `items[]`), criando no catálogo o que faltar.
- O `event_id` não aparece no catálogo porque é automático: todo card nasce com o seu, único.

### As visões

| Aba | Mostra |
|---|---|
| **Eventos** | Cada evento com tipo, parâmetros (`*` = obrigatório), em quantos cards e páginas está e quando mudou. Clique no nome para a ficha completa. |
| **Parâmetros** | Cada parâmetro com escopo, tipo, padrão, exemplo e **os eventos associados**. |
| **De-para** | Matriz parâmetro × evento: ● obrigatório, ○ opcional. |
| **Uso nos mapas** | Todo card de todas as páginas, com o estado no catálogo e um **Abrir** que leva direto ao card no canvas (o antigo Dicionário Global). |

No topo ficam os números e os alertas: `event_id` repetido entre cards, o mesmo parâmetro com
tipos diferentes nos mapas e cards fora do catálogo.

### Editar e excluir

- **Editar um evento atualiza todos os cards dele**, em todas as páginas: nome, tipo e
  parâmetros. O que é do card (valores de exemplo, gatilho, plataforma, governança, ticket,
  `event_id`) não muda. Renomear um parâmetro também chega a todos os cards.
- **Excluir um evento** não apaga card nenhum: os cards ficam com o conteúdo de antes, só que
  fora do catálogo.
- **Parâmetro em uso não pode ser excluído**: tire-o dos eventos primeiro. Mudar o contrato de
  coleta precisa ser uma decisão explícita.

### Trazer os eventos que já estão nos mapas

Mapas criados antes do catálogo têm cards livres. O banner **Revisar e trazer para o catálogo**
mostra o plano (eventos novos, parâmetros novos, conflitos de tipo, cards que serão vinculados) e,
confirmado, cria tudo e vincula os cards, juntando os parâmetros de todos os cards do mesmo
evento. Nenhum valor de exemplo se perde. Card avulso também pode ser vinculado pelo inspetor.

### Exportar e importar

- **Exportar → Para o Google Cloud Storage**: grava `<prefixo>catalog/<nome>.json` com cada
  evento e os parâmetros dele por extenso (legível pelo time de engenharia) e a lista completa de
  parâmetros com os eventos de cada um.
- **Exportar → CSV**: do catálogo (evento × parâmetro) ou dos mapas (página × evento × parâmetro),
  com BOM para o Excel.
- **Importar** (do Storage ou do computador) aceita o catálogo exportado, um backup diário (usa o
  catálogo de um dos mapeamentos dele) ou um contrato exportado (monta o catálogo a partir dos
  eventos). Dois modos:
  - **Mesclar**: acrescenta o que falta e atualiza o que já existe, casando pelo nome.
  - **Substituir**: o catálogo fica igual ao arquivo; evento que sai deixa os cards dele fora do
    catálogo.

---

## 5. Canvas

### Fluxo recomendado

1. **Cadastre** os eventos e parâmetros no **Catálogo**.
2. **Crie uma página** (`+ Página` na barra lateral), uma por tela/jornada.
3. **Cole o print** da tela com `Ctrl + V`.
4. **Marque os pontos de interação** com pins (`P`).
5. **Crie os cards** (`E` e clique no canvas): o seletor abre com os eventos do catálogo; busque,
   escolha com `Enter` ou clique. O card já vem com nome, tipo e parâmetros.
6. **Preencha no inspetor** o que é do card: valores de exemplo, plataforma, gatilho,
   governança e ticket.
7. **Ligue pin ↔ card** com o conector magnético (`C`).
8. **Confira a validação** no rodapé; clique num problema para o canvas voar até o card.
9. **Exporte** o JSON para o bucket.

### O Card de Evento

| Bloco | Campos |
|---|---|
| Evento do catálogo | O evento vinculado, com descrição e **Trocar evento**, **Ver no catálogo** e **Desvincular** |
| Contexto técnico | Plataforma (Web/App/Server, múltipla), Gatilho |
| Governança | Squad, Pessoa responsável, Observações |
| Integração ágil | Nome do card, ID, URL clicável |
| Parâmetros | Nome, tipo e obrigatoriedade vêm do catálogo (só leitura); o **valor de exemplo** é do card |
| Módulo Ecommerce | `items[]`, quando o evento é do tipo Ecommerce |

A cor da tarja codifica o tipo: View azul, Interaction verde, Ecommerce amarelo, Automatic lilás.

**Card fora do catálogo** (criado antes dele, ou desvinculado) continua editável como sempre e
mostra o selo **FORA DO CATÁLOGO** no canvas. No inspetor aparecem **Vincular a "evento"**
(quando já existe um com o mesmo nome), **Adicionar ao catálogo** (cria o evento a partir do card)
e **Escolher evento do catálogo**. O validador acusa como aviso, não como erro: o card exporta
normalmente.

### O `event_id`

Todo card nasce com um parâmetro `event_id` obrigatório e já preenchido. É a chave que amarra o
planejamento ao dado coletado. O valor tem três partes separadas por hífen:

| Parte | Formato | Exemplo |
|---|---|---|
| Pasta | `d` + código ASCII de cada letra do nome da pasta onde a página está | `d099111114` (pasta `cor`) |
| Momento | `p` + timestamp da criação, em segundos | `p1757203200` |
| Sorteio | `6` + 6 caracteres aleatórios | `6k3f9zq` |

Os códigos ASCII vão com zero à esquerda (3 dígitos). Página na raiz do mapeamento usa `papyrus`.
O valor é editável, mas **não pode repetir**: o validador do rodapé acusa repetição na página, o
Catálogo mostra repetição entre páginas, e o servidor recusa exportar com `409`. Colar, duplicar e
duplicar a página geram um `event_id` novo para cada cópia; a importação preserva os ids.

### Aparência do canvas

O botão de paleta ao lado do zoom (e o inspetor, com nada selecionado) muda a aparência da
página:

- **Fundo**: Padrão (cinza claro), Branco, Cinza, Preto ou qualquer outra cor.
- **Grade**: pontos, linhas ou sem grade.
- **Aplicar em todas as páginas** do mapeamento, de uma vez.

Fica salvo na página e sai igual na foto e no PDF. No fundo escuro, texto, traço de forma e
conector que estão na cor padrão passam a ser desenhados claros; cor escolhida à mão é respeitada.

### Foto e PDF

**Foto / PDF**, na barra superior, recorta o canvas no conteúdo:

| Formato | Para |
|---|---|
| PNG | Sem perdas, com fundo transparente opcional |
| JPG | Arquivo menor |
| **PDF** | Documento: página ajustada ao conteúdo, A4 paisagem, A4 retrato ou A3 paisagem, com cabeçalho opcional (nome da página, mapeamento e data) |

Resolução de 2× a 4×, margem e apenas a seleção atual. O PDF é gerado no próprio navegador, sem
dependência.

### Outros recursos do canvas

- **Validador de governança contínuo** no rodapé: snake_case (GA4), nomes e prefixos reservados,
  limites do GA4, parâmetro duplicado, obrigatório sem exemplo, Ecommerce sem `currency`/`value`/
  `items[]`, governança vazia, conector órfão, card fora do catálogo.
- **Geradores de código** no card: `dataLayer.push` (com o `push({ ecommerce: null })`), `gtag()`
  e JSON Schema.
- **Histórico e auto-save**: grava 700ms depois da última alteração; digitar um nome inteiro é um
  passo de undo só (limite de 80).
- **Vários elementos**: alinhar, distribuir, copiar e colar entre páginas, abas e até entre
  mapeamentos (o card é religado pelo nome no catálogo de destino).
- **Grupos de Parâmetros**: conjuntos nomeados de parâmetros recorrentes, usados no editor de
  evento do catálogo e, nos cards fora do catálogo, pelo inspetor.

### Nomes únicos

Dentro de um mapeamento não existem dois nomes iguais: nem duas páginas, nem duas pastas, nem uma
pasta e uma página. A comparação ignora a caixa. O motivo é o exportador: o JSON usa o nome da
página como chave raiz, e chave de objeto não se repete. Nada é renomeado em silêncio: a
tentativa é recusada com o nome e o lugar do que já existe. Vale para criar, renomear, mover e
importar. Os nomes `_assets`, `_system` e `_workspaces` são reservados.

---

## 6. Google Cloud Storage e backup

Aba **Configurações → Google Cloud Storage** (administradores): bucket, prefixo, project id e o
JSON da service account, colado num campo mascarado. A chave é validada, gravada no servidor e
nunca volta para o navegador. **Testar conexão** confere biblioteca, credencial e acesso usando
os valores da tela, antes de salvar.

A service account precisa do papel **Storage Object User** (`roles/storage.objectUser`) no bucket:
ele lista, lê, grava e **substitui** arquivos, e o export com nome fixo, o backup do dia e a
importação precisam disso (o antigo "Storage Object Creator" não sobrescreve arquivo).

Tudo fica abaixo do prefixo:

```
gs://<bucket>/<prefixo>/
├── papyrus.json              ← Exportar do GA4 (outros mapeamentos: papyrus-<id>.json)
├── catalog/
│   └── catalogo-ga4.json     ← Exportar do Catálogo
└── versions/
    ├── 20261029.json         ← backup diário
    └── 20261030.json
```

### Exportar (contrato de coleta)

JSON só com regra de negócio, **no mesmo formato de sempre** (o time de engenharia não precisa
mudar nada): a chave raiz é o nome da página e o valor é o array de eventos. Os cards saem com a
definição atual do catálogo.

```json
{
  "Checkout": [
    {
      "event_name": "begin_checkout",
      "event_type": "ecommerce",
      "platform": ["web", "app"],
      "trigger": "Clique em 'Finalizar compra' no carrinho",
      "governance": { "squad": "Checkout", "owner": "…", "notes": "…" },
      "tracker": { "card_name": "…", "card_id": "ANA-1234", "url": "…" },
      "parameters": {
        "event": [{ "name": "event_id", "type": "string", "required": true, "example": "d067…" }],
        "user":  [{ "name": "user_id",  "type": "string", "required": false }],
        "items": [{ "name": "item_id",  "type": "string", "required": true }]
      }
    }
  ]
}
```

O escopo é sempre o mapeamento inteiro, e a exportação só acontece sem erros de validação (avisos
não bloqueiam). O servidor repete a checagem de `event_id` e recusa com `409` se algum faltar ou
repetir.

### Backup diário (`versions/`)

Com bucket e service account configurados, **todo dia às 00h** (fuso `BACKUP_TZ`, padrão
`America/Sao_Paulo`) o Papyrus grava `versions/AAAAMMDD.json` com o estado atual de **todos os
mapeamentos**: páginas completas (com o desenho do canvas), pastas, cores, catálogo e grupos.

- O nome é a data em que o backup rodou: o das 00h de 30/10 é `20261030.json`, com o estado do
  fim do dia 29.
- Se o servidor estava desligado à meia-noite (ou o GCS foi configurado no meio do dia), o backup
  do dia roda assim que possível. Falhou? Nova tentativa em 30 minutos.
- **Fazer backup agora**, na aba Configurações, roda na hora e substitui o arquivo do dia.
- Ficam de fora usuários, senhas e a credencial. As imagens também não vão no JSON (a página
  guarda só o endereço delas): faça backup da pasta `papyrus/_assets` da máquina.

### Importar do Storage

Barra lateral → **Importar ▾ → Do Google Cloud Storage**: a lista mostra os `.json` do bucket
(backups, catálogos e mapas exportados), do mais recente para o mais antigo. O Papyrus lê o
arquivo e oferece as opções certas:

| Arquivo | O que acontece |
|---|---|
| **Backup** (`versions/`) | Escolha qual mapeamento do backup restaurar. Voltam páginas completas, pastas e cores; o catálogo do backup completa o atual (entra o que falta). |
| **Contrato exportado** | Cada página é remontada com os cards em colunas, já ligados ao catálogo quando o evento existe nele. Página existente é sempre mantida. |
| **Página do Papyrus** | Entra na pasta escolhida. |
| **Catálogo** | Vai para a importação da aba Catálogo. |

Página com o mesmo nome: **manter a atual** (o arquivo aparece no relatório) ou **substituir
pelo arquivo**, no lugar onde a página está. **Importar → Arquivos do computador** aceita os
mesmos formatos.

---

## 7. Estrutura do projeto

```
Papyrus/
├── REQUISITOS.txt              # Requisitos mínimos para rodar em Linux
├── server/                     # Back-end Express
│   ├── index.js                # Filtro de IP, login, barreira de sessão, rotas
│   ├── scripts/
│   │   └── reset-password.js   # npm run reset-password
│   ├── lib/
│   │   ├── auth.js             # Usuários, senhas (scrypt), sessões, perfis
│   │   ├── workspaces.js       # Mapeamentos: registro e contexto de cada um
│   │   ├── catalog.js          # Catálogo: CRUD, propagação, adoção, import/export
│   │   ├── importer.js         # Importação de página, backup e contrato
│   │   ├── backup.js           # Backup diário em versions/ e o agendador
│   │   ├── gcs.js              # Adapter do Google Cloud Storage
│   │   ├── json-store.js       # Gravação atômica e trava por arquivo
│   │   ├── paths.js            # Resolução segura de caminhos (anti path-traversal)
│   │   ├── papyrus.js          # Formato do arquivo, varredura da árvore
│   │   ├── names.js            # Nome único no mapeamento
│   │   ├── templates.js        # Grupos de parâmetros
│   │   └── folder-colors.js    # Cor de cada pasta
│   └── routes/
│       ├── auth.js             # Login, sessão, usuários
│       ├── workspaces.js       # Mapeamentos
│       ├── tree.js             # Pastas, páginas, aparência em lote
│       ├── catalog.js          # Catálogo
│       ├── system.js           # Grupos, consolidação, exportar, importar
│       ├── integrations.js     # GCS e backup
│       └── assets.js           # Upload de imagens
│
├── shared/                     # Regras que servidor e navegador aplicam igual
│   ├── rules.js                # Nomes reservados, limites, snake_case
│   ├── tools.js                # Ferramentas dos mapeamentos
│   └── catalog-sync.js         # Vínculo card ↔ catálogo, event_id
│
├── public/                     # Front-end (ES modules, sem build step)
│   ├── index.html · login.html
│   ├── css/                    # tokens · app · forms · screens · login
│   └── js/
│       ├── main.js · login.js · session.js · store.js · api.js
│       ├── models.js · constants.js · util.js · pdf.js
│       ├── canvas/             # stage · nodes · geometry · clipboard
│       ├── panels/             # hub · users · catalog · catalog-forms · storage ·
│       │                       # appearance · sidebar · inspector · templates ·
│       │                       # exporters · settings
│       ├── quality/            # validation · snippet
│       └── ui/                 # modal · toast
│
├── docs/papyrus-handbook.html  # Documentação completa
└── papyrus/                    # Criada na primeira execução: seus dados
```

---

## 8. A pasta `papyrus`

Tudo o que você cria vive em `papyrus/`, em JSON legível por humanos. Pastas e páginas na
interface são pastas e arquivos de verdade no disco.

```
papyrus/
├── _assets/                    # imagens coladas, de todos os mapeamentos
├── _system/                    # configuração global e os arquivos internos do GA4
│   ├── users.json              # usuários (hash scrypt, nunca senha)
│   ├── workspaces.json         # registro dos mapeamentos
│   ├── gcs.json                # bucket e prefixo
│   ├── gcs-service-account.json
│   ├── backup-state.json       # último backup
│   ├── catalog.json            # catálogo do GA4
│   ├── parameter-groups.json   # grupos do GA4
│   └── folder-colors.json      # cores de pasta do GA4
├── _workspaces/
│   └── meta-ads/               # cada mapeamento criado depois
│       ├── _system/            # catalog.json, parameter-groups.json, folder-colors.json
│       └── Checkout/…          # pastas e páginas dele
└── Checkout/                   # pastas e páginas do GA4, onde sempre estiveram
    └── carrinho.json
```

Um arquivo só é renderizado se a **raiz do JSON** contiver `"json-type": "papyrus"`. Arquivos
sem essa chave aparecem esmaecidos na barra lateral, marcados como `ignorado`, e não abrem.

O card vinculado guarda o `catalogEventId` e uma cópia do que o catálogo define (cada parâmetro
com o seu `catalogParamId`), e por isso a página continua autossuficiente: o exportador, os
geradores de código e o backup leem o card sem consultar o catálogo.

```json
{
  "id": "evt_x1y2", "type": "event", "x": 620, "y": 300, "width": 320,
  "data": {
    "catalogEventId": "cev_8k2h1a",
    "name": "view_item", "eventType": "ecommerce",
    "platform": ["web", "app"], "trigger": "Carregamento da PDP",
    "squad": "Growth", "owner": "ana@empresa",
    "eventParams": [
      { "id": "p1", "name": "event_id", "type": "string", "required": true, "example": "d080068080-p1757203200-6k3f9zq" },
      { "id": "p2", "catalogParamId": "cpa_3m9x0q", "name": "currency", "type": "string", "required": true, "example": "BRL" }
    ],
    "userParams": [], "itemParams": []
  }
}
```

Adicione `papyrus/_system/users.json` e `papyrus/_system/gcs-service-account.json` ao
`.gitignore` se a pasta for versionada (o `.gitignore` do projeto já faz isso).

---

## 9. Atalhos de teclado

| Ação | Atalho |
|---|---|
| Selecionar / Navegar | `V` / `H` ou `Espaço` |
| Card de evento (abre o seletor do catálogo) | `E` |
| Nota adesiva / Texto | `N` / `T` |
| Retângulo / Círculo | `R` / `O` |
| Pin / Conector | `P` / `C` |
| Colar print ou elementos | `Ctrl + V` |
| Copiar seleção | `Ctrl + C` |
| Duplicar | `Ctrl + D` |
| Desfazer / Refazer | `Ctrl + Z` / `Ctrl + Shift + Z` |
| Selecionar tudo | `Ctrl + A` |
| Salvar agora | `Ctrl + S` |
| Excluir seleção | `Delete` |
| Mover 1px / 10px | Setas / `Shift` + Setas |
| Zoom | `Ctrl + Scroll` |
| Zoom 100% / Enquadrar | `Ctrl + 0` / `Shift + 1` |
| Barra lateral / Inspetor | `[` / `]` |
| Ajuda | `?` |

---

## 10. API do back-end

Tudo sob `/api`, tudo JSON, tudo com sessão (menos entrar e sair). As rotas de conteúdo são de
um mapeamento: `/api/w/<id>/…`.

| Método | Rota | Função |
|---|---|---|
| `POST` | `/api/auth/login` · `/api/auth/logout` | Entrar (cookie de sessão) e sair |
| `GET` | `/api/auth/me` | Quem está logado e o prazo de inatividade |
| `POST` | `/api/auth/touch` · `/api/auth/password` | Manter a sessão viva · trocar a própria senha |
| `GET`/`POST` | `/api/users` | Listar · criar usuário (admin) |
| `PUT` | `/api/users/:usuario/password` | Redefinir senha (admin) |
| `PATCH`/`DELETE` | `/api/users/:usuario` | Mudar perfil · remover (admin) |
| `GET`/`POST` | `/api/workspaces` | Mapeamentos com números · criar |
| `PATCH`/`DELETE` | `/api/workspaces/:id` | Renomear · excluir (admin) |
| `GET` | `/api/w/:id/tree` | Árvore do mapeamento |
| `POST` | `/api/w/:id/folders` · `/pages` | Criar pasta · página |
| `GET`/`PUT` | `/api/w/:id/page` | Ler (já sincronizada com o catálogo) · gravar página |
| `POST` | `/api/w/:id/pages/appearance` | Aparência em todas as páginas |
| `PATCH`/`DELETE` | `/api/w/:id/entry` | Renomear · excluir |
| `POST` | `/api/w/:id/entry/move` | Mover |
| `GET` | `/api/w/:id/catalog` | Catálogo |
| `POST`/`PUT`/`DELETE` | `/api/w/:id/catalog/events[/:eid]` | Eventos (editar propaga para os cards) |
| `POST` | `/api/w/:id/catalog/events/from-definition` | Evento a partir de um card |
| `POST`/`PUT`/`DELETE` | `/api/w/:id/catalog/params[/:pid]` | Parâmetros |
| `GET`/`POST` | `/api/w/:id/catalog/adopt` | Plano · aplicar "trazer eventos dos mapas" |
| `POST` | `/api/w/:id/catalog/export` · `/catalog/import` | Catálogo para o bucket · importar |
| `GET` | `/api/w/:id/dictionary` | Consolidação dos mapas (uso, conflitos, `event_id`) |
| `GET`/`PUT` | `/api/w/:id/templates` | Grupos de parâmetros |
| `POST` | `/api/w/:id/export/events` | Contrato para o bucket |
| `POST` | `/api/w/:id/import` · `/import/inspect` | Importar (computador ou bucket) · ler arquivo do bucket |
| `POST` | `/api/assets` | Upload de imagem |
| `GET` | `/api/gcs/status` · `/api/gcs/objects` | Diagnóstico · arquivos do bucket |
| `GET`/`PUT` | `/api/settings/gcs` | Configuração do GCS (gravar: admin) |
| `POST` | `/api/settings/gcs/test` | Testar conexão (admin) |
| `GET` | `/api/backup/status` | Estado do backup diário |
| `POST` | `/api/backup/run` | Backup agora (admin) |

Erros: `400` dado inválido · `401` sem sessão · `403` IP bloqueado ou falta de perfil · `404` não
encontrado · `409` nome já existe, parâmetro em uso, `event_id` ausente/repetido no export · `413`
arquivo grande demais · `422` arquivo fora do formato · `429` tentativas de login demais · `501`
pacote do GCS ausente.

---

## 11. Notas de implementação

**Sem dependência nova.** Login com `crypto.scrypt` do Node, cookie sem `cookie-parser`, PDF
gerado à mão (um JPEG embutido num PDF 1.4 válido), agendador com `setInterval`. As dependências
continuam `express`, `konva` e `@google-cloud/storage`.

**Código compartilhado.** `shared/` é importado pelo Node e pelo navegador (servido em
`/shared`). As regras de nome e a sincronização card ↔ catálogo existem uma vez só; duas cópias
divergiriam na primeira mudança.

**Sincronização com o catálogo em três lugares.** Editar o catálogo propaga para as páginas no
disco, dentro da trava de cada página. Ler uma página devolve os cards já sincronizados (cobre a
página que alguém salvou por cima de uma propagação). E a exportação sincroniza na hora. O disco
converge, e nenhum consumidor vê o catálogo de ontem.

**Gravação atômica e trava por arquivo.** Usuários, catálogo, registro de mapeamentos e páginas
são gravados em arquivo temporário e trocados com `rename`; ler-alterar-gravar no mesmo arquivo é
enfileirado. Uma queda de energia não deixa `users.json` pela metade.

**Backup sem timer de meia-noite.** Um tick por minuto confere se o dia de hoje (no fuso
configurado) já tem backup. Resolve horário de verão, servidor desligado à meia-noite e
integração configurada no meio do dia.

**Renderização do canvas.** Render incremental com diff por fingerprint (que agora inclui a tinta
do fundo e o vínculo do card com o catálogo); conectores sempre recalculados; nada é reconstruído
durante um arrasto; `pixelRatio` limitado a 2; validação com debounce de 250ms.

**Conectores magnéticos, edição no inspetor, undo por snapshot e modo offline** seguem como
antes: `from`/`to` guardam só `{ id, anchor }`; o card é editado no painel porque são ~20 campos;
histórico de 80 snapshots; o Konva sai do `node_modules` e a única dependência externa do
navegador é o Google Fonts.

---

<img width="1901" height="942" alt="image" src="https://github.com/user-attachments/assets/0110f0cf-acde-4f89-bfde-efb4113aec6d" />

---

© 2026 · Chico / Nikola Wissenklaus / Francisco Lucas · Licença MIT
