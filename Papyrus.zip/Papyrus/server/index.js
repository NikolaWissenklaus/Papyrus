/*
 * Servidor Express do Papyrus.
 *
 * Express em vez de Electron por tres motivos. Nao tem build step, sobe em
 * cerca de um segundo e roda em qualquer maquina com Node. Da acesso de
 * verdade ao file system, que a pasta `papyrus` exige e um front-end puro no
 * navegador nao teria. E deixa a ferramenta aberta em varias abas ou monitores
 * e, se for o caso, exposta na rede interna do time, o que com Electron daria
 * bem mais trabalho.
 *
 * Ordem das barreiras, de fora para dentro:
 *
 *   1. filtro de IP       quem nao esta na lista nem chega ao login
 *   2. login              /login, /api/auth/login e os arquivos da tela de login
 *   3. sessao             todo o resto: app, API, imagens, documentacao
 */

import express from 'express';
import path from 'node:path';

import { PAPYRUS_ROOT, PROJECT_ROOT, ASSETS_DIR, ensureBaseStructure } from './lib/paths.js';
import { ensureDefaultUser, requireSession, resolveSession, DEFAULT_USERNAME } from './lib/auth.js';
import { ensureWorkspaces, resolveWorkspace } from './lib/workspaces.js';
import { startBackupScheduler, BACKUP_TIMEZONE } from './lib/backup.js';
import { publicAuthRoutes, sessionRoutes, userRoutes } from './routes/auth.js';
import workspaceRoutes from './routes/workspaces.js';
import treeRoutes from './routes/tree.js';
import assetRoutes from './routes/assets.js';
import systemRoutes from './routes/system.js';
import catalogRoutes from './routes/catalog.js';
import integrationRoutes from './routes/integrations.js';

const PORT = Number(process.env.PORT) || 4173;
const PUBLIC_DIR = path.join(PROJECT_ROOT, 'public');

const app = express();
app.disable('x-powered-by');

// Atras de um proxy reverso (Nginx, Cloudflare, Docker...), o IP real do
// cliente vem no X-Forwarded-For. Defina TRUST_PROXY (ex.: "loopback" para um
// Nginx na mesma maquina) para o filtro de IP e o cookie Secure enxergarem a
// conexao de verdade. Sem isso, todo acesso parece vir do proprio proxy.
if (process.env.TRUST_PROXY) {
  const value = process.env.TRUST_PROXY;
  app.set('trust proxy', value === 'true' ? true : /^\d+$/.test(value) ? Number(value) : value);
}

// Cabecalhos basicos: sem sniff de tipo, sem abrir dentro de iframe de outro
// site (clickjacking na tela de login) e sem vazar URL interna no Referer.
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'same-origin');
  next();
});

// --- Restrição de IP --------------------------------------------------------
// Adicione os IPs permitidos (inclua localhost para testes locais)
const ALLOWED_IPS = [
  '127.0.0.1',       // Localhost IPv4
  '::1',             // Localhost IPv6
  '',                // Substitua pelo IP externo ou IP da rede interna desejado
  // Na VPS, da para completar a lista sem editar o codigo:
  // ALLOWED_IPS="200.100.50.25,10.0.0.8" npm start
  ...String(process.env.ALLOWED_IPS || '').split(',').map((ip) => ip.trim()).filter(Boolean),
];

// Se o servidor rodar atrás de um proxy reverso (Nginx, Cloudflare, Docker, etc.),
// defina TRUST_PROXY (veja acima) para ler o IP real do cabeçalho X-Forwarded-For.

app.use((req, res, next) => {
  // Normaliza o IP (o Node/Express costuma retornar ::ffff:192.168.x.x para IPv4)
  const rawIp = req.ip || req.socket.remoteAddress || '';
  const clientIp = rawIp.replace(/^.*:/, '');

  const isAllowed = ALLOWED_IPS.some((allowed) => {
    return clientIp === allowed || rawIp === allowed;
  });

  if (!isAllowed) {
    console.warn(`[segurança] Bloqueado acesso não autorizado do IP: ${rawIp}`);
    return res.status(403).json({ error: 'Acesso não autorizado para este endereço IP.' });
  }

  next();
});

// Canvas com muita imagem ou muito parametro passa fácil do default de 100kb.
app.use(express.json({ limit: '60mb' }));

// --- Login (sem sessao) -----------------------------------------------------
app.use('/api/auth', publicAuthRoutes);

app.get(['/login', '/login.html'], async (req, res, next) => {
  try {
    // Quem ja tem sessao valida vai direto para o hub.
    if (await resolveSession(req)) return res.redirect(302, '/');
    res.sendFile(path.join(PUBLIC_DIR, 'login.html'));
  } catch (err) {
    next(err);
  }
});

// So o que a tela de login precisa sai sem sessao. O resto do front-end fica
// atras da barreira, junto com os dados.
const LOGIN_ASSETS = {
  '/css/tokens.css': 'css/tokens.css',
  '/css/login.css': 'css/login.css',
  '/js/login.js': 'js/login.js',
};
app.get(Object.keys(LOGIN_ASSETS), (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, LOGIN_ASSETS[req.path]));
});

// --- Daqui para baixo, so com sessao -----------------------------------------
app.use(requireSession);

// Front-end estatico
app.use(express.static(PUBLIC_DIR));

// Regras compartilhadas entre servidor e navegador (catalogo, nomenclatura).
app.use('/shared', express.static(path.join(PROJECT_ROOT, 'shared')));

// Documentacao (handbook), aberta pelo menu de ajuda.
app.use('/docs', express.static(path.join(PROJECT_ROOT, 'docs')));

// Konva sai do node_modules, entao a ferramenta funciona offline.
app.get('/vendor/konva.min.js', (_req, res) => {
  res.type('application/javascript');
  res.sendFile(path.join(PROJECT_ROOT, 'node_modules', 'konva', 'konva.min.js'));
});

// Imagens coladas no canvas. So _assets: servir a pasta papyrus inteira
// exporia _system (usuarios, configuracao e a chave da service account).
app.use('/papyrus/_assets', express.static(ASSETS_DIR, { fallthrough: false, dotfiles: 'deny' }));

// API global
app.use('/api', sessionRoutes);
app.use('/api', userRoutes);
app.use('/api', workspaceRoutes);
app.use('/api', assetRoutes);
app.use('/api', integrationRoutes);

// API de cada mapeamento
app.use('/api/w/:workspace', resolveWorkspace, treeRoutes, systemRoutes, catalogRoutes);

app.use('/api', (_req, res) => res.status(404).json({ error: 'Rota não encontrada.' }));

// Tratamento de erros
app.use((err, _req, res, _next) => {
  const status = err.status || err.statusCode || 500;
  if (status >= 500) console.error('[papyrus]', err.message);
  res.status(status).json({ error: err.message || 'Erro interno.' });
});

await ensureBaseStructure();
const { created: createdDefaultUser } = await ensureDefaultUser();
await ensureWorkspaces();
startBackupScheduler();

const server = app.listen(PORT, () => {
  console.log('');
  console.log('  ██  PAPYRUS  |  mapa de coletas');
  console.log('  ─────────────────────────────────────────────');
  console.log(`  App .......... http://localhost:${PORT}`);
  console.log(`  Papyrus ...... ${PAPYRUS_ROOT}`);
  console.log(`  Backup ....... 00h (${BACKUP_TIMEZONE}), quando o GCS estiver configurado`);
  if (createdDefaultUser) {
    console.log(`  Login ........ usuário padrão "${DEFAULT_USERNAME}" criado (troque a senha no primeiro acesso)`);
  }
  console.log('  ─────────────────────────────────────────────');
  console.log('');
});

// Sem este handler, porta ocupada derruba o processo com um stack trace do Node
// que nao ajuda em nada. Quase sempre e o proprio Papyrus, ja rodando em outra
// janela do terminal.
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error('');
    console.error(`  A porta ${PORT} ja esta em uso.`);
    console.error('');
    console.error('  Provavelmente o Papyrus ja esta rodando. Tente abrir');
    console.error(`  http://localhost:${PORT} antes de subir outra instancia.`);
    console.error('');
    console.error('  Se quiser rodar em outra porta:');
    console.error('     PowerShell   $env:PORT=4174; npm start');
    console.error('     Bash         PORT=4174 npm start');
    console.error('');
    console.error('  Para encerrar a instancia atual:');
    console.error(`     PowerShell   Get-NetTCPConnection -LocalPort ${PORT} -State Listen | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }`);
    console.error(`     Linux        fuser -k ${PORT}/tcp`);
    console.error('');
    process.exit(1);
  }
  throw err;
});
