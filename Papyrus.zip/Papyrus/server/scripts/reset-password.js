/*
 * Redefine uma senha direto no arquivo de usuarios, sem passar pela interface.
 * E a saida para quando a senha do administrador se perdeu.
 *
 *   npm run reset-password                       usuario padrao volta para a senha padrao
 *   npm run reset-password -- joao NovaSenha123  define a senha de outro usuario
 *
 * Pode rodar com o servidor no ar: o servidor percebe a mudanca no arquivo.
 * Respeita PAPYRUS_DIR, como o servidor.
 */

import {
  restoreDefaultUserPassword, resetPassword, listUsers, DEFAULT_USERNAME, DEFAULT_PASSWORD,
} from '../lib/auth.js';
import { ensureBaseStructure } from '../lib/paths.js';

const [username, password] = process.argv.slice(2);

try {
  await ensureBaseStructure();

  if (!username || (username === DEFAULT_USERNAME && !password)) {
    await restoreDefaultUserPassword();
    console.log(`Senha do usuário "${DEFAULT_USERNAME}" redefinida para a padrão (${DEFAULT_PASSWORD}).`);
    console.log('Entre e troque a senha em "Trocar minha senha".');
  } else {
    if (!password) throw new Error('Informe a nova senha: npm run reset-password -- <usuario> <senha>');
    const known = (await listUsers()).some((u) => u.username === username.toLowerCase());
    if (!known) throw new Error(`O usuário "${username}" não existe.`);
    await resetPassword(username.toLowerCase(), password);
    console.log(`Senha do usuário "${username.toLowerCase()}" redefinida.`);
  }
  process.exit(0);
} catch (err) {
  console.error(err.message);
  process.exit(1);
}
