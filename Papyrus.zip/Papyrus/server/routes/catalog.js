/*
 * Catalogo de eventos e parametros do mapeamento, montado em
 * /api/w/:workspace/catalog. As regras moram em lib/catalog.js; aqui so entra
 * e sai JSON.
 *
 * Toda resposta de mutacao devolve o catalogo inteiro atualizado. A interface
 * troca o seu de uma vez e ressincroniza a pagina aberta com ele, sem precisar
 * de uma segunda requisicao.
 */

import express from 'express';
import { sanitizeName } from '../lib/paths.js';
import {
  readCatalog, createEvent, updateEvent, deleteEvent, createEventFromDefinition,
  createParam, updateParam, deleteParam, planAdoption, applyAdoption,
  buildCatalogExport, importCatalog,
} from '../lib/catalog.js';
import { uploadToGcs, downloadJsonObject } from '../lib/gcs.js';
import { catalogSourceOf } from '../lib/importer.js';

const router = express.Router({ mergeParams: true });

const strip = (catalog) => ({ events: catalog.events, params: catalog.params, updatedAt: catalog.updatedAt });

const handle = (fn) => async (req, res, next) => {
  try {
    await fn(req, res);
  } catch (err) {
    next(err);
  }
};

/** GET /catalog */
router.get('/catalog', handle(async (req, res) => {
  res.json({ catalog: strip(await readCatalog(req.ws)) });
}));

/* Eventos */

/** POST /catalog/events  { name, eventType, description, params: [{ id, required }] } */
router.post('/catalog/events', handle(async (req, res) => {
  const { event, catalog } = await createEvent(req.ws, req.body || {}, req.user.username);
  res.status(201).json({ event, catalog: strip(catalog) });
}));

/** POST /catalog/events/from-definition: "Adicionar ao catalogo" a partir de um card. */
router.post('/catalog/events/from-definition', handle(async (req, res) => {
  const result = await createEventFromDefinition(req.ws, req.body || {}, req.user.username);
  res.status(201).json({ ...result, catalog: strip(result.catalog) });
}));

/** PUT /catalog/events/:id */
router.put('/catalog/events/:id', handle(async (req, res) => {
  const { event, catalog, propagation } = await updateEvent(req.ws, req.params.id, req.body || {}, req.user.username);
  res.json({ event, catalog: strip(catalog), propagation });
}));

/** DELETE /catalog/events/:id */
router.delete('/catalog/events/:id', handle(async (req, res) => {
  const { catalog, unlinked } = await deleteEvent(req.ws, req.params.id);
  res.json({ catalog: strip(catalog), unlinked });
}));

/* Parametros */

/** POST /catalog/params  { name, scope, type, required, description, example } */
router.post('/catalog/params', handle(async (req, res) => {
  const { param, catalog } = await createParam(req.ws, req.body || {}, req.user.username);
  res.status(201).json({ param, catalog: strip(catalog) });
}));

/** PUT /catalog/params/:id */
router.put('/catalog/params/:id', handle(async (req, res) => {
  const { param, catalog, propagation } = await updateParam(req.ws, req.params.id, req.body || {}, req.user.username);
  res.json({ param, catalog: strip(catalog), propagation });
}));

/** DELETE /catalog/params/:id */
router.delete('/catalog/params/:id', handle(async (req, res) => {
  const { catalog } = await deleteParam(req.ws, req.params.id);
  res.json({ catalog: strip(catalog) });
}));

/* Trazer os eventos dos mapas */

/** GET /catalog/adopt: o plano, sem gravar nada. */
router.get('/catalog/adopt', handle(async (req, res) => {
  res.json({ plan: await planAdoption(req.ws) });
}));

/** POST /catalog/adopt: cria o que falta no catalogo e liga os cards. */
router.post('/catalog/adopt', handle(async (req, res) => {
  const { catalog, report } = await applyAdoption(req.ws, req.user.username);
  res.json({ catalog: strip(catalog), report });
}));

/* Storage */

/** POST /catalog/export  { filename }: grava em <prefixo>catalog/<nome>.json. */
router.post('/catalog/export', handle(async (req, res) => {
  const catalog = await readCatalog(req.ws);
  const safeName = sanitizeName(req.body?.filename || `catalogo-${req.ws.id}`);
  const filename = safeName.endsWith('.json') ? safeName : `${safeName}.json`;

  const uploaded = await uploadToGcs({
    filename,
    folder: 'catalog',
    contentType: 'application/json',
    buffer: Buffer.from(JSON.stringify(buildCatalogExport(req.ws, catalog), null, 2), 'utf8'),
  });
  res.json({ saved: true, gcs: uploaded, events: catalog.events.length, params: catalog.params.length });
}));

/**
 * POST /catalog/import
 * body: { source: 'gcs'|'inline', object?, content?, mode: 'merge'|'replace', sourceWorkspace? }
 *
 * Aceita o arquivo de catalogo, o backup diario (usa o catalogo de um dos
 * mapeamentos dele) e o contrato exportado (monta o catalogo a partir dos
 * eventos).
 */
router.post('/catalog/import', handle(async (req, res) => {
  const body = req.body || {};
  let json;
  if (body.source === 'gcs') {
    json = await downloadJsonObject(body.object);
  } else {
    try {
      json = JSON.parse(body.content);
    } catch {
      return res.status(400).json({ error: 'O arquivo não é um JSON válido.' });
    }
  }

  const source = catalogSourceOf(json, { sourceWorkspace: body.sourceWorkspace, workspaceId: req.ws.id });
  if (!source) {
    return res.status(422).json({
      error: 'Este arquivo não traz catálogo: use um catálogo exportado, um backup (versions/) ou um contrato exportado.',
    });
  }

  const { catalog, report } = await importCatalog(req.ws, source, { mode: body.mode }, req.user.username);
  res.json({ catalog: strip(catalog), report });
}));

export default router;
