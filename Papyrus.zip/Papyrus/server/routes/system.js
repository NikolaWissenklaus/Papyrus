/*
 * Modulos transversais de um mapeamento: Grupos de Parametros, a consolidacao
 * dos mapas (o que o antigo Dicionario Global mostrava e que hoje alimenta a
 * aba Catalogo), o exportador de eventos e a importacao de mapas.
 *
 * Montado em /api/w/:workspace. Nada aqui devolve caminho absoluto ou
 * estrutura de pastas do host. E o que permite rodar a ferramenta em um
 * servidor compartilhado.
 */

import express from 'express';
import path from 'node:path';
import { resolveIn, sanitizeName } from '../lib/paths.js';
import { collectAllDocs, eventCards, extractEvent, readDocIfValid, EVENT_ID_PARAM } from '../lib/papyrus.js';
import { readTemplates, writeTemplates } from '../lib/templates.js';
import { readCatalog } from '../lib/catalog.js';
import { uploadToGcs, downloadJsonObject } from '../lib/gcs.js';
import { importIntoWorkspace, summarize } from '../lib/importer.js';
import { indexCatalog, syncDocWithCatalog, cardLinkStatus, folderNameOf } from '../../shared/catalog-sync.js';

const router = express.Router({ mergeParams: true });

/* Grupos de Parametros */

/** GET /templates */
router.get('/templates', async (req, res, next) => {
  try {
    res.json({ groups: await readTemplates(req.ws) });
  } catch (err) {
    next(err);
  }
});

/** PUT /templates  { groups: [...] }: grava a colecao inteira. */
router.put('/templates', async (req, res, next) => {
  try {
    const groups = Array.isArray(req.body.groups) ? req.body.groups : [];
    await writeTemplates(req.ws, groups);
    res.json({ ok: true, count: groups.length });
  } catch (err) {
    next(err);
  }
});

/* Consolidacao dos mapas */

/** Paginas do mapeamento ja sincronizadas com o catalogo, como o export as ve. */
async function syncedDocs(ws, index) {
  return (await collectAllDocs(ws)).map(({ path: relative, doc }) => ({
    path: relative,
    doc: syncDocWithCatalog(doc, index, { folderName: folderNameOf(relative) }).doc,
  }));
}

/**
 * GET /dictionary
 *
 * Consolida o mapeamento inteiro: `events` traz todo card e onde ele mora,
 * `parameters` traz os parametros unicos com o de-para dos eventos que os
 * usam, `conflicts` lista o mesmo parametro declarado com tipos diferentes
 * (o risco de schema) e `eventIdCollisions` aponta o event_id que aparece em
 * mais de um card. `catalogUsage` diz em quantos cards e paginas cada evento
 * do catalogo esta, e `unlinked` conta os cards fora do catalogo.
 */
router.get('/dictionary', async (req, res, next) => {
  try {
    const index = indexCatalog(await readCatalog(req.ws));
    const docs = await syncedDocs(req.ws, index);
    const events = [];
    const paramMap = new Map();
    const catalogUsage = {};
    let unlinked = 0;
    let missing = 0;

    for (const { path: relPath, doc } of docs) {
      const pageName = doc.name || path.basename(relPath, '.json');

      for (const el of eventCards(doc)) {
        const evt = extractEvent(el);
        const status = cardLinkStatus(el.data, index);
        if (status === 'unlinked') unlinked += 1;
        if (status === 'missing') missing += 1;

        if (status === 'linked') {
          const usage = (catalogUsage[el.data.catalogEventId] ||= { cards: 0, pages: [] });
          usage.cards += 1;
          const page = usage.pages.find((p) => p.path === relPath);
          if (page) page.count += 1;
          else usage.pages.push({ path: relPath, name: pageName, count: 1 });
        }

        events.push({
          ...evt,
          page: pageName,
          pagePath: relPath,
          elementId: el.id,
          catalogEventId: el.data.catalogEventId || null,
          catalogStatus: status,
        });

        for (const scope of ['event', 'user', 'items']) {
          for (const param of evt.parameters[scope] || []) {
            const key = `${scope}::${param.name}`;
            if (!paramMap.has(key)) {
              paramMap.set(key, { name: param.name, scope, types: new Set(), requiredIn: 0, usedBy: [] });
            }
            const entry = paramMap.get(key);
            entry.types.add(param.type);
            if (param.required) entry.requiredIn += 1;
            entry.usedBy.push({ event: evt.event_name, page: pageName, pagePath: relPath });
          }
        }
      }
    }

    const parameters = [...paramMap.values()]
      .map((p) => ({
        name: p.name,
        scope: p.scope,
        types: [...p.types],
        requiredIn: p.requiredIn,
        usageCount: p.usedBy.length,
        usedBy: p.usedBy,
      }))
      .sort((a, b) => b.usageCount - a.usageCount || a.name.localeCompare(b.name));

    const conflicts = parameters
      .filter((p) => p.types.length > 1)
      .map((p) => ({ name: p.name, scope: p.scope, types: p.types }));

    // event_id repetido. O validador da pagina so enxerga a pagina aberta, e a
    // chave precisa ser unica no mapeamento todo, entao a colisao entre paginas
    // so aparece aqui.
    const byEventId = new Map();
    for (const e of events) {
      const id = ((e.parameters.event || []).find((p) => p.name === EVENT_ID_PARAM)?.example || '').trim();
      if (!id) continue;
      if (!byEventId.has(id)) byEventId.set(id, []);
      byEventId.get(id).push({ event: e.event_name, page: e.page, pagePath: e.pagePath });
    }
    const eventIdCollisions = [...byEventId.entries()]
      .filter(([, uses]) => uses.length > 1)
      .map(([id, uses]) => ({ id, uses }));

    res.json({
      generatedAt: new Date().toISOString(),
      totals: { pages: docs.length, events: events.length, parameters: parameters.length, unlinked, missing },
      events,
      parameters,
      conflicts,
      eventIdCollisions,
      catalogUsage,
    });
  } catch (err) {
    next(err);
  }
});

/* Exportador */

/** Aponta evento sem event_id e event_id usado por mais de um evento. */
function findEventIdProblems(payload) {
  const problems = [];
  const byId = new Map();

  for (const [page, events] of Object.entries(payload)) {
    for (const evt of events) {
      const id = ((evt.parameters?.event || []).find((p) => p.name === EVENT_ID_PARAM)?.example || '').trim();

      if (!id) {
        problems.push({ kind: 'missing', page, event: evt.event_name });
        continue;
      }
      if (!byId.has(id)) byId.set(id, []);
      byId.get(id).push({ page, event: evt.event_name });
    }
  }

  for (const [id, uses] of byId) {
    if (uses.length > 1) problems.push({ kind: 'duplicate', id, uses });
  }

  return problems;
}

/**
 * POST /export/events
 * body: { paths?: string[], filename?: string }
 *
 * Gera `{ "<nome da pagina>": [ ...eventos com parametros tipados ] }`.
 * Nenhuma coordenada de canvas, cor ou elemento visual entra no arquivo. Os
 * cards saem sincronizados com o catalogo atual.
 *
 * O nome da pagina basta como chave porque o mapeamento nao aceita nome
 * repetido: ver lib/names.js.
 *
 * O destino e sempre o bucket do Google Cloud Storage configurado. O contrato
 * de coleta precisa morar em um lugar so, versionado e acessivel ao time; um
 * download solto na maquina de quem exportou vira copia divergente no dia
 * seguinte. Gravar em caminho de disco tambem nao e opcao, porque exporia o
 * filesystem do servidor quando a ferramenta roda compartilhada.
 *
 * Recusa a exportacao quando algum event_id falta ou se repete. A UI ja checa
 * isso antes de habilitar o botao, mas a garantia precisa morar aqui: o arquivo
 * no bucket e lido como verdade pelo time de engenharia, e um id repetido faz
 * dois eventos diferentes chegarem como o mesmo no GA4.
 */
router.post('/export/events', async (req, res, next) => {
  try {
    const { paths: requested, filename } = req.body;
    const index = indexCatalog(await readCatalog(req.ws));

    const docs =
      Array.isArray(requested) && requested.length
        ? await Promise.all(
            requested.map(async (rel) => ({ path: rel, doc: await readDocIfValid(resolveIn(req.ws.root, rel)) })),
          )
        : await collectAllDocs(req.ws);

    /** @type {Record<string, object[]>} */
    const payload = {};
    for (const item of docs) {
      if (!item.doc) continue;
      const doc = syncDocWithCatalog(item.doc, index, { folderName: folderNameOf(item.path) }).doc;
      const pageName = doc.name || path.basename(item.path, '.json');
      payload[pageName] = eventCards(doc).map(extractEvent);
    }

    const problems = findEventIdProblems(payload);
    if (problems.length) {
      return res.status(409).json({
        error: 'Exportacao bloqueada: event_id ausente ou repetido.',
        problems,
      });
    }

    const json = JSON.stringify(payload, null, 2);
    const safeName = sanitizeName(filename || `papyrus-${Date.now()}`);
    const object = safeName.endsWith('.json') ? safeName : `${safeName}.json`;

    const uploaded = await uploadToGcs({
      filename: object,
      contentType: 'application/json',
      buffer: Buffer.from(json, 'utf8'),
    });
    res.json({ saved: true, gcs: uploaded, pages: Object.keys(payload).length });
  } catch (err) {
    next(err);
  }
});

/* Importacao */

/*
 * A importacao chega por upload pelo navegador ou do bucket configurado. O
 * antigo navegador de diretorios do SO e a importacao por caminho absoluto
 * foram removidos de proposito: com a ferramenta em servidor compartilhado, os
 * dois exporiam a estrutura de pastas do host.
 */

/** Le os arquivos do corpo da requisicao, sem deixar um JSON quebrado derrubar o lote. */
function parseInlineFiles(files) {
  return (Array.isArray(files) ? files : []).map((f) => {
    const name = String(f?.name || 'arquivo.json');
    try {
      return { name, json: JSON.parse(f.content) };
    } catch {
      return { name, error: 'JSON invalido.' };
    }
  });
}

/**
 * POST /import/inspect  { object }: le um arquivo do bucket e diz o que ele e,
 * para a tela oferecer as opcoes certas antes de importar.
 */
router.post('/import/inspect', async (req, res, next) => {
  try {
    const json = await downloadJsonObject(req.body?.object);
    res.json({ object: req.body.object, summary: summarize(json) });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /import
 * body: { source: 'inline'|'gcs', files?: [{ name, content }], object?,
 *         destination?, onConflict?: 'skip'|'overwrite', sourceWorkspace? }
 */
router.post('/import', async (req, res, next) => {
  try {
    const body = req.body || {};
    const items =
      body.source === 'gcs'
        ? [{ name: path.posix.basename(String(body.object || 'arquivo.json')), json: await downloadJsonObject(body.object) }]
        : parseInlineFiles(body.files);

    const report = await importIntoWorkspace(
      req.ws,
      items,
      { destination: body.destination, onConflict: body.onConflict, sourceWorkspace: body.sourceWorkspace },
      req.user.username,
    );
    res.json(report);
  } catch (err) {
    next(err);
  }
});

/** POST /import/inline  { files, destination }: rota antiga, mesmo comportamento de /import. */
router.post('/import/inline', async (req, res, next) => {
  try {
    const report = await importIntoWorkspace(
      req.ws,
      parseInlineFiles(req.body?.files),
      { destination: req.body?.destination },
      req.user.username,
    );
    res.json(report);
  } catch (err) {
    next(err);
  }
});

export default router;
