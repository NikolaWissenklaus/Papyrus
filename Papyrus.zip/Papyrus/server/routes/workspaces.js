/*
 * Mapeamentos: a lista do hub (com os numeros de cada card), criacao,
 * renomeacao e exclusao. Excluir e renomear sao de administrador; criar e de
 * qualquer pessoa logada.
 */

import express from 'express';
import fs from 'node:fs/promises';
import {
  listWorkspaces, getWorkspace, createWorkspace, updateWorkspace, deleteWorkspace, publicWorkspace,
} from '../lib/workspaces.js';
import { collectAllDocs, countEvents } from '../lib/papyrus.js';
import { readCatalog } from '../lib/catalog.js';
import { requireAdmin } from '../lib/auth.js';

const router = express.Router();

/** Numeros que o card do hub mostra. Falha de leitura nao derruba a lista. */
async function statsOf(ws) {
  try {
    const [docs, catalog, stat] = await Promise.all([
      collectAllDocs(ws),
      readCatalog(ws),
      fs.stat(ws.root).catch(() => null),
    ]);
    const updated = docs.map((d) => d.doc.updatedAt).filter(Boolean).sort().pop();
    return {
      pages: docs.length,
      cards: docs.reduce((n, d) => n + countEvents(d.doc), 0),
      catalogEvents: catalog.events.length,
      updatedAt: updated || stat?.mtime?.toISOString() || null,
    };
  } catch {
    return { pages: 0, cards: 0, catalogEvents: 0, updatedAt: null };
  }
}

/** GET /api/workspaces */
router.get('/workspaces', async (_req, res, next) => {
  try {
    const list = await listWorkspaces();
    const workspaces = await Promise.all(
      list.map(async (ws) => ({ ...publicWorkspace(ws), stats: await statsOf(ws) })),
    );
    res.json({ workspaces });
  } catch (err) {
    next(err);
  }
});

/** POST /api/workspaces  { name, tool, description } */
router.post('/workspaces', async (req, res, next) => {
  try {
    const ws = await createWorkspace(req.body || {}, req.user.username);
    res.status(201).json({ workspace: { ...publicWorkspace(ws), stats: await statsOf(ws) } });
  } catch (err) {
    next(err);
  }
});

/** PATCH /api/workspaces/:id  { name?, description?, tool? } */
router.patch('/workspaces/:id', requireAdmin, async (req, res, next) => {
  try {
    if (!(await getWorkspace(req.params.id))) return res.status(404).json({ error: 'Mapeamento não encontrado.' });
    const ws = await updateWorkspace(req.params.id, req.body || {});
    res.json({ workspace: { ...publicWorkspace(ws), stats: await statsOf(ws) } });
  } catch (err) {
    next(err);
  }
});

/** DELETE /api/workspaces/:id */
router.delete('/workspaces/:id', requireAdmin, async (req, res, next) => {
  try {
    await deleteWorkspace(req.params.id);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

export default router;
