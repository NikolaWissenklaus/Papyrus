/*
 * Integracao com o Google Cloud Storage e backup diario. E configuracao
 * global, igual para todos os mapeamentos.
 *
 * Ler o status e listar o bucket e liberado para qualquer pessoa logada, que
 * precisa disso para exportar e importar. Gravar configuracao, testar com uma
 * credencial nova e disparar backup fica com os administradores: a service
 * account e a chave de escrita no bucket da empresa.
 */

import express from 'express';
import {
  gcsStatus, readGcsFileConfig, saveGcsConfig, testGcs, gcsEnvOverrides, listJsonObjects,
} from '../lib/gcs.js';
import { backupStatus, runBackup } from '../lib/backup.js';
import { requireAdmin } from '../lib/auth.js';

const router = express.Router();

/** GET /api/gcs/status: a UI usa isto para habilitar, ou explicar, as opcoes. */
router.get('/gcs/status', async (_req, res, next) => {
  try {
    res.json(await gcsStatus());
  } catch (err) {
    next(err);
  }
});

/** GET /api/gcs/objects: os .json abaixo do prefixo, para a importacao. */
router.get('/gcs/objects', async (_req, res, next) => {
  try {
    res.json(await listJsonObjects());
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/settings/gcs: configuracao atual para a aba Configuracoes.
 * Nem a chave privada nem CAMINHOS do servidor sao devolvidos: a credencial
 * vira apenas o booleano `hasCredential`.
 */
router.get('/settings/gcs', async (_req, res, next) => {
  try {
    const fileConfig = await readGcsFileConfig();
    res.json({
      config: {
        bucket: fileConfig.bucket || '',
        prefix: fileConfig.prefix || '',
        projectId: fileConfig.projectId || '',
        hasCredential: Boolean(fileConfig.keyFilename),
      },
      envOverrides: gcsEnvOverrides(),
      status: await gcsStatus(),
    });
  } catch (err) {
    next(err);
  }
});

/** PUT /api/settings/gcs  { bucket, prefix, projectId, keyJson?, removeKey? } */
router.put('/settings/gcs', requireAdmin, async (req, res, next) => {
  try {
    const saved = await saveGcsConfig(req.body || {});
    res.json({
      config: {
        bucket: saved.bucket,
        prefix: saved.prefix,
        projectId: saved.projectId,
        hasCredential: Boolean(saved.keyFilename),
      },
      status: await gcsStatus(),
    });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/settings/gcs/test  { bucket?, prefix?, projectId?, keyJson? }
 * Valida lib + credencial + acesso ao bucket. O corpo é opcional: quando vem
 * preenchido, testa os valores que estão na tela (permite testar sem salvar);
 * quando vem vazio, testa a configuração já persistida.
 */
router.post('/settings/gcs/test', requireAdmin, async (req, res, next) => {
  try {
    res.json(await testGcs(req.body || {}));
  } catch (err) {
    next(err);
  }
});

/** GET /api/backup/status */
router.get('/backup/status', async (_req, res, next) => {
  try {
    res.json(await backupStatus());
  } catch (err) {
    next(err);
  }
});

/** POST /api/backup/run: backup do dia agora, sem esperar a meia-noite. */
router.post('/backup/run', requireAdmin, async (_req, res, next) => {
  try {
    const lastRun = await runBackup({ trigger: 'manual' });
    res.json({ lastRun, status: await backupStatus() });
  } catch (err) {
    next(err);
  }
});

export default router;
