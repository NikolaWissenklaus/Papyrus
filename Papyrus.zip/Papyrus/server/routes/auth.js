/*
 * Login, sessao e gestao de usuarios.
 *
 * `publicAuthRoutes` e montado antes da barreira de sessao (entrar e sair
 * precisam funcionar sem estar logado). `sessionRoutes` e `userRoutes` ficam
 * atras dela; os de usuario exigem tambem perfil de administrador.
 */

import express from 'express';
import {
  login, destroySession, readSessionToken, setSessionCookie, clearSessionCookie,
  changeOwnPassword, listUsers, createUser, resetPassword, setAdmin, deleteUser,
  requireAdmin, SESSION_TTL_MS,
} from '../lib/auth.js';

export const publicAuthRoutes = express.Router();
export const sessionRoutes = express.Router();
export const userRoutes = express.Router();

/** POST /api/auth/login  { username, password } */
publicAuthRoutes.post('/login', async (req, res, next) => {
  try {
    const { token, user } = await login(req.body?.username, req.body?.password, req.ip || '');
    setSessionCookie(res, req, token);
    res.json({ user, sessionTtlMs: SESSION_TTL_MS });
  } catch (err) {
    next(err);
  }
});

/** POST /api/auth/logout: funciona com ou sem sessao valida. */
publicAuthRoutes.post('/logout', (req, res) => {
  destroySession(readSessionToken(req));
  clearSessionCookie(res, req);
  res.json({ ok: true });
});

/** GET /api/auth/me: quem esta logado e quanto dura a sessao ociosa. */
sessionRoutes.get('/auth/me', (req, res) => {
  res.json({ user: req.user, sessionTtlMs: SESSION_TTL_MS });
});

/*
 * POST /api/auth/touch: a interface chama quando a pessoa esta mexendo na
 * tela sem gerar requisicao (lendo o catalogo, rolando uma tabela). A barreira
 * de sessao ja empurrou o prazo; aqui nao ha mais nada a fazer.
 */
sessionRoutes.post('/auth/touch', (_req, res) => {
  res.status(204).end();
});

/** POST /api/auth/password  { currentPassword, newPassword } */
sessionRoutes.post('/auth/password', async (req, res, next) => {
  try {
    const user = await changeOwnPassword(
      req.user.username,
      req.body?.currentPassword,
      req.body?.newPassword,
      req.sessionToken,
    );
    res.json({ user });
  } catch (err) {
    next(err);
  }
});

userRoutes.use('/users', requireAdmin);

/** GET /api/users */
userRoutes.get('/users', async (_req, res, next) => {
  try {
    res.json({ users: await listUsers() });
  } catch (err) {
    next(err);
  }
});

/** POST /api/users  { username, password, admin } */
userRoutes.post('/users', async (req, res, next) => {
  try {
    const user = await createUser(req.body || {}, req.user.username);
    res.status(201).json({ user });
  } catch (err) {
    next(err);
  }
});

/** PUT /api/users/:username/password  { password }: redefinicao pelo administrador. */
userRoutes.put('/users/:username/password', async (req, res, next) => {
  try {
    const user = await resetPassword(req.params.username, req.body?.password, req.sessionToken);
    res.json({ user });
  } catch (err) {
    next(err);
  }
});

/** PATCH /api/users/:username  { admin } */
userRoutes.patch('/users/:username', async (req, res, next) => {
  try {
    if (req.params.username === req.user.username) {
      return res.status(400).json({ error: 'Você não pode mudar o próprio perfil.' });
    }
    const user = await setAdmin(req.params.username, req.body?.admin);
    res.json({ user });
  } catch (err) {
    next(err);
  }
});

/** DELETE /api/users/:username */
userRoutes.delete('/users/:username', async (req, res, next) => {
  try {
    await deleteUser(req.params.username, req.user.username);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});
