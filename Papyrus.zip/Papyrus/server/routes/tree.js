/*
 * CRUD da arvore de trabalho (pastas e paginas) e leitura e gravacao de pagina.
 *
 * Montado em /api/w/:workspace, entao todo caminho e relativo a raiz do
 * mapeamento em `req.ws` (ver lib/workspaces.js).
 */

import express from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import { resolveIn, toRelative, sanitizeName, exists } from '../lib/paths.js';
import { assertNameAvailable } from '../lib/names.js';
import { scanTree, createEmptyDoc, readDocIfValid, writeDoc, listPagePaths } from '../lib/papyrus.js';
import {
  readFolderColors,
  setFolderColor,
  moveFolderColors,
  forgetFolderColors,
} from '../lib/folder-colors.js';
import { readCatalog, pageLockKey } from '../lib/catalog.js';
import { withLock } from '../lib/json-store.js';
import { indexCatalog, syncDocWithCatalog, folderNameOf } from '../../shared/catalog-sync.js';

const router = express.Router({ mergeParams: true });

const HEX_COLOR = /^#[0-9a-fA-F]{6}$/;
const GRID_STYLES = ['dots', 'lines', 'none'];

/** GET /tree: arvore completa do mapeamento. */
router.get('/tree', async (req, res, next) => {
  try {
    const colors = await readFolderColors(req.ws);
    res.json({ nodes: await scanTree(req.ws, req.ws.root, 0, colors) });
  } catch (err) {
    next(err);
  }
});

/** POST /folders  { parent, name, color? } */
router.post('/folders', async (req, res, next) => {
  try {
    const parent = resolveIn(req.ws.root, req.body.parent || '');
    const name = sanitizeName(req.body.name);
    await assertNameAvailable(req.ws, name);

    const target = path.join(parent, name);
    await fs.mkdir(target, { recursive: true });

    const relative = toRelative(target, req.ws.root);
    if (req.body.color) await setFolderColor(req.ws, relative, req.body.color);

    res.status(201).json({ path: relative, name: path.basename(target), color: req.body.color || null });
  } catch (err) {
    next(err);
  }
});

/** PUT /folders/color  { path, color }: cor vazia volta ao padrao. */
router.put('/folders/color', async (req, res, next) => {
  try {
    const absolute = resolveIn(req.ws.root, req.body.path);
    const stat = await fs.stat(absolute);
    if (!stat.isDirectory()) {
      return res.status(400).json({ error: 'Somente pastas tem cor personalizada.' });
    }

    const relative = toRelative(absolute, req.ws.root);
    await setFolderColor(req.ws, relative, req.body.color || '');
    res.json({ path: relative, color: req.body.color || null });
  } catch (err) {
    next(err);
  }
});

/** POST /pages  { parent, name }: cria uma pagina de canvas vazia. */
router.post('/pages', async (req, res, next) => {
  try {
    const parent = resolveIn(req.ws.root, req.body.parent || '');
    const name = sanitizeName(req.body.name);
    await assertNameAvailable(req.ws, name);

    await fs.mkdir(parent, { recursive: true });

    const target = path.join(parent, `${name}.json`);
    const doc = await withLock(pageLockKey(target), () => writeDoc(target, createEmptyDoc(name)));

    res.status(201).json({ path: toRelative(target, req.ws.root), name, doc });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /page?path=...: le uma pagina validada.
 *
 * Os cards vinculados saem ja sincronizados com o catalogo atual. A pagina no
 * disco pode estar atrasada (alguem com a pagina aberta salvou por cima de uma
 * propagacao, ou ela veio de uma importacao), e quem abre precisa ver o
 * catalogo de hoje. `synced: true` avisa a interface para gravar a versao
 * corrigida.
 */
router.get('/page', async (req, res, next) => {
  try {
    const absolute = resolveIn(req.ws.root, req.query.path);
    const doc = await readDocIfValid(absolute);

    if (!doc) {
      return res.status(422).json({
        error: 'Arquivo ignorado: a raiz do JSON precisa conter "json-type": "papyrus".',
      });
    }

    const relative = toRelative(absolute, req.ws.root);
    const index = indexCatalog(await readCatalog(req.ws));
    const result = syncDocWithCatalog(doc, index, { folderName: folderNameOf(relative) });

    res.json({ path: relative, doc: result.doc, synced: result.changed > 0 });
  } catch (err) {
    next(err);
  }
});

/** PUT /page  { path, doc }: grava a pagina (auto-save do canvas). */
router.put('/page', async (req, res, next) => {
  try {
    const absolute = resolveIn(req.ws.root, req.body.path);
    if (!absolute.toLowerCase().endsWith('.json')) {
      return res.status(400).json({ error: 'Somente arquivos .json podem ser gravados.' });
    }
    const saved = await withLock(pageLockKey(absolute), () => writeDoc(absolute, req.body.doc || {}));
    res.json({ path: toRelative(absolute, req.ws.root), updatedAt: saved.updatedAt });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /pages/appearance  { background?, grid? }: aplica a aparencia do canvas
 * em todas as paginas do mapeamento. Fundo vazio volta ao padrao.
 */
router.post('/pages/appearance', async (req, res, next) => {
  try {
    const { background, grid } = req.body || {};
    if (background && !HEX_COLOR.test(background)) {
      return res.status(400).json({ error: 'Cor inválida: use hexadecimal no formato #RRGGBB.' });
    }
    if (grid != null && !GRID_STYLES.includes(grid)) {
      return res.status(400).json({ error: 'Estilo de grade inválido.' });
    }

    let pages = 0;
    for (const relative of await listPagePaths(req.ws)) {
      const absolute = resolveIn(req.ws.root, relative);
      await withLock(pageLockKey(absolute), async () => {
        const doc = await readDocIfValid(absolute);
        if (!doc) return;

        const next = { ...doc };
        if (background !== undefined) {
          if (background) next.background = background.toUpperCase();
          else delete next.background;
        }
        if (grid !== undefined) {
          if (grid && grid !== 'dots') next.grid = grid;
          else delete next.grid;
        }
        await writeDoc(absolute, next);
        pages += 1;
      });
    }
    res.json({ pages });
  } catch (err) {
    next(err);
  }
});

/** PATCH /entry  { path, name }: renomeia pasta ou pagina. */
router.patch('/entry', async (req, res, next) => {
  try {
    const absolute = resolveIn(req.ws.root, req.body.path);
    if (absolute === req.ws.root) {
      return res.status(400).json({ error: 'A raiz nao pode ser renomeada.' });
    }

    const stat = await fs.stat(absolute);
    const name = sanitizeName(req.body.name);

    // O proprio item nao conta como conflito: trocar so a caixa da letra, de
    // "abacate" para "Abacate", precisa continuar sendo uma renomeacao valida.
    await assertNameAvailable(req.ws, name, { ignorePath: toRelative(absolute, req.ws.root) });

    const ext = stat.isDirectory() ? '' : '.json';
    const target = path.join(path.dirname(absolute), `${name}${ext}`);

    await fs.rename(absolute, target);

    if (stat.isDirectory()) {
      await moveFolderColors(req.ws, toRelative(absolute, req.ws.root), toRelative(target, req.ws.root));
    }

    // Mantem o campo `name` do documento em sincronia com o nome do arquivo.
    if (!stat.isDirectory()) {
      await withLock(pageLockKey(target), async () => {
        const doc = await readDocIfValid(target);
        if (doc) await writeDoc(target, { ...doc, name: path.basename(target, '.json') });
      });
    }

    res.json({ path: toRelative(target, req.ws.root), name: path.basename(target, ext) });
  } catch (err) {
    next(err);
  }
});

/** DELETE /entry?path=...: exclui pasta (recursivo) ou pagina. */
router.delete('/entry', async (req, res, next) => {
  try {
    const absolute = resolveIn(req.ws.root, req.query.path);
    if (absolute === req.ws.root) {
      return res.status(400).json({ error: 'A raiz nao pode ser excluida.' });
    }
    if (!(await exists(absolute))) return res.status(404).json({ error: 'Nao encontrado.' });

    await fs.rm(absolute, { recursive: true, force: true });
    await forgetFolderColors(req.ws, toRelative(absolute, req.ws.root));
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

/** POST /entry/move  { path, destination }: move pasta/pagina (drag & drop). */
router.post('/entry/move', async (req, res, next) => {
  try {
    const source = resolveIn(req.ws.root, req.body.path);
    const destDir = resolveIn(req.ws.root, req.body.destination || '');

    if (source === req.ws.root) return res.status(400).json({ error: 'Origem invalida.' });
    if (destDir === source || destDir.startsWith(source + path.sep)) {
      return res.status(400).json({ error: 'Nao e possivel mover uma pasta para dentro dela mesma.' });
    }

    /*
     * Mover nao muda o nome, e nome repetido ja e barrado na criacao, entao
     * aqui a checagem so pega mapeamento montado antes desta regra. Ainda assim
     * ela existe: renomear em silencio para "(2)" durante um arrastar e soltar
     * seria a forma mais facil de acabar com duas paginas parecidas.
     */
    const target = path.join(destDir, path.basename(source));
    if (await exists(target)) {
      return res.status(409).json({
        error: `Já existe "${path.basename(source)}" na pasta de destino. Renomeie antes de mover.`,
      });
    }

    await fs.mkdir(destDir, { recursive: true });
    await fs.rename(source, target);
    await moveFolderColors(req.ws, toRelative(source, req.ws.root), toRelative(target, req.ws.root));
    res.json({ path: toRelative(target, req.ws.root) });
  } catch (err) {
    next(err);
  }
});

export default router;
